<?php
// --------------------------------------------------------
//  This is a part of the Sparx Systems Pro Cloud Server.
//  Copyright (C) Sparx Systems Pty Ltd
//  All rights reserved.
//
//  This source code can be used only under terms and 
//  conditions of the accompanying license agreement.
// --------------------------------------------------------
	$sRootPath = dirname(__FILE__);
	require_once $sRootPath . '/globals.php';
	SafeStartSession();
	if (isset($_SESSION['authorized']) === false)
	{
		echo '<div id="main-content-empty">' . _glt('Your session appears to have timed out') . '</div>';
		setResponseCode(440);
		exit();
	}
	$bAddDiscussions = (IsSessionSettingTrue('add_discuss'));
	$sAuthor 	= SafeGetInternalArrayParameter($_SESSION, 'login_fullname', '');
	if ( strIsEmpty( $sAuthor ) )
		$sAuthor = 'Web User';
	$sLoginGUID = SafeGetInternalArrayParameter($_SESSION, 'login_guid', '');
	$sSessionReviewGUID = SafeGetInternalArrayParameter($_SESSION, 'review_session');
	$iReviewCount = 0;
	foreach ($aDiscussions as $disc)
	{
		if (!strIsEmpty($disc['reviewguid']))
		{
			$iReviewCount++;
		}
	}
	if ($iReviewCount > 0 || (!strIsEmpty($sSessionReviewGUID)))
	{
		WritePropertySectionContentHeader('reviews', _glt('Reviews'), '1');
		echo '<div id="reviews-section">';
		WriteReviewsSection($aDiscussions, $sObjectGUID, $bAddDiscussions, $sAuthor, $sLoginGUID, $sSessionReviewGUID);
		echo '</div>' . PHP_EOL;
		echo '</div></li>';
	}
	WritePropertySectionContentHeader('discussions', _glt('Discussions'), '1');
	echo '<div id="discussion-section">';
	WriteDiscussionsSection($aDiscussions, $sObjectGUID, $bAddDiscussions, $sAuthor, $sLoginGUID, $sSessionReviewGUID);
	echo '</div>' . PHP_EOL;
	echo '</div></li>';
	if (isset($aAvatars))
	{
		WriteAvatarCSS($aAvatars);
	}
	function WriteReviewsSection($aDiscussions, $sObjectGUID, $bAddDiscussions, $sAuthor, $sLoginGUID, $sSessionReviewGUID)
	{
		$aReviews = array();
		foreach ($aDiscussions as $disc)
		{
			$aRow = array();
			$aRow['reviewname'] = $disc['reviewname'];
			$aRow['reviewguid'] = $disc['reviewguid'];
			if (!(in_array($aRow,$aReviews)) && ($disc['reviewguid']!==''))
			{
				$aReviews[] = $aRow;
			}
		}
		foreach ($aReviews as &$rev)
		{
			$rev['reviewdiscussions'] = array();
			foreach ($aDiscussions as $disc)
			{
				if ($disc['reviewguid']===$rev['reviewguid'])
				{
					$rev['reviewdiscussions'][] = $disc;
				}
			}
		}
		$sReviewName 		= '';
		$sReviewGUID 		= '';
		$aReviewDiscussions = array();
		foreach ($aReviews as $aReview)
		{
			$sReviewName 	 	= $aReview['reviewname'];
			$sReviewGUID 		= $aReview['reviewguid'];
			$aReviewDiscussions = $aReview['reviewdiscussions'];
			if ((strIsEmpty($sSessionReviewGUID)) || ($sSessionReviewGUID === $sReviewGUID))
			{
				echo '<div class="review-name w3-link" onclick="load_object(\'' . $sReviewGUID . '\',\'false\',\'\',\'\',\'' . ConvertStringToParameter($sReviewName) . '\',\'images/element16/review.png\')">';
				echo '<img alt="" title="Review" src="images/spriteplaceholder.png" class="propsprite-review">';
				echo ' ' . $aReview['reviewname'];
				echo '</div>';
				$iCnt = count($aReviewDiscussions);
				for ($i=0; $i<$iCnt; $i++)
				{
					$sDiscussText 		= SafeGetArrayItem2Dim($aReviewDiscussions, $i, 'discussion');
					$sDiscussGUID 		= SafeGetArrayItem2Dim($aReviewDiscussions, $i, 'guid');
					$sReviewGUID  		= SafeGetArrayItem2Dim($aReviewDiscussions, $i, 'reviewguid');
					$sExpandDiscussEvent= ' onclick="OnTogglePropertiesReviewDiscussionReplies(\'' . $sDiscussGUID . '\')"';
					$sReplyID			= 'replies_' . $sDiscussGUID;
					$sStatusButtonID	= 'sb_' . $sDiscussGUID;
					$sPriority			= SafeGetArrayItem2Dim($aReviewDiscussions, $i, 'priority');
					$sPriorityImageClass= SafeGetArrayItem2Dim($aReviewDiscussions, $i, 'priorityimageclass');
					$sPriorityTooltip 	= str_replace('%PRIORITY%', $sPriority, _glt('Priority: xx'));
					$sStatus 			= SafeGetArrayItem2Dim($aReviewDiscussions, $i, 'status');
					$sStatusImageClass	= SafeGetArrayItem2Dim($aReviewDiscussions, $i, 'statusimageclass');
					$sStatusTooltip 	= str_replace('%STATUS%', $sStatus, _glt('Status: xx'));
					$bHasReplies 		= array_key_exists(("replies"), $aReviewDiscussions[$i]);
					$sIsDisabled 		= '';
					if ($bAddDiscussions)
					{
						if ( !strIsEmpty($sReviewGUID) )
						{
							if ($sSessionReviewGUID === $sReviewGUID)
							{
								$bCanReply = true;
							}
							else
							{
								$bCanReply = false;
							}
						}
						else
						{
							$bCanReply = true;
						}
					}
					else
					{
						$bCanReply = false;
					}
					if ($bAddDiscussions || $bHasReplies)
					{
						echo '<div class="review-item collapsible-section-header-closed">';
						echo '<img alt="" src="images/spriteplaceholder.png" class="review-item-icon collapsible-section-header-closed-icon show-cursor-pointer" ' . $sExpandDiscussEvent . '>';
					}
					else
					{
						echo '<div class="review-item">';
						$sExpandDiscussEvent = '';
						$sIsDisabled 		=  'disabled="true"';
					}
					WriteAvatarImage($aReviewDiscussions[$i]['avatarid'], 'false');
					echo '<div class="discussion-item-states" >';
					WriteDiscussionStatusMenus($bCanReply, $sDiscussGUID, $sPriorityImageClass, $sPriorityTooltip, $sStatusImageClass, $sStatusTooltip);
					echo '</div>';
					echo '<div class="review-item-text"' . $sIsDisabled . $sExpandDiscussEvent . '>' . $sDiscussText . '</div>';
					echo '<div class="review-item-text-footer">';
					echo '<div class="review-item-text-footer-dateauthor">' . $aReviewDiscussions[$i]['created'] . '&nbsp; &nbsp;' . $aReviewDiscussions[$i]['author'] . '</div>';
					echo '</div>';
					echo '<div class="review-item-replies" id="'.$sReplyID.'">';
					if (array_key_exists(("replies"), $aReviewDiscussions[$i]))
					{
						$aReplies = $aReviewDiscussions[$i]['replies'];
						$iReplyCnt = count($aReplies);
						for ($iR=0; $iR<$iReplyCnt; $iR++)
						{
							$sReplyAuthor 	= SafeGetArrayItem2Dim($aReplies, $iR, 'replyauthor');
							$sReplyAvatarID	= SafeGetArrayItem2Dim($aReplies, $iR, 'replyavatarid');
							$sReplyAvatarImage	= SafeGetArrayItem2Dim($aReplies, $iR, 'replyavatarimage');
							$sReplyCreated 	= SafeGetArrayItem2Dim($aReplies, $iR, 'replycreated');
							$sReplyText 	= SafeGetArrayItem2Dim($aReplies, $iR, 'replytext');
							echo '<div class="review-item-reply">';
							WriteAvatarImage($sReplyAvatarID, 'true');
							echo '<div class="review-item-reply-text">' . $sReplyText . '</div>';
							echo '<div class="review-item-reply-text-footer">';
							echo '<div class="review-item-reply-text-footer-dateauthor">' . $sReplyCreated . '&nbsp; &nbsp;' . $sReplyAuthor . '</div>';
							echo '</div>';
							echo '</div>';
						}
					}
					if ($bAddDiscussions)
					{
						if ($bCanReply)
						{
							echo '<div class="discussion-reply-form" id="ddrf_' . $sDiscussGUID . '"><form id="drf_' . $sDiscussGUID . '" method="post">';
							echo '<div class="discussion-reply-comment-send">';
							echo '<div class="discussion-reply-send-div">';
							echo '<input class="webea-main-styled-button discussion-reply-send-button" type="submit" value="" onclick="OnFormRunAddReply(event, this.form)">';
							echo '</div>';
							echo '<div class="discussion-reply-comment-div">';
							echo '<textarea class="discussion-reply-new-comment" name="comments" placeholder="' . _glt('Post reply') . '"></textarea>';
							echo '</div>';
							echo '</div>';
							echo '<input type="hidden" name="guid" value="' . $sDiscussGUID .'"> ';
							echo '<input type="hidden" name="author" value="' . $sAuthor . '"> ';
							echo '<input type="hidden" name="isreply" value="true"> ';
							echo '<input type="hidden" name="objectguid" value="' . $sObjectGUID . '"> ';
							echo '<input type="hidden" name="loginguid" value="' . $sLoginGUID . '">';
							if ( !strIsEmpty($sSessionReviewGUID) && $sSessionReviewGUID===$sReviewGUID )
							{
								echo '<input type="hidden" name="sessionreviewguid" value="' . $sSessionReviewGUID . '">';
							}
							echo '</form></div>';
						}
						else
						{
							echo '<div class="discussion-reply-form" id="ddrf_' . $sDiscussGUID . '"><form id="drf_' . $sDiscussGUID . '" method="post">';
							echo '<div class="discussion-reply-join-review-message">' . _glt('Join the review to post a reply') . '</div>';
							echo '</form></div>';
						}
					}
					echo '</div>';
					echo '</div>';
				}
			}
		}
		if ($bAddDiscussions)
		{
			if ( !strIsEmpty($sSessionReviewGUID) )
			{
				echo '<div class="review-filtered-message">';
				echo _glt('Filtered to display the current review only');
				echo '</div>';
				echo '<div id="discussion-form"><form id="discussion-form1" method="post">';
				echo '<div id="discussion-comment-send">';
				echo '<div id="discussion-send-div">';
				echo '<input class="webea-main-styled-button" id="discussion-send-button" type="submit" value="" onclick="OnFormRunAddDiscussion(event)">';
				echo '</div>';
				echo '<div id="discussion-comment-div">';
				echo '<textarea class="discussion-new-comment" name="comments" placeholder="' . _glt('Create Review Topic') . '"></textarea>';
				echo '</div>';
				echo '</div>';
				echo '<input type="hidden" name="guid" value="' . $sObjectGUID . '"> ';
				echo '<input type="hidden" name="author" value="' . $sAuthor . '"> ';
				echo '<input type="hidden" name="isreply" value="false"> ';
				echo '<input type="hidden" name="loginguid" value="' . $sLoginGUID . '">';
				echo '<input type="hidden" name="sessionreviewguid" value="' . $sSessionReviewGUID . '">';
				echo '</form></div>';
			}
			else
			{
				echo '<div class="review-new-topic-message">';
				echo _glt('Join a review to create a new topic');
				echo '</div>';
			}
		}
	}
	function WriteDiscussionsSection($aDiscussions, $sObjectGUID, $bAddDiscussions, $sAuthor, $sLoginGUID, $sSessionReviewGUID)
	{
		$iCnt = count($aDiscussions);
		for ($i=0; $i<$iCnt; $i++)
		{
			$sDiscussText 		= SafeGetArrayItem2Dim($aDiscussions, $i, 'discussion');
			$sDiscussGUID 		= SafeGetArrayItem2Dim($aDiscussions, $i, 'guid');
			$sReviewGUID  		= SafeGetArrayItem2Dim($aDiscussions, $i, 'reviewguid');
			$sExpandDiscussEvent= ' onclick="OnToggleDiscussionReplies(\'' . $sDiscussGUID . '\')"';
			$sReplyID			= 'replies_' . $sDiscussGUID;
			$sStatusButtonID	= 'sb_' . $sDiscussGUID;
			$sPriority			= SafeGetArrayItem2Dim($aDiscussions, $i, 'priority');
			$sPriorityImageClass= SafeGetArrayItem2Dim($aDiscussions, $i, 'priorityimageclass');
			$sPriorityTooltip = str_replace('%PRIORITY%', $sPriority, _glt('Priority: xx'));
			$sStatus 			= SafeGetArrayItem2Dim($aDiscussions, $i, 'status');
			$sStatusImageClass	= SafeGetArrayItem2Dim($aDiscussions, $i, 'statusimageclass');
			$sStatusTooltip = str_replace('%STATUS%', $sStatus, _glt('Status: xx'));
			$bHasReplies 		= array_key_exists(("replies"), $aDiscussions[$i]);
			$sIsDisabled 		= '';
			if ($bAddDiscussions)
			{
				if ( !strIsEmpty($sSessionReviewGUID) )
				{
					$bCanReply = false;
				}
				else
				{
					$bCanReply = true;
				}
			}
			else
			{
				$bCanReply = false;
			}
			if (strIsEmpty($sReviewGUID) )
			{
				if (($bAddDiscussions && $bCanReply) || $bHasReplies)
				{
					echo '<div class="discussion-item collapsible-section-header-closed">';
					echo '<img alt="" src="images/spriteplaceholder.png" class="discussion-item-icon collapsible-section-header-closed-icon show-cursor-pointer" ' . $sExpandDiscussEvent .'>';
				}
				else
				{
					echo '<div class="discussion-item">';
					$sExpandDiscussEvent = '';
					$sIsDisabled 		=  'disabled="true"';
				}
				WriteAvatarImage($aDiscussions[$i]['avatarid'], 'false');
				echo '<div class="discussion-item-states" >';
				WriteDiscussionStatusMenus($bCanReply, $sDiscussGUID, $sPriorityImageClass, $sPriorityTooltip, $sStatusImageClass, $sStatusTooltip);
				echo '</div>';
				echo '<div class="discussion-item-text2"' . $sIsDisabled . $sExpandDiscussEvent . '><div class="discussion-item-text">' . $sDiscussText . '</div></div>';
				echo '<div class="discussion-item-text-footer">';
				echo '<div class="discussion-item-text-footer-dateauthor">' . $aDiscussions[$i]['created'] . '&nbsp; &nbsp;' . $aDiscussions[$i]['author'] . '</div>';
				echo '</div>';
				echo '<div class="discussion-item-replies" id="'.$sReplyID.'">';
				if (array_key_exists(("replies"), $aDiscussions[$i]))
				{
					$aReplies = $aDiscussions[$i]['replies'];
					$iReplyCnt = count($aReplies);
					for ($iR=0; $iR<$iReplyCnt; $iR++)
					{
						$sReplyAuthor 	= SafeGetArrayItem2Dim($aReplies, $iR, 'replyauthor');
						$sReplyAvatarID	= SafeGetArrayItem2Dim($aReplies, $iR, 'replyavatarid');
						$sReplyAvatarImage	= SafeGetArrayItem2Dim($aReplies, $iR, 'replyavatarimage');
						$sReplyCreated 	= SafeGetArrayItem2Dim($aReplies, $iR, 'replycreated');
						$sReplyText 	= SafeGetArrayItem2Dim($aReplies, $iR, 'replytext');
						echo '<div class="discussion-item-reply">';
						WriteAvatarImage($sReplyAvatarID, 'true');
						echo '<div class="discussion-item-reply-text">' . $sReplyText . '</div>';
						echo '<div class="discussion-item-reply-text-footer">';
						echo '<div class="discussion-item-reply-text-footer-dateauthor">' . $sReplyCreated . '&nbsp; &nbsp;' . $sReplyAuthor . '</div>';
						echo '</div>';
						echo '</div>';
					}
				}
				if ($bAddDiscussions)
				{
					if ($bCanReply)
					{
						echo '<div class="discussion-reply-form" id="ddrf_' . $sDiscussGUID . '"><form id="drf_' . $sDiscussGUID . '" method="post">';
						echo '<div class="discussion-reply-comment-send">';
						echo '<div class="discussion-reply-send-div">';
						echo '<input class="webea-main-styled-button discussion-reply-send-button" type="submit" value="" onclick="OnFormRunAddReply(event, this.form)">';
						echo '</div>';
						echo '<div class="discussion-reply-comment-div">';
						echo '<textarea class="discussion-reply-new-comment" name="comments" placeholder="' . _glt('Post reply') . '"></textarea>';
						echo '</div>';
						echo '</div>';
						echo '<input type="hidden" name="guid" value="' . $sDiscussGUID .'"> ';
						echo '<input type="hidden" name="author" value="' . $sAuthor . '"> ';
						echo '<input type="hidden" name="isreply" value="true"> ';
						echo '<input type="hidden" name="objectguid" value="' . $sObjectGUID . '"> ';
						echo '<input type="hidden" name="loginguid" value="' . $sLoginGUID . '">';
						echo '</form></div>';
					}
				}
				echo '</div>';
				echo '</div>';
			}
		}
		if ($bAddDiscussions)
		{
			if ( strIsEmpty($sSessionReviewGUID) )
			{
				echo '<div id="discussion-form"><form id="discussion-form1" method="post">';
				echo '<div id="discussion-comment-send">';
				echo '<div id="discussion-send-div">';
				echo '<input class="webea-main-styled-button" id="discussion-send-button" type="submit" value="" onclick="OnFormRunAddDiscussion(event)">';
				echo '</div>';
				echo '<div id="discussion-comment-div">';
				echo '<textarea class="discussion-new-comment" name="comments" placeholder="' . _glt('Create new Discussion') . '"></textarea>';
				echo '</div>';
				echo '</div>';
				echo '<input type="hidden" name="guid" value="' . $sObjectGUID . '"> ';
				echo '<input type="hidden" name="author" value="' . $sAuthor . '"> ';
				echo '<input type="hidden" name="isreply" value="false"> ';
				echo '<input type="hidden" name="loginguid" value="' . $sLoginGUID . '">';
				echo '</form></div>';
			}
			else
			{
				echo '<div class="review-new-topic-message">';
				echo _glt('General discussions cannot be added while in a review');
				echo '</div>';
			}
		}
	}
	function WriteAvatarCSS($aAvatars)
	{
		if (IsSessionSettingTrue('use_avatars'))
		{
			echo '<style>';
			foreach ($aAvatars as $aAvatar)
			{
				$sImage = str_replace("\n", '', $aAvatar['avatarimage']);
				echo '#' . 'avatarimg-' . $aAvatar['avatarid'] . ' {';
				echo 'background-image: url("data:image/png; base64,' . $sImage . '");';
				echo '}';
			}
			echo '</style>';
		}
	}
	function WriteDiscussionStatusMenus($bIsEnabled, $sDiscussGUID, $sPriorityImageClass, $sPriorityTooltip, $sStatusImageClass, $sStatusTooltip)
	{
		if ($bIsEnabled)
		{
			echo '<span id="prioritymenu-button">';
			echo '<img alt="" id="priorityimage_' . $sDiscussGUID . '" src="images/spriteplaceholder.png" class="' . $sPriorityImageClass . '" title="' . $sPriorityTooltip . '" onclick="show_discussion_state_menu(this)">&nbsp;';
			echo '<div class="prioritymenu-content" id="prioritymenu-content-' . $sDiscussGUID . '">';
			echo '<div class="contextmenu-header">' . _glt('Priority') . '</div>';
			echo '<div class="contextmenu-items">';
			echo '<div class="contextmenu-item" onclick="set_discuss_state(\''.$sDiscussGUID.'\',\'priority\',\'High\',\'' . str_replace('%PRIORITY%', _glt('High'), _glt('Priority: xx')) . '\')"><img alt="" src="images/spriteplaceholder.png" class="propsprite-discusspriorityhigh"></img>' . _glt('High') . '</div>';
			echo '<div class="contextmenu-item" onclick="set_discuss_state(\''.$sDiscussGUID.'\',\'priority\',\'Medium\',\'' . str_replace('%PRIORITY%', _glt('Medium'), _glt('Priority: xx')) . '\')"><img alt="" src="images/spriteplaceholder.png" class="propsprite-discussprioritymed"></img>' . _glt('Medium') . '</div>';
			echo '<div class="contextmenu-item" onclick="set_discuss_state(\''.$sDiscussGUID.'\',\'priority\',\'Low\',\'' . str_replace('%PRIORITY%', _glt('Low'), _glt('Priority: xx')) . '\')"><img alt="" src="images/spriteplaceholder.png" class="propsprite-discussprioritylow"></img>' . _glt('Low') . '</div>';
			echo '<hr>';
			echo '<div class="contextmenu-item" onclick="set_discuss_state(\''.$sDiscussGUID.'\',\'priority\',\'None\')"><img alt="" src="images/spriteplaceholder.png" class="propsprite-discussprioritynone"></img>' . _glt('<none>') . '</div>';
			echo '</div>';
			echo '</div>';
			echo '</span>';
			echo '<span id="statusmenu-button">';
			echo '<img alt="" id="statusimage_' . $sDiscussGUID . '" src="images/spriteplaceholder.png" class="' . $sStatusImageClass . '" title="' . $sStatusTooltip . '" onclick="show_discussion_state_menu(this)">&nbsp;';
			echo '<div class="statusmenu-content" id="statusmenu-content-' . $sDiscussGUID . '">';
			echo '<div class="contextmenu-header">' . _glt('Status') . '</div>';
			echo '<div class="contextmenu-items">';
			echo '<div class="contextmenu-item" onclick="set_discuss_state(\''.$sDiscussGUID.'\',\'status\',\'Open\',\'' . str_replace('%STATUS%', _glt('Open'), _glt('Status: xx')) . '\')"><img alt="" src="images/spriteplaceholder.png" class="propsprite-discussstatusopen"></img>' . _glt('Open') . '</div>';
			echo '<div class="contextmenu-item" onclick="set_discuss_state(\''.$sDiscussGUID.'\',\'status\',\'Awaiting Review\',\'' . str_replace('%STATUS%', _glt('Awaiting Review'), _glt('Status: xx')) . '\')"><img alt="" src="images/spriteplaceholder.png" class="propsprite-discussstatusawait"></img>' . _glt('Awaiting Review') . '</div>';
			echo '<div class="contextmenu-item" onclick="set_discuss_state(\''.$sDiscussGUID.'\',\'status\',\'Closed\',\'' . str_replace('%STATUS%', _glt('Closed'), _glt('Status: xx')) . '\')"><img alt="" src="images/spriteplaceholder.png" class="propsprite-discussstatuscomplete"></img>' . _glt('Closed') . '</div>';
			echo '</div>';
			echo '</div>';
			echo '</span>';
		}
		else
		{
			echo '<span id="prioritymenu-button" disabled="true">';
			echo '<img alt="" id="priorityimage_' . $sDiscussGUID . '" src="images/spriteplaceholder.png" class="' . $sPriorityImageClass . '" title="' . $sPriorityTooltip . '">&nbsp;';
			echo '</span>';
			echo '<span id="statusmenu-button" disabled="true">';
			echo '<img alt="" id="statusimage_' . $sDiscussGUID . '" src="images/spriteplaceholder.png" class="' . $sStatusImageClass . '" title="' . $sStatusTooltip . '">&nbsp;';
			echo '</span>';
		}
	}
?>