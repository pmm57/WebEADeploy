<?php
// --------------------------------------------------------
//  This is a part of the Sparx Systems Pro Cloud Server.
//  Copyright (C) Sparx Systems Pty Ltd
//  All rights reserved.
//
//  This source code can be used only under terms and 
//  conditions of the accompanying license agreement.
// --------------------------------------------------------
	$sRootPath = dirname(__FILE__);
	require_once $sRootPath . '/globals.php';
	SafeStartSession();
	if (isset($_SESSION['authorized']) === false)
	{
		echo '<div id="main-content-empty">' . _glt('Your session appears to have timed out') . '</div>';
		setResponseCode(440);
		exit();
	}
	$sObjectGUIDEnc = SafeGetInternalArrayParameter($_POST, 'objectguid');
	$sObjectGUID 	= urldecode($sObjectGUIDEnc);
	$sResType 		= GetResTypeFromGUID($sObjectGUID);
	$aDiscussions 	= array();
	include('./data_api/get_discussions.php');
	$sOSLCErrorMsg = BuildOSLCErrorString();
	if ( strIsEmpty($sOSLCErrorMsg) )
	{
		include('./propertiesdiscussions.php');
	}
	else
	{
		echo 'error: ' . $sOSLCErrorMsg;
	}
?>