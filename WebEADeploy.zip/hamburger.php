<?php
// --------------------------------------------------------
//  This is a part of the Sparx Systems Pro Cloud Server.
//  Copyright (C) Sparx Systems Pty Ltd
//  All rights reserved.
//
//  This source code can be used only under terms and 
//  conditions of the accompanying license agreement.
// --------------------------------------------------------
	echo '<div class="header-buttons">';
	echo '  <div class="search-dropdown">';
	echo '	  <div id="search-button" title=""><div><div class="mainsprite-search32white">&#160;</div></div></div>';
	echo '	  <div id="search-menu">';
	echo '	    <div class="hamburger-contextmenu-arrow-bottom"></div><div class="hamburger-contextmenu-arrow-top"></div>';
	echo '	    <div class="contextmenu-content">';
	echo '		  <div class="contextmenu-header">' . _glt('Search') . '</div>';
	echo '		  <div class="contextmenu-items">';
	$iDays = SafeGetArrayItem1DimInt($_SESSION, 'recent_search_days');
	if ( $iDays == 0 )
	{
		$iDays = 3;
	}
	$sDays = (string)$iDays;
	echo '			<div class="contextmenu-item" onclick="OnPromptForGotoGUID()"><img alt="" src="images/spriteplaceholder.png" class="mainsprite-gotolink">' . _glt('Goto item') . '</div>';
	echo '			<hr>';
	echo '			<div class="contextmenu-item" onclick="OnRunPrefinedSearch(\'category=review&term=&recent=-' . $sDays. 'd\',\'' . _glt('Search Results') . '\')"><img alt="" title="' . _glt('Display list of recent reviews') . '" src="images/spriteplaceholder.png" class="mainsprite-recentreview">' . _glt('Reviews') . '</div>';
	echo '			<div class="contextmenu-item" onclick="OnRunPrefinedSearch(\'category=discussion&term=&recent=-' . $sDays. 'd\',\'' . _glt('Search Results') . '\')"><img alt="" title="' . _glt('Display list of discussions') . '" src="images/spriteplaceholder.png" class="mainsprite-recentdiscuss">' . _glt('Discussions') . '</div>';
	echo '			<hr>';
	echo '			<div class="contextmenu-item" onclick="OnRunPrefinedSearch(\'category=diagram&term=&recent=-' . $sDays. 'd\',\'' . _glt('Search Results') . '\')"><img alt="" title="' . _glt('Display list of recently modified diagrams') . '" src="images/spriteplaceholder.png" class="mainsprite-recentdiagram">' . _glt('Diagrams') . '</div>';
	echo '			<div class="contextmenu-item" onclick="OnRunPrefinedSearch(\'category=element&term=&recent=-' . $sDays. 'd\',\'' . _glt('Search Results') . '\')"><img alt="" title="' . _glt('Display list of recently modified elements') . '" src="images/spriteplaceholder.png" class="mainsprite-recentelement">' . _glt('Elements') . '</div>';
	echo '			<div class="contextmenu-item" onclick="load_object(\'watchlist\',\'\',\'\',\'\',\'' . _glt('Watchlist') . '\',\'images/element16/watchlist.png\')"><img alt="" src="images/spriteplaceholder.png" class="mainsprite-watchlist16color">' . _glt('Watchlist') . '</div>';
	echo '			<hr>';
	echo '			<div class="contextmenu-item" onclick="load_object(\'search\',\'\',\'\',\'\',\'' . _glt('Search') . '\',\'images/element16/search.png\')"><img alt="" src="images/spriteplaceholder.png" class="mainsprite-search16color">' . _glt('Custom search') . '</div>';
	echo '		  </div>';
	echo '		</div>';
	echo '	  </div>';
	echo '	</div>';
	$sMainLayoutNo = SafeGetInternalArrayParameter($_SESSION, 'mainlayout', '1');
	$sShowRadioIcons = 'class="hamburger-radio-icon"';
	$sShowRadioList = '';
	$sShowRadioNotes = '';
	if ($sMainLayoutNo === '2')
	{
		$sShowRadioIcons = '';
		$sShowRadioList = 'class="hamburger-radio-icon"';
	}
	elseif ($sMainLayoutNo === '3')
	{
		$sShowRadioIcons = '';
		$sShowRadioNotes = 'class="hamburger-radio-icon"';
	}
	echo '  <div class="hamburger-dropdown">';
	echo '	  <div id="hamburger-button" title=""><div><div class="mainsprite-hamburger32white">&#160;</div></div></div>';
	echo '	  <div id="hamburger-menu">';
	echo '	    <div class="hamburger-contextmenu-arrow-bottom"></div><div class="hamburger-contextmenu-arrow-top"></div>';
	echo '	    <div class="contextmenu-content">';
	echo '        <div class="contextmenu-header">' . _glt('Menu') . '</div>';
	echo '        <div class="contextmenu-items">';
	echo '          <div id="contextmenu-package">';
	echo '            <div class="contextmenu-items-hdr">' . _glt('Package Layout') . '</div>';
	echo '            <div class="contextmenu-item-inner">';
	echo '              <div class="contextmenu-item" onclick="set_main_layout(\'1\')"><div id="main-layout-icons" '.$sShowRadioIcons.'><div id="hamburger-iconview-icon"><div class="hamburger-item-text">' . _glt('Icon view') . '</div></div></div></div>';
	echo '              <div class="contextmenu-item" onclick="set_main_layout(\'2\')"><div id="main-layout-list" '.$sShowRadioList.'><div id="hamburger-listview-icon"><div class="hamburger-item-text">' . _glt('List view') . '</div></div></div></div>';
	echo '              <div class="contextmenu-item" onclick="set_main_layout(\'3\')"><div id="main-layout-notes" '.$sShowRadioNotes.'><div id="hamburger-notesview-icon"><div class="hamburger-item-text">' . _glt('Notes view') . '</div></div></div></div>';
	echo '            </div>';
	echo '	        </div>';
	echo '	        <div id="contextmenu-properties">';
	echo '	          <div class="contextmenu-items-hdr">' . _glt('Properties') . '</div>';
	echo ' 	          <div class="contextmenu-item-inner">';
	echo '	            <div class="contextmenu-item" onclick="set_property_layout(\'1\')"><div id="prop-layout-wide" class="prop-layout-wide-disabled"><div id="hamburger-layout-wide-icon"><div class="hamburger-item-text">' . _glt('Wide view') . '</div></div></div></div>';
	echo '	            <div class="contextmenu-item" onclick="set_property_layout(\'2\')"><div id="prop-layout-split" class="prop-layout-split-enabled"><div id="hamburger-layout-split-icon"><div class="hamburger-item-text">' . _glt('Split view') . '</div></div></div></div>';
	echo '	          </div>';
	echo '	        </div>';
	echo '	        <hr>';
	echo '	        <div id="contextmenu-logout">';
	echo '	          <div class="contextmenu-item" onclick="OnLogoff(this)"><div id="hamburger-logout-icon"><div class="hamburger-item-text">' . _glt('Logout') . '</div></div></div>';
	echo '	        </div>';
	echo '	      </div>';
	echo '	    </div>';
	echo '    </div>';
	echo '  </div>';
	echo '</div>';
?>
<script>
	$(document).ready( function ()
	{
		$(".contextmenu-item").click(function()
		{
			$("#search-menu").hide();
			$("#hamburger-menu").hide();
		});
		$('#search-button').click(function()
		{
			$('#search-menu').toggle();
		});
		$('#hamburger-button').click(function()
		{
			$('#hamburger-menu').toggle();
		});
	});
	$(document).mouseup(function (e)
	{
		hide_menu(e,"#hamburger-button","#hamburger-menu");
		hide_menu(e,"#search-button","#search-menu");
		hide_menu(e,"#navbar-hamburger-button","#navbar-hamburger-menu");
		hide_menu(e,"#navbar-search-button","#navbar-search-menu");
	});
</script>