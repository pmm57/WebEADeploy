<?php
// --------------------------------------------------------
//  This is a part of the Sparx Systems Pro Cloud Server.
//  Copyright (C) Sparx Systems Pty Ltd
//  All rights reserved.
//
//  This source code can be used only under terms and 
//  conditions of the accompanying license agreement.
// --------------------------------------------------------
	require_once 'globals.php';
	SafeStartSession();
	if (isset($_SESSION['authorized']) === false)
	{
		echo '<div id="main-content-empty">' . _glt('Your session appears to have timed out') . '</div>';
		setResponseCode(440);
		exit();
	}
	if ($_SERVER["REQUEST_METHOD"] !== "POST")
	{
		setResponseCode(405);
		exit();
	}
	$sHTMLDoc = '';
	include('./data_api/get_linkeddoc.php');
	if (strIsEmpty($sHTMLDoc))
	{
		echo '<div class="linked-document-section-empty">' . _glt('No content') . '</div>';
	}
	else
	{
		$sHTMLDoc = trim($sHTMLDoc);
		if ( substr($sHTMLDoc, 0, 9) === '<![CDATA[' )
			$sHTMLDoc = substr($sHTMLDoc, 9);
		if ( substr($sHTMLDoc, -3) === ']]>' )
			$sHTMLDoc = substr($sHTMLDoc, 0, -3);
		$sHTMLDoc = ConvertHyperlinksInLinkedDoc($sHTMLDoc);
		echo '<div class="linked-document-section">';
		echo '<div class="linked-document">' . $sHTMLDoc . '</div>';
		echo '</div>' . PHP_EOL;
	}
?>