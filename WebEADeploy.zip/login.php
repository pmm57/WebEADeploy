<!DOCTYPE html>
<html>
<head>
	<title>Web EA - login</title>
	<meta http-equiv="content-type" content="text/html; charset=utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link type="text/css" rel="stylesheet" href="styles/webea.css"/>
	<script type="text/javascript" src="js/jquery.min.js"></script>
	<script type="text/javascript" src="js/webea.js"></script>
</head>
<body>
<?php
// --------------------------------------------------------
//  This is a part of the Sparx Systems Pro Cloud Server.
//  Copyright (C) Sparx Systems Pty Ltd
//  All rights reserved.
//
//  This source code can be used only under terms and 
//  conditions of the accompanying license agreement.
// --------------------------------------------------------
	error_reporting(E_ERROR | E_WARNING | E_NOTICE);
	require_once 'globals.php';
?>
	<div id="main-tl-swoosh"><img src="images/spriteplaceholder.png" class="mainsprite-procloudswoosh" alt=""/></div>
	<header>
		<img src="images/spriteplaceholder.png" class="mainsprite-logo-full" alt="" align="left"/>
	</header>
<?php
		$aSettings = ParseINIFile2Array('includes/webea_config.ini');
		include ('nojs.php');
		$sErrorMsg 			= '';
		$sModelName			= '';
		$sModelNo			= '';
		$sAuthType			= '';
		$sAccessCode		= '';
		$sModelFriendlyName = '';
		$sUserID 			= '';
		$sPassword			= '';
		$sCurrentStep 		= 'prompt_model';
		$sShowAccessCode 	= '1';
		$sShowLoginFields 	= '1';
		$sShowInsecureWarning = '1';
		$sTestConnection 	= '0';
		$sAllowBlankPwd		= '0';
		$sAutoLoadModel		= SafeGetInternalArrayParameter($_GET, 'm', '');
		$sAutoLoadObject	= SafeGetInternalArrayParameter($_GET, 'o', '');
		echo '<div id="main-page-overlay">&nbsp;</div>';
		SafeStartSession();
		if ( isset($_SESSION['authorized']) && isset($_SESSION['model_no']) )
		{
			$sURLLocation = 'location: index.php';
			$sURLParameters = '';
			if ( !strIsEmpty($sAutoLoadModel) )
			{
				$sURLParameters .= 'm=' . $sAutoLoadModel;
			}
			if ( !strIsEmpty($sAutoLoadObject) )
			{
				if ( !strIsEmpty($sURLParameters) )
					$sURLParameters .= '&';
				$sURLParameters .= 'o=' . $sAutoLoadObject;
			}
			if ( !strIsEmpty($sURLParameters) )
			{
				$sURLLocation .= '?' . $sURLParameters;
			}
			header($sURLLocation);
			exit();
		}
		if ($_SERVER["REQUEST_METHOD"] === "POST")
		{
			$sModelName		= SafeGetInternalArrayParameter($_POST, 'modelname', '');
			$sModelNo		= SafeGetInternalArrayParameter($_POST, 'modelnumber', '');
			$sAuthType		= SafeGetInternalArrayParameter($_POST, 'auth-type', '');
			$sAccessCode	= md5(SafeGetInternalArrayParameter($_POST, 'access-code', ''));
			$sModelFriendlyName	= SafeGetInternalArrayParameter($_POST, 'modelfriendlyname', '');
			$sUserID 		= SafeGetInternalArrayParameter($_POST, 'userid');
			$sPassword		= SafeGetInternalArrayParameter($_POST, 'password');
			$sCurrentStep	= SafeGetInternalArrayParameter($_POST, 'step', 'prompt_model');
			$sShowAccessCode = SafeGetInternalArrayParameter($_POST, 'showaccesscode', '1');
			$sShowLoginFields = SafeGetInternalArrayParameter($_POST, 'showloginfields', '1');
			$sShowInsecureWarning = SafeGetInternalArrayParameter($_POST, 'showinsecurewarning', '1');
			$sTestConnection = SafeGetInternalArrayParameter($_POST, 'testconnection', '0');
			$sAllowBlankPwd	=  SafeGetInternalArrayParameter($_POST, 'allowblankpwd', '0');
			if ( strIsEmpty($sAutoLoadModel) )
			{
				$sAutoLoadModel		= SafeGetInternalArrayParameter($_POST, 'autoloadmodel', '');
			}
			if ( strIsEmpty($sAutoLoadObject) )
			{
				$sAutoLoadObject	= SafeGetInternalArrayParameter($_POST, 'autoloadobject', '');
			}
			if ( !strIsEmpty($sModelName) )
			{
				if (isset($aSettings['model_list']))
				{
					$sModelNameInConfig = $sModelName;
					if ( !strIsEmpty($sModelNameInConfig) )
					{
						$sAccessCodeFromConfig = $aSettings[$sModelNameInConfig]['auth_code'];
						if ($sAccessCode === $sAccessCodeFromConfig || $sAccessCodeFromConfig === md5(''))
						{
							SafeStartSession();
							$_SESSION['model_name']				= $sModelFriendlyName;
							$_SESSION['model_no']				= $sModelNo;
							$_SESSION['protocol'] 				= SafeGetArrayItem2DimByName($aSettings, $sModelNameInConfig, 'sscs_protocol', 'http');
							$_SESSION['server'] 				= SafeGetArrayItem2DimByName($aSettings, $sModelNameInConfig, 'sscs_server', 'localhost');
							$_SESSION['port'] 					= SafeGetArrayItem2DimByName($aSettings, $sModelNameInConfig, 'sscs_port', '80');
							$_SESSION['db_alias']				= SafeGetArrayItem2DimByName($aSettings, $sModelNameInConfig, 'sscs_db_alias', 'ea');
							$_SESSION['use_ssl']				= SafeGetArrayItem2DimByName($aSettings, $sModelNameInConfig, 'sscs_use_ssl', 'false');
							$_SESSION['enforce_certs']	 		= SafeGetArrayItem2DimByName($aSettings, $sModelNameInConfig, 'sscs_enforce_certs', 'true');
							$_SESSION['model_user']				= SafeGetArrayItem2DimByName($aSettings, $sModelNameInConfig, 'sscs_model_user', '');
							$_SESSION['model_pwd']				= SafeGetArrayItem2DimByName($aSettings, $sModelNameInConfig, 'sscs_model_pwd', '');
							$_SESSION['eao_access_code']		= SafeGetArrayItem2DimByName($aSettings, $sModelNameInConfig, 'sscs_access_code', '');
							include('./data_api/validate_login.php');
							if ( strIsEmpty($sErrorMsg) )
							{
								$_SESSION['authorized']				= 'true';
								$_SESSION['auth_code']				= SafeGetArrayItem2DimByName($aSettings, $sModelNameInConfig, 'auth_code', '');
								$_SESSION['login_prompt']			= SafeGetArrayItem2DimByName($aSettings, $sModelNameInConfig, 'login_prompt', 'false');
								$_SESSION['login_allow_blank_pwd']	= SafeGetArrayItem2DimByName($aSettings, $sModelNameInConfig, 'login_allow_blank_pwd', 'false');
								$_SESSION['default_diagram']		= SafeGetArrayItem2DimByName($aSettings, $sModelNameInConfig, 'default_diagram', '');
								$_SESSION['participate_in_reviews']	= SafeGetArrayItem2DimByName($aSettings, $sModelNameInConfig, 'participate_in_reviews', 'false');
								$_SESSION['recent_search_days']		= SafeGetArrayItem2DimByName($aSettings, $sModelNameInConfig, 'recent_search_days', '3');
								$_SESSION['use_avatars']			= (IsSessionSettingTrue('security_enabled_model')?SafeGetArrayItem2DimByName($aSettings, $sModelNameInConfig, 'use_avatars', 'true') : 'false');
								$sMainLayout						= SafeGetArrayItem2DimByName($aSettings, $sModelNameInConfig, 'default_main_layout', 'icon');
								$sMainLayout						= mb_strtolower($sMainLayout);
								$_SESSION['mainlayout']				= ($sMainLayout==='notes' ? '3' : ($sMainLayout==='list' ? '2' : '1'));
								$_SESSION['diagramlayout']			= '1';
								$_SESSION['prop_visible_location']  = strIsTrue(SafeGetArrayItem2DimByName($aSettings, $sModelNameInConfig, 'prop_sec_location_visible', 'true')) ? '1' : '0';
								$_SESSION['prop_visible_relationships'] = strIsTrue(SafeGetArrayItem2DimByName($aSettings, $sModelNameInConfig, 'prop_sec_relationships_visible', 'true')) ? '1' : '0';
								$_SESSION['prop_visible_taggedvalues'] = strIsTrue(SafeGetArrayItem2DimByName($aSettings, $sModelNameInConfig, 'prop_sec_taggedvalues_visible', 'true')) ? '1' : '0';
								$_SESSION['prop_visible_testing'] 	= strIsTrue(SafeGetArrayItem2DimByName($aSettings, $sModelNameInConfig, 'prop_sec_testing_visible', 'true')) ? '1' : '0';
								$_SESSION['prop_visible_resourcealloc'] = strIsTrue(SafeGetArrayItem2DimByName($aSettings, $sModelNameInConfig, 'prop_sec_resourcealloc_visible', 'true')) ? '1' : '0';
								$_SESSION['prop_visible_attributes'] = strIsTrue(SafeGetArrayItem2DimByName($aSettings, $sModelNameInConfig, 'prop_sec_attribute_visible', 'true')) ? '1' : '0';
								$_SESSION['prop_visible_operations'] = strIsTrue(SafeGetArrayItem2DimByName($aSettings, $sModelNameInConfig, 'prop_sec_operation_visible', 'true')) ? '1' : '0';
								$_SESSION['prop_visible_runstates'] = strIsTrue(SafeGetArrayItem2DimByName($aSettings, $sModelNameInConfig, 'prop_sec_runstates_visible', 'true')) ? '1' : '0';
								$_SESSION['prop_visible_changes'] 	= strIsTrue(SafeGetArrayItem2DimByName($aSettings, $sModelNameInConfig, 'prop_sec_changes_visible', 'true')) ? '1' : '0';
								$_SESSION['prop_visible_defects'] 	= strIsTrue(SafeGetArrayItem2DimByName($aSettings, $sModelNameInConfig, 'prop_sec_defects_visible', 'true')) ? '1' : '0';
								$_SESSION['prop_visible_issues'] 	= strIsTrue(SafeGetArrayItem2DimByName($aSettings, $sModelNameInConfig, 'prop_sec_issues_visible', 'true')) ? '1' : '0';
								$_SESSION['prop_visible_tasks'] 	= strIsTrue(SafeGetArrayItem2DimByName($aSettings, $sModelNameInConfig, 'prop_sec_tasks_visible', 'true')) ? '1' : '0';
								$_SESSION['prop_visible_events'] 	= strIsTrue(SafeGetArrayItem2DimByName($aSettings, $sModelNameInConfig, 'prop_sec_events_visible', 'true')) ? '1' : '0';
								$_SESSION['prop_visible_decisions'] = strIsTrue(SafeGetArrayItem2DimByName($aSettings, $sModelNameInConfig, 'prop_sec_decisions_visible', 'true')) ? '1' : '0';
								$_SESSION['prop_visible_efforts'] 	= strIsTrue(SafeGetArrayItem2DimByName($aSettings, $sModelNameInConfig, 'prop_sec_efforts_visible', 'true')) ? '1' : '0';
								$_SESSION['prop_visible_risks'] 	= strIsTrue(SafeGetArrayItem2DimByName($aSettings, $sModelNameInConfig, 'prop_sec_risks_visible', 'true')) ? '1' : '0';
								$_SESSION['prop_visible_metrics'] 	= strIsTrue(SafeGetArrayItem2DimByName($aSettings, $sModelNameInConfig, 'prop_sec_metrics_visible', 'true')) ? '1' : '0';
								$_SESSION['prop_expanded_info'] 	= strIsTrue(SafeGetArrayItem2DimByName($aSettings, $sModelNameInConfig, 'prop_sec_properties_expanded', 'true')) ? '1' : '0';
								$_SESSION['prop_expanded_location'] = strIsTrue(SafeGetArrayItem2DimByName($aSettings, $sModelNameInConfig, 'prop_sec_location_expanded', 'true')) ? '1' : '0';
								$_SESSION['prop_expanded_relationships'] = strIsTrue(SafeGetArrayItem2DimByName($aSettings, $sModelNameInConfig, 'prop_sec_relationships_expanded', 'false')) ? '1' : '0';
								$_SESSION['prop_expanded_taggedvalues'] = strIsTrue(SafeGetArrayItem2DimByName($aSettings, $sModelNameInConfig, 'prop_sec_taggedvalues_expanded', 'false')) ? '1' : '0';
								$_SESSION['prop_expanded_testing'] 	= strIsTrue(SafeGetArrayItem2DimByName($aSettings, $sModelNameInConfig, 'prop_sec_testing_expanded', 'false')) ? '1' : '0';
								$_SESSION['prop_expanded_resourcealloc'] = strIsTrue(SafeGetArrayItem2DimByName($aSettings, $sModelNameInConfig, 'prop_sec_resourcealloc_expanded', 'false')) ? '1' : '0';
								$_SESSION['prop_expanded_attributes'] = strIsTrue(SafeGetArrayItem2DimByName($aSettings, $sModelNameInConfig, 'prop_sec_attribute_expanded', 'false')) ? '1' : '0';
								$_SESSION['prop_expanded_operations'] = strIsTrue(SafeGetArrayItem2DimByName($aSettings, $sModelNameInConfig, 'prop_sec_operation_expanded', 'false')) ? '1' : '0';
								$_SESSION['prop_expanded_runstates']= strIsTrue(SafeGetArrayItem2DimByName($aSettings, $sModelNameInConfig, 'prop_sec_runstates_expanded', 'false')) ? '1' : '0';
								$_SESSION['prop_expanded_changes'] 	= strIsTrue(SafeGetArrayItem2DimByName($aSettings, $sModelNameInConfig, 'prop_sec_changes_expanded', 'false')) ? '1' : '0';
								$_SESSION['prop_expanded_defects'] 	= strIsTrue(SafeGetArrayItem2DimByName($aSettings, $sModelNameInConfig, 'prop_sec_defects_expanded', 'false')) ? '1' : '0';
								$_SESSION['prop_expanded_issues'] 	= strIsTrue(SafeGetArrayItem2DimByName($aSettings, $sModelNameInConfig, 'prop_sec_issues_expanded', 'false')) ? '1' : '0';
								$_SESSION['prop_expanded_tasks'] 	= strIsTrue(SafeGetArrayItem2DimByName($aSettings, $sModelNameInConfig, 'prop_sec_tasks_expanded', 'false')) ? '1' : '0';
								$_SESSION['prop_expanded_events'] 	= strIsTrue(SafeGetArrayItem2DimByName($aSettings, $sModelNameInConfig, 'prop_sec_events_expanded', 'false')) ? '1' : '0';
								$_SESSION['prop_expanded_decisions']= strIsTrue(SafeGetArrayItem2DimByName($aSettings, $sModelNameInConfig, 'prop_sec_decisions_expanded', 'false')) ? '1' : '0';
								$_SESSION['prop_expanded_efforts'] 	= strIsTrue(SafeGetArrayItem2DimByName($aSettings, $sModelNameInConfig, 'prop_sec_efforts_expanded', 'false')) ? '1' : '0';
								$_SESSION['prop_expanded_risks'] 	= strIsTrue(SafeGetArrayItem2DimByName($aSettings, $sModelNameInConfig, 'prop_sec_risks_expanded', 'false')) ? '1' : '0';
								$_SESSION['prop_expanded_metrics'] 	= strIsTrue(SafeGetArrayItem2DimByName($aSettings, $sModelNameInConfig, 'prop_sec_metrics_expanded', 'false')) ? '1' : '0';
								$_SESSION['show_discuss']			= SafeGetArrayItem2DimByName($aSettings, $sModelNameInConfig, 'show_discuss', 'false');
								$_SESSION['add_discuss']			= (IsSessionSettingTrue('show_discuss')?SafeGetArrayItem2DimByName($aSettings, $sModelNameInConfig, 'add_discuss', 'false'):'false');
								$_SESSION['add_objects']			= SafeGetArrayItem2DimByName($aSettings, $sModelNameInConfig, 'add_objects', 'false');
								$_SESSION['add_diagrams']			= SafeGetArrayItem2DimByName($aSettings, $sModelNameInConfig, 'add_diagrams', 'false');
								$_SESSION['edit_diagrams']			= SafeGetArrayItem2DimByName($aSettings, $sModelNameInConfig, 'edit_diagrams', 'false');
								$_SESSION['edit_object_notes']		= SafeGetArrayItem2DimByName($aSettings, $sModelNameInConfig, 'edit_object_notes', 'false');
								$_SESSION['add_objecttype_package']	= SafeGetArrayItem2DimByName($aSettings, $sModelNameInConfig, 'add_objecttype_package', 'false');
								$_SESSION['add_objecttype_review']	= SafeGetArrayItem2DimByName($aSettings, $sModelNameInConfig, 'add_objecttype_review', 'false');
								$_SESSION['add_objecttype_actor']	= SafeGetArrayItem2DimByName($aSettings, $sModelNameInConfig, 'add_objecttype_actor', 'false');
								$_SESSION['add_objecttype_change']	= SafeGetArrayItem2DimByName($aSettings, $sModelNameInConfig, 'add_objecttype_change', 'false');
								$_SESSION['add_objecttype_component'] = SafeGetArrayItem2DimByName($aSettings, $sModelNameInConfig, 'add_objecttype_component', 'false');
								$_SESSION['add_objecttype_feature']	= SafeGetArrayItem2DimByName($aSettings, $sModelNameInConfig, 'add_objecttype_feature', 'false');
								$_SESSION['add_objecttype_issue']	= SafeGetArrayItem2DimByName($aSettings, $sModelNameInConfig, 'add_objecttype_issue', 'false');
								$_SESSION['add_objecttype_node']	= SafeGetArrayItem2DimByName($aSettings, $sModelNameInConfig, 'add_objecttype_node', 'false');
								$_SESSION['add_objecttype_requirement']= SafeGetArrayItem2DimByName($aSettings, $sModelNameInConfig, 'add_objecttype_requirement', 'false');
								$_SESSION['add_objecttype_task']	= SafeGetArrayItem2DimByName($aSettings, $sModelNameInConfig, 'add_objecttype_task', 'false');
								$_SESSION['add_objecttype_usecase']	= SafeGetArrayItem2DimByName($aSettings, $sModelNameInConfig, 'add_objecttype_usecase', 'false');
								$_SESSION['add_object_features']	= SafeGetArrayItem2DimByName($aSettings, $sModelNameInConfig, 'add_object_features', 'false');
								$_SESSION['add_objectfeature_tests'] = (IsSessionSettingTrue('add_object_features')?SafeGetArrayItem2DimByName($aSettings, $sModelNameInConfig, 'add_objectfeature_tests', 'false'):'false');
								$_SESSION['add_objectfeature_resources'] = (IsSessionSettingTrue('add_object_features')?SafeGetArrayItem2DimByName($aSettings, $sModelNameInConfig, 'add_objectfeature_resources', 'false'):'false');
								$_SESSION['add_objectfeature_changes'] = (IsSessionSettingTrue('add_object_features')?SafeGetArrayItem2DimByName($aSettings, $sModelNameInConfig, 'add_objectfeature_changes', 'false'):'false');
								$_SESSION['add_objectfeature_defects'] = (IsSessionSettingTrue('add_object_features')?SafeGetArrayItem2DimByName($aSettings, $sModelNameInConfig, 'add_objectfeature_defects', 'false'):'false');
								$_SESSION['add_objectfeature_issues'] = (IsSessionSettingTrue('add_object_features')?SafeGetArrayItem2DimByName($aSettings, $sModelNameInConfig, 'add_objectfeature_issues', 'false'):'false');
								$_SESSION['add_objectfeature_tasks'] = (IsSessionSettingTrue('add_object_features')?SafeGetArrayItem2DimByName($aSettings, $sModelNameInConfig, 'add_objectfeature_tasks', 'false'):'false');
								$_SESSION['add_objectfeature_risks'] = (IsSessionSettingTrue('add_object_features')?SafeGetArrayItem2DimByName($aSettings, $sModelNameInConfig, 'add_objectfeature_risks', 'false'):'false');
								$_SESSION['edit_objectfeature_tests'] = SafeGetArrayItem2DimByName($aSettings, $sModelNameInConfig, 'edit_objectfeature_tests', 'false');
								$_SESSION['edit_objectfeature_resources'] = SafeGetArrayItem2DimByName($aSettings, $sModelNameInConfig, 'edit_objectfeature_resources', 'false');
								if ( IsSessionSettingTrue('readonly_model') || !IsSessionSettingTrue('valid_license'))
								{
									$sReason = 'read-only';
									if ( IsSessionSettingTrue('readonly_model') && !IsSessionSettingTrue('valid_license') )
										$sReason = 'read-only and invalid license';
									elseif ( !IsSessionSettingTrue('valid_license') )
										$sReason = 'invalid license';
									$gLog->Write2Log( $sModelName . ' is ' . $sReason . ', overriding edit options.' );
									$_SESSION['add_discuss']			= 'false';
									$_SESSION['add_objects']			= 'false';
									$_SESSION['edit_object_notes']		= 'false';
									$_SESSION['add_object_features']	= 'false';
									$_SESSION['add_objectfeature_tests'] = 'false';
									$_SESSION['add_objectfeature_resources'] = 'false';
									$_SESSION['add_objectfeature_changes'] = 'false';
									$_SESSION['add_objectfeature_defects'] = 'false';
									$_SESSION['add_objectfeature_issues'] = 'false';
									$_SESSION['add_objectfeature_tasks'] = 'false';
									$_SESSION['add_objectfeature_risks'] = 'false';
									$_SESSION['edit_objectfeature_tests'] = 'false';
									$_SESSION['edit_objectfeature_resources'] = 'false';
								}
								if ( $_SESSION['pro_cloud_license'] === 'Express' )
								{
									$gLog->Write2Log( $sModelName . ' is connected via Express edition, overriding edit options.' );
									$_SESSION['add_objects']			= 'false';
									$_SESSION['add_object_features']	= 'false';
									$_SESSION['add_objectfeature_tests'] = 'false';
									$_SESSION['add_objectfeature_resources'] = 'false';
									$_SESSION['add_objectfeature_changes'] = 'false';
									$_SESSION['add_objectfeature_defects'] = 'false';
									$_SESSION['add_objectfeature_issues'] = 'false';
									$_SESSION['add_objectfeature_tasks'] = 'false';
									$_SESSION['add_objectfeature_risks'] = 'false';
								}
								$_SESSION['cookie_retention']		= SafeGetArrayItem2DimByName($aSettings, $sModelNameInConfig, 'cookie_retention', '365');
								$sWLPeriod			= SafeGetArrayItem2DimByName($aSettings, $sModelNameInConfig, 'wl_period', '0');
								$sWatchListOptions = ';';
								$sWatchListOptions .= 'period=' . strval((int)$sWLPeriod) . ';';
								$sWatchListOptions .= strIsTrue(SafeGetArrayItem2DimByName($aSettings, $sModelNameInConfig, 'wl_recent_discuss', 'false')) ? 'recentdiscuss=1;' : 'recentdiscuss=0;';
								$sWatchListOptions .= strIsTrue(SafeGetArrayItem2DimByName($aSettings, $sModelNameInConfig, 'wl_recent_reviews', 'false')) ? 'recentreview=1;' : 'recentreview=0;';
								$sWatchListOptions .= strIsTrue(SafeGetArrayItem2DimByName($aSettings, $sModelNameInConfig, 'wl_recent_diagram', 'false')) ? 'recentdiag=1;' : 'recentdiag=0;';
								$sWatchListOptions .= strIsTrue(SafeGetArrayItem2DimByName($aSettings, $sModelNameInConfig, 'wl_recent_element', 'false')) ? 'recentelem=1;' : 'recentelem=0;';
								$sWatchListOptions .= strIsTrue(SafeGetArrayItem2DimByName($aSettings, $sModelNameInConfig, 'wl_resalloc_active', 'false')) ? 'resallocactive=1;' : 'resallocactive=0;';
								$sWatchListOptions .= strIsTrue(SafeGetArrayItem2DimByName($aSettings, $sModelNameInConfig, 'wl_resalloc_today', 'false')) ? 'resalloctoday=1;' : 'resalloctoday=0;';
								$sWatchListOptions .= strIsTrue(SafeGetArrayItem2DimByName($aSettings, $sModelNameInConfig, 'wl_resalloc_overdue', 'false')) ? 'resallocoverdue=1;' : 'resallocoverdue=0;';
								$sWatchListOptions .= strIsTrue(SafeGetArrayItem2DimByName($aSettings, $sModelNameInConfig, 'wl_test_recentpass', 'false')) ? 'testrecentpass=1;' : 'testrecentpass=0;';
								$sWatchListOptions .= strIsTrue(SafeGetArrayItem2DimByName($aSettings, $sModelNameInConfig, 'wl_test_recentfail', 'false')) ? 'testrecentfail=1;' : 'testrecentfail=0;';
								$sWatchListOptions .= strIsTrue(SafeGetArrayItem2DimByName($aSettings, $sModelNameInConfig, 'wl_test_recentdefer', 'false')) ? 'testrecentdefer=1;' : 'testrecentdefer=0;';
								$sWatchListOptions .= strIsTrue(SafeGetArrayItem2DimByName($aSettings, $sModelNameInConfig, 'wl_test_recentnotchk', 'false')) ? 'testrecentnotchk=1;' : 'testrecentnotchk=0;';
								$sWatchListOptions .= strIsTrue(SafeGetArrayItem2DimByName($aSettings, $sModelNameInConfig, 'wl_test_notrun', 'false')) ? 'testnotrun=1;' : 'testnotrun=0;';
								$sWatchListOptions .= strIsTrue(SafeGetArrayItem2DimByName($aSettings, $sModelNameInConfig, 'wl_change_verified', 'false')) ? 'changeverified=1;' : 'changeverified=0;';
								$sWatchListOptions .= strIsTrue(SafeGetArrayItem2DimByName($aSettings, $sModelNameInConfig, 'wl_change_requested', 'false')) ? 'changerequested=1;' : 'changerequested=0;';
								$sWatchListOptions .= strIsTrue(SafeGetArrayItem2DimByName($aSettings, $sModelNameInConfig, 'wl_change_completed', 'false')) ? 'changecompleted=1;' : 'changecompleted=0;';
								$sWatchListOptions .= strIsTrue(SafeGetArrayItem2DimByName($aSettings, $sModelNameInConfig, 'wl_change_new', 'false')) ? 'changenew=1;' : 'changenew=0;';
								$sWatchListOptions .= strIsTrue(SafeGetArrayItem2DimByName($aSettings, $sModelNameInConfig, 'wl_change_incomplete', 'false')) ? 'changeincomplete=1;' : 'changeincomplete=0;';
								$sWatchListOptions .= strIsTrue(SafeGetArrayItem2DimByName($aSettings, $sModelNameInConfig, 'wl_defect_verified', 'false')) ? 'defectverified=1;' : 'defectverified=0;';
								$sWatchListOptions .= strIsTrue(SafeGetArrayItem2DimByName($aSettings, $sModelNameInConfig, 'wl_defect_requested', 'false')) ? 'defectrequested=1;' : 'defectrequested=0;';
								$sWatchListOptions .= strIsTrue(SafeGetArrayItem2DimByName($aSettings, $sModelNameInConfig, 'wl_defect_completed', 'false')) ? 'defectcompleted=1;' : 'defectcompleted=0;';
								$sWatchListOptions .= strIsTrue(SafeGetArrayItem2DimByName($aSettings, $sModelNameInConfig, 'wl_defect_new', 'false')) ? 'defectnew=1;' : 'defectnew=0;';
								$sWatchListOptions .= strIsTrue(SafeGetArrayItem2DimByName($aSettings, $sModelNameInConfig, 'wl_defect_incomplete', 'false')) ? 'defectincomplete=1;' : 'defectincomplete=0;';
								$sWatchListOptions .= strIsTrue(SafeGetArrayItem2DimByName($aSettings, $sModelNameInConfig, 'wl_issue_verified', 'false')) ? 'issueverified=1;' : 'issueverified=0;';
								$sWatchListOptions .= strIsTrue(SafeGetArrayItem2DimByName($aSettings, $sModelNameInConfig, 'wl_issue_requested', 'false')) ? 'issuerequested=1;' : 'issuerequested=0;';
								$sWatchListOptions .= strIsTrue(SafeGetArrayItem2DimByName($aSettings, $sModelNameInConfig, 'wl_issue_completed', 'false')) ? 'issuecompleted=1;' : 'issuecompleted=0;';
								$sWatchListOptions .= strIsTrue(SafeGetArrayItem2DimByName($aSettings, $sModelNameInConfig, 'wl_issue_new', 'false')) ? 'issuenew=1;' : 'issuenew=0;';
								$sWatchListOptions .= strIsTrue(SafeGetArrayItem2DimByName($aSettings, $sModelNameInConfig, 'wl_issue_incomplete', 'false')) ? 'issueincomplete=1;' : 'issueincomplete=0;';
								$sWatchListOptions .= strIsTrue(SafeGetArrayItem2DimByName($aSettings, $sModelNameInConfig, 'wl_task_verified', 'false')) ? 'taskverified=1;' : 'taskverified=0;';
								$sWatchListOptions .= strIsTrue(SafeGetArrayItem2DimByName($aSettings, $sModelNameInConfig, 'wl_task_requested', 'false')) ? 'taskrequested=1;' : 'taskrequested=0;';
								$sWatchListOptions .= strIsTrue(SafeGetArrayItem2DimByName($aSettings, $sModelNameInConfig, 'wl_task_completed', 'false')) ? 'taskcompleted=1;' : 'taskcompleted=0;';
								$sWatchListOptions .= strIsTrue(SafeGetArrayItem2DimByName($aSettings, $sModelNameInConfig, 'wl_task_new', 'false')) ? 'tasknew=1;' : 'tasknew=0;';
								$sWatchListOptions .= strIsTrue(SafeGetArrayItem2DimByName($aSettings, $sModelNameInConfig, 'wl_task_incomplete', 'false')) ? 'taskincomplete=1;' : 'taskincomplete=0;';
								$sWatchListOptions .= strIsTrue(SafeGetArrayItem2DimByName($aSettings, $sModelNameInConfig, 'wl_event_requested', 'false')) ? 'eventrequested=1;' : 'eventrequested=0;';
								$sWatchListOptions .= strIsTrue(SafeGetArrayItem2DimByName($aSettings, $sModelNameInConfig, 'wl_event_new', 'false')) ? 'eventnew=1;' : 'eventnew=0;';
								$sWatchListOptions .= strIsTrue(SafeGetArrayItem2DimByName($aSettings, $sModelNameInConfig, 'wl_event_incomplete', 'false')) ? 'eventincomplete=1;' : 'eventincomplete=0;';
								$sWatchListOptions .= strIsTrue(SafeGetArrayItem2DimByName($aSettings, $sModelNameInConfig, 'wl_decision_verified', 'false')) ? 'decisionverified=1;' : 'decisionverified=0;';
								$sWatchListOptions .= strIsTrue(SafeGetArrayItem2DimByName($aSettings, $sModelNameInConfig, 'wl_decision_requested', 'false')) ? 'decisionrequested=1;' : 'decisionrequested=0;';
								$sWatchListOptions .= strIsTrue(SafeGetArrayItem2DimByName($aSettings, $sModelNameInConfig, 'wl_decision_completed', 'false')) ? 'decisioncompleted=1;' : 'decisioncompleted=0;';
								$sWatchListOptions .= strIsTrue(SafeGetArrayItem2DimByName($aSettings, $sModelNameInConfig, 'wl_decision_new', 'false')) ? 'decisionnew=1;' : 'decisionnew=0;';
								$sWatchListOptions .= strIsTrue(SafeGetArrayItem2DimByName($aSettings, $sModelNameInConfig, 'wl_decision_incomplete', 'false')) ? 'decisionincomplete=1;' : 'decisionincomplete=0;';
								$_SESSION['watchlist_options_model'] = $sWatchListOptions;
								$_SESSION['hide_xml_errors']		= SafeGetArrayItem2DimByName($aSettings, $sModelNameInConfig, 'hide_xml_errors', 'true');
								$sURLLocation = 'location: index.php';
								$sURLParameters = '';
								if ( !strIsEmpty($sAutoLoadModel) )
								{
									$sURLParameters .= 'm=' . $sAutoLoadModel;
								}
								if ( !strIsEmpty($sAutoLoadObject) )
								{
									if ( !strIsEmpty($sURLParameters) )
										$sURLParameters .= '&';
									$sURLParameters .= 'o=' . $sAutoLoadObject;
								}
								if ( !strIsEmpty($sURLParameters) )
								{
									$sURLLocation .= '?' . $sURLParameters;
								}
								header($sURLLocation);
								exit();
							}
						}
						else
						{
							$sErrorMsg = g_csHTTPNewLine . "The entered authorization code is invalid!";
						}
					}
					else
					{
						$sErrorMsg = g_csHTTPNewLine . $sModelName . " is not defined in the configuration!";
					}
				}
				else
				{
					$sErrorMsg = g_csHTTPNewLine . "There is a problem with the options for the selected model!";
				}
			}
			else
 			{
				$sErrorMsg = g_csHTTPNewLine . "No model selected!";
			}
		}
		echo '<div id="webea-main-content">';
		$aMissingModules = CheckMissingModules();
		if (empty($aMissingModules))
		{
			$iCnt = 0;
			if (isset($aSettings['model_list']))
			{
				$iCnt = count($aSettings['model_list']);
			}
			echo '<div id="sign-in">';
			if ( $iCnt > 0 )
			{
				echo '<form class="form-signin" name="login-form" role="form" action="' . htmlspecialchars($_SERVER['PHP_SELF']) . '" method = "post">';
				echo '<div id="signin-prompt"></div>';
				echo '<div id="login-model-section"' .  ( ( $sCurrentStep === 'prompt_model' ) ? '' : 'style="display:none;"') . '>';
				echo '<fieldset class="login-model-section-fieldset"><legend class="login-model-section-legend">' . _glt('Select Model') . '</legend>';
				echo '<div id="main-busy-loader1"><img src="images/mainwait.gif" alt="" class="main-spinner" height="62" width="62"></div>';
				echo '<div id="signin-prompt-models">';
				for ($i=1; $i<=$iCnt; $i++)
				{
					$sValue 	= SafeGetArrayItem2DimByName($aSettings, 'model_list', 'model' . $i, '');
					if ( !strIsEmpty($sValue) )
					{
						$sValue 		= htmlspecialchars($sValue);
						$sAccessCode	= SafeGetArrayItem2DimByName($aSettings, 'model' . $i, 'auth_code', '');
						$bLoginPrompt	= strIsTrue(SafeGetArrayItem2DimByName($aSettings, 'model' . $i, 'login_prompt', 'false'));
						$sABP			= strIsTrue(SafeGetArrayItem2DimByName($aSettings, 'model' . $i, 'login_allow_blank_pwd', 'false')) ? '1' : '0';
						$sProtocol		= SafeGetArrayItem2DimByName($aSettings, 'model' . $i, 'sscs_protocol', 'http');
						$sAT = 'none';
						if ($sAccessCode !== md5('') && $bLoginPrompt)
							$sAT = 'access_login';
						elseif ($sAccessCode === md5('') && $bLoginPrompt)
							$sAT = 'login';
						elseif ($sAccessCode !== md5('') && !$bLoginPrompt)
							$sAT = 'access';
						if ( !strIsEmpty($sAutoLoadModel) )
						{
							$sModelName = 'model' . $sAutoLoadModel;
						}
						echo '<label class="login-model-radio-label" for="model' . $i . '"><input type="radio" name="modelname" id="model' . $i . '" value="model' . $i . (('model' . $i === $sModelName) ? '" checked="checked" ' : '" ') . 'auth_type="' . $sAT . '" protocol="' . $sProtocol . '" allowblankpwd="' . $sABP . '"/> <span>' . $sValue . '</span></label>';
					}
				}
				echo '</div>';
				echo '</fieldset>';
				echo '</div>';
				echo '<div id="login-auth-section"' .  ( ( $sCurrentStep === 'prompt_auth' ) ? '' : 'style="display:none;"') . '>';
				echo '<fieldset class="login-model-section-fieldset"><legend class="login-model-section-legend">' . _glt('Authentication') . '</legend>';
				echo '<div id="main-busy-loader2"><img src="images/mainwait.gif" alt="" class="main-spinner" height="62" width="62"></div>';
				echo '<div id="login-auth-header">' . htmlspecialchars($sModelFriendlyName) . '</div>';
				echo '<div id="login-auth-access-div"' .  (($sShowAccessCode==='1') ? '' : ' style="display:none;"') . '>';
				echo '<div class="login-accesscode-div">';
				echo '<div class="login-field-div"><label class="login-field-label">' . _glt('Access code') . '<span class="field-label-required">&nbsp;*</span></label><input id="login-accesscode-text" class="login-textbox" type="password" name="access-code" onkeypress="return OnKeyPressLogin(event)" autocomplete="off" autocorrect="off" autocapitalize="off" spellcheck="false"/></div>';
				echo '</div>';
				echo '</div>';
				echo '<div id="login-auth-login-div"' .  (($sShowLoginFields==='1') ? '' : ' style="display:none;"') . '>';
				echo '<div class="login-field-div"><label class="login-field-label">' . _glt('Model User') . '<span class="field-label-required">&nbsp;*</span> </label><input id="login-userid-text" class="login-textbox" type="text" name="userid" value="' . $sUserID . '" onkeypress="return OnKeyPressLogin(event)" autocomplete="off" autocorrect="off" autocapitalize="off" spellcheck="false"/></div>';
				echo '<div class="login-field-div"><label class="login-field-label">' . _glt('Password') . (($sAllowBlankPwd==='1') ? '' : '<span id="login-pwd-required-label" class="field-label-required">&nbsp;*</span>') . ' </label><input id="login-password-text" class="login-textbox" type="password" name="password" onkeypress="return OnKeyPressLogin(event)" autocomplete="off" autocorrect="off" autocapitalize="off" spellcheck="false"/></div>';
				if ($sShowInsecureWarning==='1')
					echo '<div id="login-insecure-warning-div"><img alt="" src="images/spriteplaceholder.png" class="mainsprite-warning"><div id="login-insecure-warning-text">'. _glt('HTTP Warning').'</div></div>';
				echo '</div>';
				echo '</fieldset>';
				echo '</div>';
				echo '<div id="login-error">' . $sErrorMsg . '</div>';
				echo '<div class="login-action-buttons-div1">&nbsp;<div class="login-action-buttons-div2">';
				echo '<input class="login-action-button" type="button" name="back" id="login-back-button" value="' . _glt('Back') . '" ' .  ( ( $sCurrentStep === 'prompt_auth' ) ? '' : 'style="display:none;"') . ' onclick="OnClickLoginBackButton(this)">';
				echo '<input class="login-action-button" type="button" name="next" id="login-next-button" value="' . _glt('Next') . '" ' .  ( ( $sCurrentStep === 'prompt_model' ) ? '' : 'style="display:none;"') . ' onclick="OnClickLoginNextButton(this)">';
				echo '<input class="login-action-button" type="button" name="finish" id="login-finish-button" value="' . _glt('Login') . '" ' .  ( ( $sCurrentStep === 'prompt_auth' ) ? '' : 'style="display:none;"') . ' onclick="OnClickLoginLoginButton(this)">';
				echo '</div></div>';
				echo '<input type="hidden" name="step" id="login-step" value="' . $sCurrentStep . '">';
				echo '<input type="hidden" name="auth-type" id="login-auth-type" value="' . $sAuthType . '">';
				echo '<input type="hidden" name="modelfriendlyname" id="login-selected-model-name" value="' . $sModelFriendlyName . '">';
				echo '<input type="hidden" name="modelnumber" id="login-selected-model-no" value="' . $sModelNo . '">';
				echo '<input type="hidden" name="showaccesscode" id="login-show-accesscode" value="' . $sShowAccessCode . '">';
				echo '<input type="hidden" name="showloginfields" id="login-show-loginfields" value="' . $sShowLoginFields . '">';
				echo '<input type="hidden" name="showinsecurewarning" id="login-show-insecure-warning" value="' . $sShowInsecureWarning . '">';
				echo '<input type="hidden" name="testconnection" id="login-test-connection" value="' . $sTestConnection . '">';
				echo '<input type="hidden" name="allowblankpwd" id="login-allow-blank-pwd" value="' . $sAllowBlankPwd . '">';
				echo '<input type="hidden" name="autoloadmodel" id="login-auto-load-model" value="' . $sAutoLoadModel . '">';
				echo '<input type="hidden" name="autoloadobject" id="login-auto-load-object" value="' . $sAutoLoadObject . '">';
				echo '</form>';
				echo '</div>';
			}
			else
			{
				echo '<div id="signin-prompt"></div>';
				echo '<div class="login-configure-error">There are no models configured, please get your system administrator to define at least one model.</div>';
			}
		}
		else
		{
			echo '<div id="sign-in">';
			echo '<div class="login-configure-error">';
			echo 'Your web server environment does not have the following modules installed:' . g_csHTTPNewLine . g_csHTTPNewLine;
			foreach ($aMissingModules as $sModule)
			{
				echo '&nbsp;&nbsp;- ' . $sModule . g_csHTTPNewLine;
			}
			echo g_csHTTPNewLine. 'Contact your web master to correct this.';
			echo '</div>';
			echo '</div>';
		}
		echo '</div>';
?>
	<footer>
		<div id="main-footer">
    	<div class="main-footer-copyright"> Copyright &copy; <?php echo g_csCopyRightYears; ?> Sparx Systems Pty Ltd.  All rights reserved.</div>
     	<div class="main-footer-version"> WebEA v<?php echo g_csWebEAVersion; ?> </div>
		</div>
	</footer>
</body>
</html>
<?php
	function CheckMissingModules()
	{
		$aModules = array('core', 'curl', 'date','gettext','hash','json','libxml','mbstring','pcre','session','standard','tokenizer');
		$aUnavailable = array();
		foreach ($aModules as $sModule)
		{
			if (extension_loaded($sModule) !== true)
			{
				$aUnavailable[] = $sModule;
			}
		}
		return $aUnavailable;
	}
?>
<style>
[type="radio"]
{
	border: 0;
	clip: rect(0 0 0 0);
	height: 1px; margin: -1px;
	overflow: hidden;
	padding: 0;
	position: absolute;
	width: 1px;
}
[type="radio"] + span
{
	display: block;
}
[type="radio"] + span:before
{
	content: '';
	display: inline-block;
	width: 1em;
	height: 1em;
	vertical-align: -0.25em;
	border: 0.1em solid #fff;
	box-shadow: 0 0 0 1px #000;
	margin-right: 1em;
}
[type="radio"]:checked + span:before {
	background: #3777bf;
	box-shadow: 0 0 0 3px #555555;
}
</style>
<script>
	window.onpageshow = function(event) {
		if (event.persisted)
		{
			var ele1 = document.getElementById('main-busy-loader1');
			if ( ele1 )
			{
				if ( ele1.style.display === 'block' )
				{
					ele1.style.display = 'none';
				}
			}
			var ele2 = document.getElementById('main-busy-loader2');
			if ( ele2 )
			{
				if ( ele2.style.display === 'block' )
				{
					ele2.style.display = 'none';
				}
			}
		}
	};
	function OnKeyPressLogin(element)
	{
		if ($("#login-finish-button").css('display') != 'none')
		{
			if (element.keyCode == 13)
			{
				OnClickLoginLoginButton(element);
				return false;
			}
		}
		return true;
	}
	function OnClickLoginNextButton()
	{
		var sErrorMessage = '<br>No model selected!';
		var sFieldToFocus = '';
		$("#login-error").html('');
		var ele = $('input[name=modelname]:checked')[0];
		if (ele)
		{
			var sValue = ele.id;
			if (sValue)
			{
				var sModelNo = sValue.substr(5);
				$("#login-selected-model-no").val(sModelNo);
				var eleNext = ele.nextElementSibling;
				var sModelFriendlyName = '';
				if (eleNext)
				{
					sModelFriendlyName = $(eleNext).text();
				}
				if (sModelFriendlyName !== '')
				{
					$("#login-selected-model-name").val(sModelFriendlyName);
					sErrorMessage = '';
				}
				var sAuthType = ele.getAttribute('auth_type')
				if (sAuthType)
				{
					$("#login-auth-type").val(sAuthType);
					if (sAuthType!=='none')
					{
						$("#login-auth-header").text(sModelFriendlyName);
						if (sAuthType !== 'access_login' && sAuthType !== 'access' )
						{
							$("#login-auth-access-div").hide();
							$("#login-show-accesscode").val('0');
						}
						else
						{
							$("#login-auth-access-div").show();
							$("#login-show-accesscode").val('1');
							sFieldToFocus = '#login-accesscode-text';
						}
						$("#login-insecure-warning-div").hide();
						$("#login-show-insecure-warning").val('0');
						if (sAuthType !== 'access_login' && sAuthType !== 'login' )
						{
							$("#login-auth-login-div").hide();
							$("#login-show-loginfields").val('0');
						}
						else
						{
							$("#login-auth-login-div").show();
							$("#login-show-loginfields").val('1');
							var sAllowBlankPwd = ele.getAttribute('allowblankpwd');
							if ( sAllowBlankPwd === '1' )
							{
								$("#login-allow-blank-pwd").val('1');
								$("#login-pwd-required-label").hide();
							}
							else
							{
								$("#login-allow-blank-pwd").val('0');
								$("#login-pwd-required-label").show();
							}
							var sProtocol = ele.getAttribute('protocol')
							if (sProtocol)
							{
								if (sProtocol !== 'https' )
								{
									$("#login-insecure-warning-div").show();
									$("#login-show-insecure-warning").val('1');
								}
							}
							if ( sFieldToFocus==='' )
							{
								sFieldToFocus = '#login-userid-text';
							}
						}
						$("#login-step").val('prompt_auth');
					}
					else
					{
						sErrorMessage = '  ';
						$("#main-busy-loader1").show();
						$("#login-test-connection").val('1');
						document.forms["login-form"].submit();
					}
				}
			}
		}
		if (sErrorMessage !== '')
		{
			$("#login-error").html(sErrorMessage);
		}
		else
		{
			$("#login-model-section").hide();
			$("#login-auth-section").show();
			$("#login-next-button").hide();
			$("#login-back-button").show();
			$("#login-finish-button").show();
			if ( sFieldToFocus!=='' )
			{
				$(sFieldToFocus).focus();
			}
		}
	}
	function OnClickLoginBackButton()
	{
		$("#login-error").html('');
		$("#login-model-section").show();
		$("#login-auth-section").hide();
		$("#login-next-button").show();
		$("#login-back-button").hide();
		$("#login-finish-button").hide();
		$("#login-step").val('prompt_model');
	}
	function OnClickLoginLoginButton()
	{
		var sErrorMessage = '';
		$("#login-error").html('');
		if ($("#login-auth-access-div").css('display') != 'none')
		{
			if (!($("#login-accesscode-text").val()))
				sErrorMessage = '<br>Access code is required!';
		}
		if ($("#login-auth-login-div").css('display') != 'none')
		{
			var sUserID = '';
			var sPwd = '';
			sUserID = $("#login-userid-text").val();
			sPwd = $("#login-password-text").val();
			sUserID = sUserID.replace(/^\s+|\s+$/gm, '');
			var sAllowBlankPwd = $("#login-allow-blank-pwd").val();
			if ( sAllowBlankPwd === '1' )
			{
				if (!sUserID)
					sErrorMessage = '<br>Model User is required!';
			}
			else
			{
				if ( !sUserID && !sPwd)
					sErrorMessage = '<br>Model User and password are both required!';
				else if (!sUserID)
					sErrorMessage = '<br>Model User is required!';
				else if (!sPwd)
					sErrorMessage = '<br>Password is required!';
			}
		}
		if (sErrorMessage !== '')
		{
			$("#login-error").html(sErrorMessage);
		}
		else
		{
			$("#main-busy-loader2").show();
			$("#login-test-connection").val('1');
			document.forms["login-form"].submit();
		}
	}
</script>