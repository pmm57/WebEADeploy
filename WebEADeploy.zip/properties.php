<?php
// --------------------------------------------------------
//  This is a part of the Sparx Systems Pro Cloud Server.
//  Copyright (C) Sparx Systems Pty Ltd
//  All rights reserved.
//
//  This source code can be used only under terms and 
//  conditions of the accompanying license agreement.
// --------------------------------------------------------
	$sRootPath = dirname(__FILE__);
	require_once $sRootPath . '/globals.php';
	SafeStartSession();
	if (isset($_SESSION['authorized']) === false)
	{
		echo '<div id="main-content-empty">' . _glt('Your session appears to have timed out') . '</div>';
		setResponseCode(440);
		exit();
	}
	$sSessionReviewGUID = SafeGetInternalArrayParameter($_SESSION, 'review_session');
	if ( $sResType === "Package" || $sResType === "Diagram"  || $sResType === "Element" )
	{
		$sObjectType 	= SafeGetArrayItem1Dim($aCommonProps, 'type');
		$sObjectName 	= SafeGetArrayItem1Dim($aCommonProps, 'name');
		$sObjectNType 	= SafeGetArrayItem1Dim($aCommonProps, 'ntype');
		$sObjectGUID 	= SafeGetArrayItem1Dim($aCommonProps, 'guid');
		$bObjectLocked 	= strIsTrue(SafeGetArrayItem1Dim($aCommonProps, 'locked'));
		$sObjectImageURL = SafeGetArrayItem1Dim($aCommonProps, 'imageurl');;
		echo '<div id="panelbar" class="w3-accordion">';
		WritePropertySectionContentHeader('info', _glt('Properties'), '1');
		WriteSectionCommon($aCommonProps);
		echo '</div>';
		if (IsSessionSettingTrue('prop_visible_location') )
		{
			WriteSectionLocation('location', _glt('Location'), '1', $aParentInfo, $aUsages);
		}
		if (IsSessionSettingTrue('prop_visible_relationships') )
		{
			WriteSectionRelationships('relationships', _glt('Relationships'), '1', $aRelationships);
		}
		if ( $sResType === "Package" || $sResType === "Element" )
		{
			if (count($aTaggedValues)> 0 && IsSessionSettingTrue('prop_visible_taggedvalues') )
			{
				WritePropertySectionContentHeader('taggedvalues', _glt('Tagged Values'), '1');
				WriteSectionTaggedValues($aTaggedValues);
				echo '</div></li>';
			}
			if (count($aTests)> 0 && IsSessionSettingTrue('prop_visible_testing') )
			{
				WritePropertySectionContentHeader('testing', _glt('Testing'), '1');
				WriteSectionTest($aTests, $sObjectGUID, $bObjectLocked, $sObjectName, $sObjectImageURL);
				echo '</div></li>';
			}
			if (count($aResAllocs)> 0 && IsSessionSettingTrue('prop_visible_resourcealloc') )
			{
				WritePropertySectionContentHeader('resourcealloc', _glt('Resource Allocation'), '1');
				WriteSectionResourceAllocs($aResAllocs, $sObjectGUID, $bObjectLocked, $sObjectName, $sObjectImageURL);
				echo '</div></li>';
			}
			if (count($aAttributes)> 0 && IsSessionSettingTrue('prop_visible_attributes') )
			{
				WritePropertySectionContentHeader('attributes', _glt('Attributes'), '1');
				WriteSectionAttributes($aAttributes);
				echo '</div></li>';
			}
			if (count($aOperations)> 0 && IsSessionSettingTrue('prop_visible_operations') )
			{
				WritePropertySectionContentHeader('operations', _glt('Operations'), '1');
				WriteSectionOperations($aOperations);
				echo '</div></li>';
			}
			if (count($aRunStates)> 0 && IsSessionSettingTrue('prop_visible_runstates') )
			{
				WritePropertySectionContentHeader('runstates', _glt('Run States'), '1');
				WriteSectionRunStates($aRunStates, 'runstate');
				echo '</div></li>';
			}
			if (count($aChanges)> 0 && IsSessionSettingTrue('prop_visible_changes') )
			{
				WritePropertySectionContentHeader('changes', _glt('Changes'), '1');
				WriteSectionChangeManagement1($aChanges, 'change');
				echo '</div></li>';
			}
			if (count($aDefects)> 0 && IsSessionSettingTrue('prop_visible_defects') )
			{
				WritePropertySectionContentHeader('defects', _glt('Defects'), '1');
				WriteSectionChangeManagement1($aDefects, 'defect');
				echo '</div></li>';
			}
			if (count($aIssues)> 0 && IsSessionSettingTrue('prop_visible_issues') )
			{
				WritePropertySectionContentHeader('issues', _glt('Issues'), '1');
				WriteSectionChangeManagement1($aIssues, 'issue');
				echo '</div></li>';
			}
			if (count($aTasks)> 0 && IsSessionSettingTrue('prop_visible_tasks') )
			{
				WritePropertySectionContentHeader('tasks', _glt('Tasks'), '1');
				WriteSectionChangeManagement1($aTasks, 'task');
				echo '</div></li>';
			}
			if (count($aEvents)> 0 && IsSessionSettingTrue('prop_visible_events') )
			{
				WritePropertySectionContentHeader('events', _glt('Events'), '1');
				WriteSectionChangeManagement1($aEvents, 'event');
				echo '</div></li>';
			}
			if (count($aDecisions)> 0 && IsSessionSettingTrue('prop_visible_decisions') )
			{
				WritePropertySectionContentHeader('decisions', _glt('Decisions'), '1');
				WriteSectionChangeManagement1($aDecisions, 'decision');
				echo '</div></li>';
			}
			if (count($aEfforts)> 0 && IsSessionSettingTrue('prop_visible_efforts') )
			{
				WritePropertySectionContentHeader('efforts', _glt('Efforts'), '1');
				WriteSectionChangeManagement2($aEfforts, 'effort');
				echo '</div></li>';
			}
			if (count($aRisks)> 0 && IsSessionSettingTrue('prop_visible_risks') )
			{
				WritePropertySectionContentHeader('risks', _glt('Risks'), '1');
				WriteSectionChangeManagement2($aRisks, 'risk');
				echo '</div></li>';
			}
			if (count($aMetrics)> 0 && IsSessionSettingTrue('prop_visible_metrics') )
			{
				WritePropertySectionContentHeader('metrics', _glt('Metrics'), '1');
				WriteSectionChangeManagement2($aMetrics, 'metric');
				echo '</div></li>';
			}
		}
		if (IsSessionSettingTrue('show_discuss'))
		{
			if ( $sResType === "Package" || $sResType === "Element" )
			{
				if (ShouldIgnoreName($sObjectType, $sObjectName, $sObjectNType))
				{
					if (count($aDiscussions)> 0 || IsSessionSettingTrue('add_discuss'))
					{
						echo '<div id="reviews-discussions">';
						include("./propertiesdiscussions.php");
						echo '</div>';
					}
				}
			}
		}
	}
	function WriteSectionCommon($aCommonProps)
	{
		echo '<div id="common-section">';
		echo '<img alt="" src="images/spriteplaceholder.png" class="common-section-icon">';
		$sObjectGUID 	= SafeGetArrayItem1Dim($aCommonProps, 'guid');
		$sObjectResType = SafeGetArrayItem1Dim($aCommonProps, 'restype');
		$sObjectModified  = SafeGetArrayItem1Dim($aCommonProps, 'modified');
		$sObjectStatus	= SafeGetArrayItem1Dim($aCommonProps, 'status');
		$sObjectVersion	= SafeGetArrayItem1Dim($aCommonProps, 'version');
		$sObjectPhase	= SafeGetArrayItem1Dim($aCommonProps, 'phase');
		$sModDate = RemoveTime($sObjectModified);
		$sModTime = RemoveDate($sObjectModified);
		$sCreated = SafeGetArrayItem1Dim($aCommonProps, 'created');
		$sCreated = RemoveTime($sCreated);;
		echo '<div class="common-item">';
		$sPropertiesDetails  = '';
		$sPropertiesDetails .= WriteArrayLabelValueProperty($aCommonProps, 'author', _glt('Author'), 'common-label', 'common-value', false);
		$sPropertiesDetails .= WriteArrayLabelValueProperty($aCommonProps, 'created', _glt('Created'), 'common-label', 'common-value', false);
		$sType 			= SafeGetArrayItem1Dim($aCommonProps, 'type');
		$aStereotypes 	= SafeGetArrayItem1Dim($aCommonProps, 'stereotypes');
		$sStereotype 	= getPrimaryFQStereotype($aStereotypes);
		$sClassName 	= SafeGetArrayItem1Dim($aCommonProps, 'classname');
		$sClassGUID 	= SafeGetArrayItem1Dim($aCommonProps, 'classguid');
		$sClassImageURL	= SafeGetArrayItem1Dim($aCommonProps, 'classimageurl');
		if ( !strIsEmpty($sClassGUID) )
		{
			$sType  = '<a class="w3-link" onclick="load_object(\'' . $sClassGUID . '\',\'false\',\'\',\'\',\'' . ConvertStringToParameter($sType) . '\',\'' . $sClassImageURL . '\')">';
			$sType .= '<img src="images/spriteplaceholder.png" class="' . GetObjectImageSpriteName($sClassImageURL) . '" style="float: none;">&nbsp;' . htmlspecialchars($sClassName) . '</a>';
		}
		else
		{
			$sType  = htmlspecialchars( _glt($sType) );
		}
		if ( !strIsEmpty($sType) || !strIsEmpty($sStereotype) )
		{
			$sPropertiesDetails .= '<tr><td class="common-label">' . _glt('Type') . '</td><td class="common-value">';
			$sPropertiesDetails .= $sType;
			if ( !strIsEmpty($sType) && !strIsEmpty($sStereotype) )
				$sPropertiesDetails .= '&nbsp;&nbsp;&nbsp;';
			if ( !strIsEmpty($sStereotype) )
			{
				$sPropertiesDetails .= buildStereotypeDisplayHTML($sStereotype, $aStereotypes, true);
			}
			$sPropertiesDetails .= '</td></tr>';
		}
		$sPropertiesDetails .= WriteArrayLabelValueProperty($aCommonProps, 'modified', _glt('Modified'), 'common-label', 'common-value', false);
		$sPCSEdition = SafeGetInternalArrayParameter($_SESSION, 'pro_cloud_license');
		if ($sObjectResType === 'Diagram' && (!IsSessionSettingTrue('readonly_model') && $sPCSEdition !== 'Express') )
		{
			$sObjectGenerated = SafeGetArrayItem1Dim($aCommonProps, 'generated');
			$sImageInSync = SafeGetArrayItem1Dim($aCommonProps, 'imageinsync');
			if ( strIsEmpty($sObjectGenerated) )
			{
				$sObjectGenerated = _glt('<awaiting>');
			}
			else
			{
				$sObjectGenerated = htmlspecialchars($sObjectGenerated);
			}
			$sPropertiesDetails .= '<tr>';
			$sPropertiesDetails .= '<td class="common-label">' . _glt('Generated') . '</td>';
			$sPropertiesDetails .= '<td class="common-value">' . $sObjectGenerated;
			$sPropertiesDetails .= '<input class="webea-main-styled-button" id="generatediagram-action-button"' . ((strIsTrue($sImageInSync)) ? '' : ' disabled=""') . ' type="button" onclick="OnRequestDiagramRegenerate(\'' . ConvertStringToParameter($sObjectGUID) . '\')" title="' . _glt('Mark the current diagram as requiring re-generation') . '"></td>';
			$sPropertiesDetails .= '</tr>';
			$sPropertiesDetails .= '<tr id="diagram-regeneration-label-line"' . ((strIsTrue($sImageInSync)) ? ' style="display: none;"' : '') . '>';
			$sPropertiesDetails .= '<td class="common-label">&nbsp;</td>';
			$sPropertiesDetails .= '<td class="common-value"><div class="diagram-regeneration-label">  ' . _glt('Image pending regeneration') . '  </div></td>';
			$sPropertiesDetails .= '</tr>';
		}
		$sPropertiesDetails .= WriteArrayLabelValueProperty($aCommonProps, 'version', _glt('Version'), 'common-label', 'common-value', false);
		$sPropertiesDetails .= WriteArrayLabelValueProperty($aCommonProps, 'phase', _glt('Phase'), 'common-label', 'common-value', false);
		$sPropertiesDetails .= WriteArrayLabelValueProperty($aCommonProps, 'status', _glt('Status'), 'common-label', 'common-value', false);
		$sPropertiesDetails .= WriteArrayLabelValueProperty($aCommonProps, 'alias', _glt('Alias'), 'common-label', 'common-value', false);
		$sPropertiesDetails .= WriteArrayLabelValueProperty($aCommonProps, 'guid_raw', _glt('GUID'), 'common-label', 'common-value', false);
		echo '<div>';
		echo '<table class="common-table">';
		echo $sPropertiesDetails;
		echo '</table>';
		echo '</div>';
		echo '</div>';
		echo '</div>' . PHP_EOL;
	}
	function WriteArrayLabelValueProperty($aProps, $sItemName, $sLabel, $sTDLabelClass, $sTDValueClass, $bEchoResult=true)
	{
		$sReturn = '';
		$sValue = SafeGetArrayItem1Dim($aProps, $sItemName);
		if ( !strIsEmpty($sValue) )
		{
			$sValue = htmlspecialchars($sValue);
			$sReturn .= '<tr>';
			$sReturn .= '<td class="' . $sTDLabelClass . '">' . $sLabel . '</td>';
			$sReturn .= '<td class="' . $sTDValueClass . '">' . $sValue . '</td>';
			$sReturn .= '</tr>';
		}
		if ($bEchoResult)
		{
			echo $sReturn;
		}
		return $sReturn;
	}
	function WriteLabelValueProperty($sLabel, $sValue, $sTDLabelID, $sTDValueID, $bEchoResult=true)
	{
		$sReturn = '';
		if ( !strIsEmpty($sValue) )
		{
			$sReturn .= '<tr>';
			$sReturn .= '<td id=' . $sTDLabelID . '>' . $sLabel . '</td>';
			$sReturn .= '<td id=' . $sTDValueID . '>' . $sValue . '</td>';
			$sReturn .= '</tr>';
		}
		if ($bEchoResult)
		{
			echo $sReturn;
		}
		return $sReturn;
	}
	function WriteSectionAttributes($a)
	{
		echo '<div id="attribute-section">';
		$iCnt = count($a);
		for ($i=0; $i<$iCnt; $i++)
		{
			$sName 			= SafeGetArrayItem2Dim($a, $i, 'name');
			$sGUID 			= SafeGetArrayItem2Dim($a, $i, 'guid');
			$sType 			= SafeGetArrayItem2Dim($a, $i, 'type');
			$sScope 		= SafeGetArrayItem2Dim($a, $i, 'scope');
			$sDefault 		= SafeGetArrayItem2Dim($a, $i, 'default');
			$sAlias 		= SafeGetArrayItem2Dim($a, $i, 'alias');
			$sStereotype 	= SafeGetArrayItem2Dim($a, $i, 'sterotype');
			$sClassName 	= SafeGetArrayItem2Dim($a, $i, 'classname');
			$sClassGUID 	= SafeGetArrayItem2Dim($a, $i, 'classguid');
			$sClassImageURL	= SafeGetArrayItem2Dim($a, $i, 'classimageurl');
			if (substr($sDefault,0,26)=='<Image type="EAShapeScript')
				$sDefault = '<EAShapeScript>';
			$sName			= htmlspecialchars($sName);
			$sDefault		= htmlspecialchars($sDefault);
			$sType 			= htmlspecialchars($sType);
			$sAlias 		= htmlspecialchars($sAlias);
			$sStereotype 	= formatWithStereotypeChars($sStereotype);
			echo '<div class="attribute-item property-section-item">';
			$s = mb_strtolower($sScope);
			$s = ($s==='private' || $s==='protected' || $s==='public' || $s==='package' ) ? 'propsprite-attribute' . $s : 'propsprite-attribute';
			if ( !strIsEmpty($sClassGUID) )
			{
				$sType  = '<a class="w3-link" onclick="load_object(\'' . $sClassGUID . '\',\'false\',\'\',\'\',\'' . ConvertStringToParameter($sType) . '\',\'' . $sClassImageURL . '\')">';
				$sType .= '<img src="images/spriteplaceholder.png" class="' . GetObjectImageSpriteName($sClassImageURL) . '" style="float: none;">&nbsp;' . htmlspecialchars($sClassName) . '</a>';
			}
			$aAttribItemHdr  = '<div class="attribute-item-hdr">';
			$aAttribItemHdr .= '<img alt="" src="images/spriteplaceholder.png" class="' . $s . '">';
			$aAttribItemHdr .= '<div class="attribute-name">' . $sName;
			$aAttribItemHdr .= WriteValueInSentence($sStereotype, '&nbsp;', '', false);
			$aAttribItemHdr .= WriteValueInSentence($sType, ':&nbsp;', '', false);
			$aAttribItemHdr .= WriteValueInSentence($sDefault, '&nbsp;=&nbsp;', '', false);
			$aAttribItemHdr .= '</div>';
			$aAttribItemHdr .= '</div>';
			$sNotes 		= SafeGetArrayItem2Dim($a, $i, 'notes');
			$sMultiplicity 	= SafeGetArrayItem2Dim($a, $i, 'multiplicity');
			$sIsStatic 		= SafeGetArrayItem2Dim($a, $i, 'isstatic');
			$sContainment 	= SafeGetArrayItem2Dim($a, $i, 'containment');
			$sAttribExInfo = '';
			if ( !strIsEmpty($sNotes) || !strIsEmpty($sMultiplicity) || ( !strIsEmpty($sIsStatic) && $sIsStatic!=='False') ||
				(!strIsEmpty($sContainment) && $sContainment!=='Not Specified' && $sContainment!=='False') ||
				 array_key_exists(("taggedvalues"), $a[$i]) )
			{
				if ( !strIsEmpty($sNotes) )
				{
					$sAttribExInfo .= '<div class="attribute-notes">' . $sNotes . '</div>';
				}
				if ( !strIsEmpty($sMultiplicity) ||
					 !strIsEmpty($sAlias)  ||
					(!strIsEmpty($sIsStatic) && $sIsStatic!=="False") ||
					(!strIsEmpty($sContainment) && $sContainment!=="Not Specified" && $sContainment!=="False") )
				{
					$sAttribExInfo .= '<div class="attribute-properties">';
					if ( !strIsEmpty($sAlias) )
					{
						$sAttribExInfo .= '<div class="attribute-property"><span class="attribute-property-label">' . _glt('Alias') . '&nbsp;=&nbsp;' . $sAlias . '</span>&nbsp;</div>';
					}
					if ( !strIsEmpty($sMultiplicity) )
					{
						$sAllowDups = SafeGetArrayItem2Dim($a, $i, 'allowdups');
						$sIsOrdered = SafeGetArrayItem2Dim($a, $i, 'isordered');
						$sAttribExInfo .= '<div class="attribute-property">';
						$sAttribExInfo .= '<span class="attribute-property-label">' . _glt('Multiplicity') . ':</span>&nbsp;(&nbsp;' . $sMultiplicity;
						if ( $sAllowDups=='True')
							$sAttribExInfo .= '<span class="attribute-property-label">, ' . _glt('Allows duplicates') . '</span>&nbsp;';
						if ( $sIsOrdered=='True')
							$sAttribExInfo .= '<span class="attribute-property-label">, ' . _glt('Ordered') . '</span>&nbsp;';
						$sAttribExInfo .= ' ) </div>';
					}
					if ($sIsStatic==="True")
					{
						$sAttribExInfo .= '<div class="attribute-property">';
						$sAttribExInfo .= '<span class="attribute-property-label">' . _glt('Is static') . '</span>&nbsp;';
						$sAttribExInfo .= '</div>';
					}
					if ( !strIsEmpty($sContainment) && $sContainment!=="Not Specified" && $sContainment!=="False")
					{
						$sAttribExInfo .= '<div class="attribute-property">';
						$sAttribExInfo .= '<span class="attribute-property-label">' . _glt('Containment') . ':</span>&nbsp;' . $sContainment;
						$sAttribExInfo .= '</div>';
					}
					$sAttribExInfo .= '</div>';
				}
				if (array_key_exists(("taggedvalues"), $a[$i]))
				{
					$aTV = $a[$i]['taggedvalues'];
					$sAttribExInfo .= '<div class="attribute-taggedvalues">';
					$sAttribExInfo .= '<div id="attribute-taggedvalues-' . $sGUID . '" ';
					$sAttribExInfo .=     ' class="attribute-taggedvalues-header">' . _glt('Properties') . '</div>';
					$sAttribExInfo .= '<div class="attribute-taggedvalues-items">';
					$iTVCnt = count($aTV);
					for ($iTV=0; $iTV<$iTVCnt; $iTV++)
					{
						$sAttribExInfo .= '<div class="attribute-taggedvalue-item">';
						$sName = SafeGetArrayItem2Dim($aTV, $iTV, 'name');
						$sValue = SafeGetArrayItem2Dim($aTV, $iTV, 'value');
						$sNotes = SafeGetArrayItem2Dim($aTV, $iTV, 'notes');
						$sNotes = (substr($sNotes,0,8)=='Values: ') ? '' : $sNotes;
						if ($sValue==='<memo>')
						{
							$sValue = '';
						}
						$sName = htmlspecialchars($sName);
						$sValue = htmlspecialchars($sValue);
						$sNotes = htmlspecialchars($sNotes);
						$sAttribExInfo .= '<div class="attribute-taggedvalue-data">' . $sName;
						if ( !strIsEmpty($sValue) )
						{
							$sAttribExInfo .= '&nbsp;=&nbsp;' . $sValue;
						}
						$sAttribExInfo .= '</div>';
						if ( !strIsEmpty($sNotes) )
						{
							$sAttribExInfo .= '<div class="attribute-taggedvalue-notes">' . $sNotes . '</div>';
						}
						$sAttribExInfo .= '</div>';
					}
					$sAttribExInfo .= '</div>';
					$sAttribExInfo .= '</div>';
				}
			}
			if ( !strIsEmpty($sAttribExInfo) )
			{
				$sSectionName = 'collapsible-' . $sGUID;
				echo '<div id="' . $sSectionName . '" onclick="OnToggleCollapsibleSection(\'' . $sSectionName . '\')" ';
				echo     ' class="collapsible-section-header collapsible-section-header-closed">';
				echo '<img alt="" src="images/spriteplaceholder.png" class="collapsible-section-header-closed-icon">';
				echo $aAttribItemHdr;
				echo '</div>';
				echo '<div class="collapsible-section w3-hide">';
				echo $sAttribExInfo;
				echo '</div>';
			}
			else
			{
				echo '<div class="non-collapsible-guid">';
				echo $aAttribItemHdr;
				echo '</div>';
			}
			echo '</div>' . PHP_EOL;
		}
		echo '</div>' . PHP_EOL;
		echo '</div>' . PHP_EOL;
	}
	function WriteSectionOperations($a)
	{
		echo '<div id="operation-section">';
		$iCnt = count($a);
		for ($i=0;$i<$iCnt;$i++)
		{
			$sName 			= SafeGetArrayItem2Dim($a, $i, 'name');
			$sGUID 			= SafeGetArrayItem2Dim($a, $i, 'guid');
			$sScope 		= SafeGetArrayItem2Dim($a, $i, 'scope');
			$sParameters 	= SafeGetArrayItem2Dim($a, $i, 'parastring');
			$sParametersFormatted = SafeGetArrayItem2Dim($a, $i, 'parastringformat');
			$sType 			= SafeGetArrayItem2Dim($a, $i, 'classifier');
			$sStereotype 	= SafeGetArrayItem2Dim($a, $i, 'sterotype');
			$sAlias 		= SafeGetArrayItem2Dim($a, $i, 'alias');
			$sClassifierName 	= SafeGetArrayItem2Dim($a, $i, 'classifiername');
			$sClassifierGUID 	= SafeGetArrayItem2Dim($a, $i, 'classifierguid');
			$sClassifierImageURL= SafeGetArrayItem2Dim($a, $i, 'classifierimageurl');
			$sName			= htmlspecialchars($sName);
			$sParameters 	= htmlspecialchars($sParameters);
			$sType 			= htmlspecialchars($sType);
			$sStereotype 	= formatWithStereotypeChars($sStereotype);
			$sAlias 		= htmlspecialchars($sAlias);
			echo '<div class="operation-item property-section-item">';
			$s = mb_strtolower($sScope);
			$s = ($s==='private' || $s==='protected' || $s==='public' || $s==='package' ) ? 'propsprite-operation' . $s : 'propsprite-operation';
			$sOperationItemHdr  = '<div class="operation-name">' ;
			$sOperationItemHdr .= '<img alt="" src="images/spriteplaceholder.png" class="' . $s . '">';
			$sOperationItemHdr .= $sName;
			$sOperationItemHdr .= WriteValueInSentence($sStereotype, '&nbsp;', '', false);
			$sOperationItemHdr .= '('. $sParameters.')';
			if ( strIsEmpty( $sClassifierGUID ) )
			{
				$sOperationItemHdr .= WriteValueInSentence($sType, ':&nbsp;', '', false);
			}
			else
			{
				$sOperationItemHdr .= ':&nbsp;<a class="w3-link" onclick="load_object(\'' . $sClassifierGUID . '\',\'false\',\'\',\'\',\'' . ConvertStringToParameter($sClassifierName) . '\',\'' . $sClassifierImageURL . '\')">';
				$sOperationItemHdr .= '<img alt="" src="images/spriteplaceholder.png" class="' . GetObjectImageSpriteName($sClassifierImageURL) . '" style="float: none;">&nbsp;' . htmlspecialchars($sClassifierName);
				$sOperationItemHdr .= '</a>';
			}
			$sOperationItemHdr .= '</div>';
			$sOperationExInfo = '';
			$sNotes = SafeGetArrayItem2Dim($a, $i, 'notes');
			if ( !strIsEmpty($sNotes) )
			{
				$sOperationExInfo .= '<div class="operation-notes">' . $sNotes . '</div>';
			}
			$sIsStatic 		= SafeGetArrayItem2Dim($a, $i, 'isstatic');
			$sIsAbstract	= SafeGetArrayItem2Dim($a, $i, 'isabstract');
			$sIsReturnArray	= SafeGetArrayItem2Dim($a, $i, 'isreturnarray');
			$sIsQuery 		= SafeGetArrayItem2Dim($a, $i, 'isquery');
			$sIsSynch 		= SafeGetArrayItem2Dim($a, $i, 'issynch');
			if (( !strIsEmpty($sIsStatic) 		&& $sIsStatic!=="False") ||
				( !strIsEmpty($sIsAbstract) 	&& $sIsAbstract!=="False") ||
				( !strIsEmpty($sIsReturnArray) 	&& $sIsReturnArray!=="False") ||
				( !strIsEmpty($sIsQuery)		&& $sIsQuery!=="False") ||
				( !strIsEmpty($sIsSynch) 		&& $sIsSynch!=="False") ||
				( !strIsEmpty($sAlias) ) )
			{
				$sOperationExInfo .= '<div class="operation-properties">';
				if ( !strIsEmpty($sAlias) )
				{
					$sOperationExInfo .= '<div class="operation-property"><span class="operation-property-label">' . _glt('Alias') . '&nbsp;=&nbsp;' . $sAlias . '</span>&nbsp;</div>';
				}
				if ( !strIsEmpty($sIsStatic) && $sIsStatic!=="False")
				{
					$sOperationExInfo .= '<div class="operation-property"><span class="operation-property-label">' . _glt('Is static') . '</span>&nbsp;</div>';
				}
				if ( !strIsEmpty($sIsAbstract) && $sIsAbstract!=="False")
				{
					$sOperationExInfo .= '<div class="operation-property"><span class="operation-property-label">' . _glt('Is abstract') . '</span>&nbsp;</div>';
				}
				if ( !strIsEmpty($sIsReturnArray) && $sIsReturnArray!="=False")
				{
					$sOperationExInfo .= '<div class="operation-property"><span class="operation-property-label">' . _glt('Is return array') . '</span>&nbsp;</div>';
				}
				if ( !strIsEmpty($sIsQuery) && $sIsQuery!=="False")
				{
					$sOperationExInfo .= '<div class="operation-property"><span class="operation-property-label">' . _glt('Is query') . '</span>&nbsp;</div>';
				}
				if ( !strIsEmpty($sIsSynch) && $sIsSynch!=="False")
				{
					$sOperationExInfo .= '<div class="operation-property"><span class="operation-property-label">' . _glt('Is synchronized') . '</span>&nbsp;</div>';
				}
				$sOperationExInfo .= '</div>';
			}
			if (array_key_exists(("taggedvalues"), $a[$i]))
			{
				$aTV = $a[$i]['taggedvalues'];
				$sOperationExInfo .= '<div class="operation-taggedvalues">';
				$sOperationExInfo .= '<div id="operation-taggedvalues-' . $sGUID . '" ';
				$sOperationExInfo .=     ' class="operation-taggedvalues-header">' . _glt('Properties') . '</div>';
				$sOperationExInfo .= '<div class="operation-taggedvalues-items">';
				$iTVCnt = count($aTV);
				for ($iTV=0; $iTV<$iTVCnt; $iTV++)
				{
					$sOperationExInfo .= '<div class="operation-taggedvalue-item">';
					$sName = SafeGetArrayItem2Dim($aTV, $iTV, 'name');
					$sValue = SafeGetArrayItem2Dim($aTV, $iTV, 'value');
					$sNotes = SafeGetArrayItem2Dim($aTV, $iTV, 'notes');
					$sNotes = (substr($sNotes,0,8)=='Values: ') ? '' : $sNotes;
					if ($sValue==='<memo>')
					{
						$sValue = '';
					}
					$sName = htmlspecialchars($sName);
					$sValue = htmlspecialchars($sValue);
					$sNotes = htmlspecialchars($sNotes);
					$sOperationExInfo .= '<div class="operation-taggedvalue-data">' . $sName;
					if ( !strIsEmpty($sValue) )
					{
						$sOperationExInfo .= '&nbsp;=&nbsp;' . $sValue;
					}
					$sOperationExInfo .= '</div>';
					if ( !strIsEmpty($sNotes) )
					{
						$sOperationExInfo .= '<div class="operation-taggedvalue-notes">' . $sNotes . '</div>';
					}
					$sOperationExInfo .= '</div>';
				}
				$sOperationExInfo .= '</div>';
				$sOperationExInfo .= '</div>' . PHP_EOL;
			}
			if ( !strIsEmpty($sOperationExInfo) )
			{
				$sSectionName = 'collapsible-' . $sGUID;
				echo '<div id="' . $sSectionName . '" onclick="OnToggleCollapsibleSection(\'' . $sSectionName . '\')" ';
				echo     ' class="collapsible-section-header collapsible-section-header-closed" >';
				echo '<img alt="" src="images/spriteplaceholder.png" class="collapsible-section-header-closed-icon">';
				echo $sOperationItemHdr;
				echo '</div>';
				echo '<div class="collapsible-section w3-hide">';
				echo $sOperationExInfo;
				echo '</div>';
			}
			else
			{
				echo '<div class="non-collapsible-guid">';
				echo $sOperationItemHdr;
				echo '</div>';
			}
			echo '</div>' . PHP_EOL;
		}
		echo '</div>' . PHP_EOL;
	}
	function WriteSectionTaggedValues($a)
	{
		echo '<div id="taggedvalue-section">';
		$aTagGroups = array();
		$iCnt = count($a);
		for ($i=0;$i<$iCnt;$i++)
		{
			$sGroup  = SafeGetArrayItem2Dim($a, $i, 'group');
			if ($sGroup == '')
			{
				WriteTaggedValue($a, $i);
			}
			else
			{
				if (!in_array($sGroup, $aTagGroups)) {
					$aTagGroups[] = $sGroup;
				}
			}
		}
		asort($aTagGroups);
		foreach ($aTagGroups as $sCurrentGroup)
		{
			$sTVGroupHdr  = '<div class="taggedvalue-group-name">';
			$sTVGroupHdr .= '<div class="propsprite-taggedvaluegroup"></div>';
			$sTVGroupHdr .= '<div class="taggedvalue-name">' . $sCurrentGroup . '</div>';
			$sTVGroupHdr .= '</div>';
			echo '<div class="taggedvalue-group-item property-section-item">';
			$sCollapsibleGroupID = 'collapsible-group-' . $sCurrentGroup;
			echo '<div id="' . $sCollapsibleGroupID . '" onclick="OnToggleCollapsibleSection(\'' . $sCollapsibleGroupID . '\')" ';
			echo     ' class="collapsible-section-header collapsible-section-header-opened">';
				echo '<img alt="" src="images/spriteplaceholder.png" class="collapsible-section-header-opened-icon">';
			echo $sTVGroupHdr;
			echo '</div>';
			echo '<div class="collapsible-section w3-show">';
			$iCnt = count($a);
			for ($i=0;$i<$iCnt;$i++)
			{
				$sGroup  = SafeGetArrayItem2Dim($a, $i, 'group');
					if ($sGroup == $sCurrentGroup)
					{
						WriteTaggedValue($a, $i);
					}
			}
			echo '</div>';
			echo '</div>';
		}
		echo '</div>';
	}
	function WriteTaggedValue($a, $i)
	{
		echo '<div class="taggedvalue-item property-section-item">';
		$sName  = SafeGetArrayItem2Dim($a, $i, 'name');
		$sValue = SafeGetArrayItem2Dim($a, $i, 'value');
		$sNotes = SafeGetArrayItem2Dim($a, $i, 'notes');
		$sGUID  = SafeGetArrayItem2Dim($a, $i, 'guid');
		$aRefResource  = SafeGetArrayItem2Dim($a, $i, 'referredresource');
		if ($aRefResource !== '')
		{
			$sValue  = '';
			$refCount = count($aRefResource);
			$refName = '';
			$refGUID = '';
			$refType = '';
			$refResType = '';
			for ($i=0; $i<$refCount; $i++)
			{
				$refName = 	SafeGetArrayItem2Dim($aRefResource, $i, 'name');
				$refGUID = SafeGetArrayItem2Dim($aRefResource, $i, 'guid');
				$refType = SafeGetArrayItem2Dim($aRefResource, $i, 'type');
				$refResType = SafeGetArrayItem2Dim($aRefResource, $i, 'restype');
				$refImageURL = SafeGetArrayItem2Dim($aRefResource, $i, 'imageurl');
				$sValue .= '<a class="w3-link" onclick="load_object(\'' . $refGUID . '\',\'false\',\'\',\'\',\'' . ConvertStringToParameter($refName) . '\',\'' . $refImageURL . '\')">';
				$sValue .= '<img alt="" src="images/spriteplaceholder.png" class="' . GetObjectImageSpriteName($refImageURL) . '" style="float: none;">&nbsp;' . htmlspecialchars($refName);
				$sValue .= '</a>';
				if ($i !== $refCount-1)
				{
					$sValue .= ', ';
				}
			}
		}
		$sColon = "";
		if ($sValue==='<memo>')
		{
			$sValue = '';
			if (substr($sNotes,0,11)==='<Checklist>')
			{
				$aTV = ConvertTVXMLToArray($sNotes);
				$iTVCnt = count($aTV);
				if ($iTVCnt>0)
				{
					$sNotes  = '<table class="taggedvalue-notes-checklist"><tbody>';
					for ($iTV=0; $iTV<$iTVCnt; $iTV++)
					{
						$sSubValue	= SafeGetArrayItem2Dim($aTV, $iTV, 'checked');
						if ($sSubValue === "True")
						{
							$sSubValue	= '<img alt="True" src="images/spriteplaceholder.png" class="propsprite-tick">';
						}
						else
						{
							$sSubValue	= '<img alt="False" src="images/spriteplaceholder.png" class="propsprite-untick">';
						}
						$sSubName	= SafeGetArrayItem2Dim($aTV, $iTV, 'text');
						$sNotes    .= WriteLabelValueProperty($sSubValue, $sSubName, 'checklist-tickbox', 'checklist-text', false);
					}
					$sNotes .= '</tbody></table>';
				}
				else
				{
					$sNotes = htmlspecialchars($sNotes);
				}
			}
			else if (substr($sNotes,0,12)==='<MatrixData>')
			{
				$sNotes = '<Matrix Configuration Data>';
				$sNotes = htmlspecialchars($sNotes);
			}
			else if (substr($sNotes,0,11)==='<modelview>')
			{
				$sNotes = '<Model View Configuration Data>';
				$sNotes = htmlspecialchars($sNotes);
			}
			else if (substr($sNotes,0,17)==='<DocumentOptions>')
			{
				$sNotes = '<Document Generation Data>';
				$sNotes = htmlspecialchars($sNotes);
			}
			else if (substr($sNotes,0,12)==='<chart type=')
			{
				$sNotes = '<Chart Configuration Data>';
				$sNotes = htmlspecialchars($sNotes);
			}
			else
			{
				$sNotes = htmlspecialchars($sNotes);
			}
		}
		if (substr($sNotes,0,8)==='Values: ')
		{
			$sNotes = '';
		}
		if (substr($sNotes,0,14)==='<tagStructure>')
		{
			$sValue = '';
			$aTV = ConvertTVXMLToArray($sNotes);
			$iTVCnt = count($aTV);
			if ($iTVCnt>0)
			{
				$sNotes  = '<table class="taggedvalue-notes-stv"><tbody>';
				for ($iTV=0; $iTV<$iTVCnt; $iTV++)
				{
					$sSubName	= SafeGetArrayItem2Dim($aTV, $iTV, 'name');
					$sSubValue	= SafeGetArrayItem2Dim($aTV, $iTV, 'value');
					$sNotes    .= WriteLabelValueProperty($sSubName, $sSubValue, 'taggedvalue-label', 'taggedvalue-value', false);
				}
				$sNotes .= '</tbody></table>';
			}
			else
			{
				$sNotes = htmlspecialchars($sNotes);
				$sValue = htmlspecialchars($sValue);
			}
		}
		$sName = htmlspecialchars($sName);
		$sTVItemHdr  = '<div class="propsprite-taggedvalue"></div>';
		$sTVItemHdr .= '<div class="taggedvalue-name">';
		$sTVItemHdr .= $sName;
		$sTVItemHdr .= WriteValueInSentence($sValue, '&nbsp;:&nbsp;', '', false);
		$sTVItemHdr .= '</div>';
		if ( !strIsEmpty($sNotes) )
		{
			$sSectionName = 'collapsible-' . $sGUID;
			echo '<div id="' . $sSectionName . '" onclick="OnToggleCollapsibleSection(\'' . $sSectionName . '\')" ';
			echo     	' class="collapsible-section-header collapsible-section-header-closed">';
			echo '  <img alt="" src="images/spriteplaceholder.png" class="collapsible-section-header-closed-icon">';
			echo $sTVItemHdr;
			echo '</div>';
			echo '<div class="collapsible-section w3-hide">';
			echo '  <div class="taggedvalue-notes">' . $sNotes . '</div>';
			echo '</div>';
		}
		else
		{
			echo '<div class="non-collapsible-guid">';
			echo $sTVItemHdr;
			echo '</div>';
		}
		echo '</div>' . PHP_EOL;
	}
	function ConvertTVXMLToArray($sXML)
	{
		$aTV = array();
		$xmlDoc = new DOMDocument();
		$validXML = SafeXMLLoad($xmlDoc, $sXML);
		if ($xmlDoc !== null && $validXML)
		{
			$xnRoot = $xmlDoc->documentElement;
			if ($xnRoot->nodeName === 'tagStructure')
			{
				foreach ($xnRoot->childNodes as $xnProp)
				{
					$aRow		= array();
					GetXMLNodeValueAttr($xnProp, 'property', 'name', $aRow['name']);
					GetXMLNodeValue($xnProp, 'property', $aRow['value']);
					$aTV[] 		= $aRow;
				}
			}
			else if ($xnRoot->nodeName === 'Checklist')
			{
				foreach ($xnRoot->childNodes as $xnProp)
				{
					$aRow		= array();
					GetXMLNodeValueAttr($xnProp, 'Item', 'Text', $aRow['text']);
					GetXMLNodeValueAttr($xnProp, 'Item', 'Checked', $aRow['checked']);
					$aTV[] 		= $aRow;
				}
			}
		}
		return $aTV;
	}
	function WriteSectionTest($a, $sObjectGUID, $bObjectLocked, $sObjectName, $sObjectImageURL)
	{
		echo '<div id="test-section">';
		$iCnt = count($a);
		for ($i=0; $i<$iCnt; $i++)
		{
			$sTestItemExInfo = '';
			$sType 		= SafeGetArrayItem2Dim($a, $i, 'type');
			$sClassType = SafeGetArrayItem2Dim($a, $i, 'classtype');
			$sName	 	= SafeGetArrayItem2Dim($a, $i, 'name');
			$sGUID	 	= SafeGetArrayItem2Dim($a, $i, 'guid');
			$sStatus 	= SafeGetArrayItem2Dim($a, $i, 'status');
			$sLrun 		= SafeGetArrayItem2Dim($a, $i, 'lastrun');
			$sRunBy 	= SafeGetArrayItem2Dim($a, $i, 'runby');
			$sChkdBy 	= SafeGetArrayItem2Dim($a, $i, 'checkedby');
			echo '<div class="test-item property-section-item">';
			if ( !$bObjectLocked )
			{
				if ( IsSessionSettingTrue('login_perm_test') )
				{
					if (IsSessionSettingTrue('edit_objectfeature_tests'))
					{
						echo '<div class="test-item-edit">';
						echo '<input class="test-item-edit-button" type="button" value="&#160;" onclick="load_object(\'editelementtest\',\'false\',\'' . $sObjectGUID . '|' . ConvertStringToParameter($sName) . '\',\'' . $sClassType . '\',\'' . ConvertStringToParameter($sObjectName) .'\',\'' . $sObjectImageURL . '\')" />';
						echo '</div>';
					}
				}
			}
			$sTestItemHdr  = '<img alt="" src="images/spriteplaceholder.png" class="test-item-icon">';
			$sTestItemHdr .= '<div class="test-name">';
			$s = '';
			if ( !strIsEmpty($sType) )
				$s .= $sType . ' ';
			if ( !strIsEmpty($sClassType) )
				$s .= '<span class="test-classtype">' . $sClassType . '</span> ';
			if ( !strIsEmpty($s) )
			{
				$s = substr($s, 0, strlen($s)-1);
				$s .= '.  ';
			}
			$sTestItemHdr .= $s . $sName;
			$sTestItemHdr .= '</div>';
			$sTestItemHdr .= '<div class="test-runstate">';
			if ($sStatus==='Not Run' )
			{
				$sTestItemHdr .= '<img alt="" src="images/spriteplaceholder.png" class="test-runstate-notrun"><span style="padding-left: 10px;">' . _glt('Not run yet') . '</span>';
			}
			else
			{
				$sStatusClassName = mb_strtolower($sStatus);
				if ((stripos(',deferred,fail,not run yet,pass,cancelled,', ',' . $sStatusClassName . ',')!==false))
					$sStatusClassName = 'test-runstate-' . $sStatusClassName;
				else
					$sStatusClassName = 'test-runstate-userdef';
				$sTestItemHdr .= '<div class="test-runstate-status"><img alt="" src="images/spriteplaceholder.png" class="' . $sStatusClassName . '"><span style="padding-left: 10px;">' . $sStatus . '</span></div>';
			}
			$sTestItemHdr .= '</div>';
			if ( !strIsEmpty($sLrun) && !strIsEmpty($sRunBy) )
			{
				$sTestItemExInfo .= '<span class="test-status-label"> [ ' . _glt('Last Run at') . '</span>';
				$sTestItemExInfo .= '<span class="test-status-value">' . $sLrun . '</span>';
				$sTestItemExInfo .= '<span class="test-status-label"> ' . _glt('by') . ' </span><span class="test-status-value">' . htmlspecialchars($sRunBy) . '</span>';
				if ( !strIsEmpty($sChkdBy) )
				{
					$sTestItemExInfo .= '<span class="test-status-label">' . _glt('and checked by') . ' </span><span class="test-status-value">' . htmlspecialchars($sChkdBy) . '</span>';
				}
				$sTestItemExInfo .= '<span class="test-status-label"> ]</span>';
			}
			$sDesc = SafeGetArrayItem2Dim($a, $i, 'notes');
			$sInput = SafeGetArrayItem2Dim($a, $i, 'input');
			$sAccptCr = SafeGetArrayItem2Dim($a, $i, 'acceptance');
			$sResults = SafeGetArrayItem2Dim($a, $i, 'results');
			if ( !strIsEmpty($sDesc) )
			{
				$sTestItemExInfo .= '<div class="testblock-desc-label">' . _glt('Description') . ':</div><div class="testblock-desc">' . $sDesc . '</div>';
			}
			if ( !strIsEmpty($sInput) )
			{
				$sTestItemExInfo .= '<div class="testblock-input-label">' . _glt('Input') . ':</div><div class="testblock-input">' . $sInput . '</div>';
			}
			if ( !strIsEmpty($sAccptCr) )
			{
				$sTestItemExInfo .= '<div class="testblock-acceptance-label">' . _glt('Acceptance Criteria') . ':</div><div class="testblock-acceptance">'.$sAccptCr.'</div>';
			}
			if ( !strIsEmpty($sResults) )
			{
				$sTestItemExInfo .= '<div class="testblock-results-label">' . _glt('Results') . ':</div><div class="testblock-results">' . $sResults . '</div>';
			}
			if ( !strIsEmpty($sTestItemExInfo) )
			{
				$sSectionName = 'collapsible-' . $sGUID;
				echo '<div id="' . $sSectionName . '" onclick="OnToggleCollapsibleSection(\'' . $sSectionName . '\')" ';
				echo     ' class="collapsible-section-header collapsible-section-header-closed">';
				echo '<img alt="" src="images/spriteplaceholder.png" class="collapsible-section-header-closed-icon">';
				echo $sTestItemHdr . '</div>';
				echo '<div class="collapsible-section w3-hide">';
				echo '<div class="test-ex-info" >';
				echo $sTestItemExInfo;
				echo '</div>';
				echo '</div>';
			}
			else
			{
				echo '<div class="non-collapsible-guid">';
				echo $sTestItemHdr;
				echo '</div>';
			}
			echo '</div>'. PHP_EOL;
		}
		echo '</div>' . PHP_EOL;
	}
	function WriteSectionResourceAllocs($a, $sObjectGUID, $bObjectLocked, $sObjectName, $sObjectImageURL)
	{
		echo '<div id="resources-section">';
		$iCnt = count($a);
		for ($i=0;$i<$iCnt;$i++)
		{
			$sResource 	= SafeGetArrayItem2Dim($a, $i, 'resource');
			$sRole 		= SafeGetArrayItem2Dim($a, $i, 'role');
			$sGUID 		= SafeGetArrayItem2Dim($a, $i, 'guid');
			echo '<div class="resource-item property-section-item property-section-item">';
			if ( !$bObjectLocked )
			{
				if ( IsSessionSettingTrue('login_perm_resalloc') )
				{
					if (IsSessionSettingTrue('edit_objectfeature_resources'))
					{
						echo '<div class="resource-item-edit">';
						echo '<input class="resource-item-edit-button" type="button" value="&#160;" onclick="load_object(\'editelementresalloc\',\'false\',\'' .  $sObjectGUID . '|' . ConvertStringToParameter($sResource) . '\',\'' . ConvertStringToParameter($sRole) . '\',\'' . ConvertStringToParameter($sObjectName) .'\',\'' . $sObjectImageURL . '\')" />';
						echo '</div>';
					}
				}
			}
			$sResourceItemHdr  = '<img alt="" src="images/spriteplaceholder.png" class="resource-item-icon">';
			$sResourceItemHdr .= '<div class="resources-name">';
			$sResourceItemHdr .= htmlspecialchars($sResource) . '&nbsp;-&nbsp;' . htmlspecialchars($sRole) . '</div>';
			$sStartDt =  SafeGetArrayItem2Dim($a, $i, 'sdate');
			$sEndDt =  SafeGetArrayItem2Dim($a, $i, 'edate');
			if ( !strIsEmpty($sStartDt) || !strIsEmpty($sEndDt) )
			{
				$sResourceItemHdr .= '<div class="resources-dates1">';
				$sResourceItemHdr .= '<div class="resources-date-line">';
				if ( !strIsEmpty($sStartDt) )
				{
					$sResourceItemHdr .= '<span class="resources-date-value">' . $sStartDt . '&nbsp;</span>';
				}
				if ( !strIsEmpty($sEndDt) )
				{
					$sResourceItemHdr .= '<span class="resources-date-label2">' . _glt('until') . '</span><span class="resources-date-value">' . $sEndDt . '</span>';
				}
				$sResourceItemHdr .= '</div>';
				$sResourceItemHdr .= '</div>';
			}
			$sPercentage = SafeGetArrayItem2Dim($a, $i, 'percentage');
			$sPercentage = Trim($sPercentage, '.');
			if ( !strIsEmpty($sPercentage) )
			{
				$sResourceItemHdr .= '<div class="resources-dates2">';
				$sResourceItemHdr .= '<div class="resources-date-line">';
				$sResourceItemHdr .= '<span class="resources-date-value">' . $sPercentage . '&#37;&nbsp;</span><span class="resources-date-label">' . _glt('completed') . '</span>';
				$sResourceItemHdr .= '</div>';
				$sResourceItemHdr .= '</div>';
			}
			$sNotes 	= SafeGetArrayItem2Dim($a, $i, 'notes');
			$sHistory 	= SafeGetArrayItem2Dim($a, $i, 'history');
			$sAllocated = SafeGetArrayItem2Dim($a, $i, 'atime');
			$sExpected 	= SafeGetArrayItem2Dim($a, $i, 'exptime');
			$sExpended 	= SafeGetArrayItem2Dim($a, $i, 'expendtime');
			if ( !strIsEmpty($sNotes) || !strIsEmpty($sHistory) || (!strIsEmpty($sAllocated) && $sAllocated !== '0') ||
				(!strIsEmpty($sExpected) && $sExpected !== "0") || (!strIsEmpty($sExpended) && $sExpended !== "0"))
			{
				$sSectionName = 'collapsible-' . $sGUID;
				echo '<div id="' . $sSectionName . '" onclick="OnToggleCollapsibleSection(\'' . $sSectionName . '\')" ';
				echo     ' class="collapsible-section-header collapsible-section-header-closed">';
				echo '<img alt="" src="images/spriteplaceholder.png" class="collapsible-section-header-closed-icon">';
				echo $sResourceItemHdr;
				echo '</div>';
				echo '<div class="collapsible-section w3-hide">';
				if ( !strIsEmpty($sNotes) )
				{
					echo '<div class="resources-notes">' . $sNotes . '</div>';
				}
				if ( !strIsEmpty($sHistory) )
				{
					echo '<div class="resources-history-header">History: </div><div class="resources-history">' . $sHistory . '</div>';
				}
				if ( ( !strIsEmpty($sAllocated) && $sAllocated !== "0") ||
					 ( !strIsEmpty($sExpected) && $sExpected !== "0") ||
					 ( !strIsEmpty($sExpended) && $sExpended != "0") )
				{
					echo '<div class="resources-times-div"><div class="resources-times">';
					echo '<span class="resources-time-label"> (' . _glt('Actual') . ':</span><span class="resources-time-value">' . $sExpended . '</span>';
					echo '<span class="resources-time-label"> ' . _glt('Expected') . ':</span><span class="resources-time-value">' . $sExpected . '</span>';
					echo '<span class="resources-time-label"> ' . _glt('Time') . ':</span><span class="resources-time-value">' . $sAllocated . '</span><span class="resources-time-label"> )</span>';
					echo '</div></div>';
				}
				echo '</div>';
			}
			else
			{
				echo '<div class="non-collapsible-guid">';
				echo $sResourceItemHdr;
				echo '</div>';
			}
			echo '</div>'. PHP_EOL;
		}
		echo '</div>' . PHP_EOL;
	}
	function WriteSectionRunStates($a)
	{
		echo '<div id="runstate-section">';
		$iCnt = count($a);
		for ($i=0; $i<$iCnt; $i++)
		{
			$sName 			= SafeGetArrayItem2Dim($a, $i, 'name');
			$sGUID 			= SafeGetArrayItem2Dim($a, $i, 'guid');
			$sValue 		= SafeGetArrayItem2Dim($a, $i, 'value');
			$sOperator 		= SafeGetArrayItem2Dim($a, $i, 'operator');
			$sOperator 		= str_replace('<![CDATA[', '', $sOperator);
			$sOperator 		= str_replace("]]>","", $sOperator);
			$sName			= htmlspecialchars($sName);
			$sValue			= htmlspecialchars($sValue);
			$sOperator 		= htmlspecialchars($sOperator);
			echo '<div class="runstate-item property-section-item">';
			$sRunStateItemHdr  = '<div class="runstate-item-hdr">';
			$sRunStateItemHdr .= '<img alt="" src="images/spriteplaceholder.png" class="runstate-item-icon">';
			$sRunStateItemHdr .= '<div class="runstate-name">' . $sName;
			$sRunStateItemHdr .= WriteValueInSentence($sOperator, '&nbsp;', '&nbsp;', false);
			$sRunStateItemHdr .= WriteValueInSentence($sValue, '&nbsp;', '', false);
			$sRunStateItemHdr .= '</div>';
			$sRunStateItemHdr .= '</div>';
			$sNotes 		= SafeGetArrayItem2Dim($a, $i, 'notes');
			$sRunStateExInfo = '';
			if ( !strIsEmpty($sNotes) )
			{
				$sRunStateExInfo .= '<div class="runstate-notes">' . $sNotes . '</div>';
			}
			if ( !strIsEmpty($sRunStateExInfo) )
			{
				$sSectionName = 'collapsible-' . $sGUID;
				echo '<div id="' . $sSectionName . '" onclick="OnToggleCollapsibleSection(\'' . $sSectionName . '\')" ';
				echo     ' class="collapsible-section-header collapsible-section-header-closed">';
				echo '<img alt="" src="images/spriteplaceholder.png" class="collapsible-section-header-closed-icon">';
				echo $sRunStateItemHdr;
				echo '</div>';
				echo '<div class="collapsible-section w3-hide">';
				echo $sRunStateExInfo;
				echo '</div>';
			}
			else
			{
				echo '<div class="non-collapsible-guid">';
				echo $sRunStateItemHdr;
				echo '</div>';
			}
			echo '</div>' . PHP_EOL;
		}
		echo '</div>' . PHP_EOL;
	}
	function WriteSectionLocation($sInternalName, $sSectionName, $sDefault, $aP, $a)
	{
		if (empty($aP) && count($a) <= 0)
		{
			return;
		}
		WritePropertySectionContentHeader($sInternalName, $sSectionName, $sDefault);
		if (empty($aP) === false)
		{
			$sName 		= SafeGetArrayItem1Dim($aP, 'text');
			$sName 		= GetPlainDisplayName($sName);
			$sGUID 		= SafeGetArrayItem1Dim($aP, 'guid');
			$sResType 	= SafeGetArrayItem1Dim($aP, 'restype');
			$sImageURL	= SafeGetArrayItem1Dim($aP, 'imageurl');
			if ( strIsEmpty($sGUID) && $sName===_glt('<Unnamed object>'))
			{
				SafeStartSession();
				$sName = isset($_SESSION['model_name']) ? htmlspecialchars($_SESSION['model_name']) : 'Home';
			}
			echo '<div id="parent-section">';
			echo '<div class="parent-desc w3-link" onclick="load_object(\'' . $sGUID . '\',\'true\',\'\',\'\',\'' . ConvertStringToParameter($sName) . '\',\'' . $sImageURL . '\')">';
			echo '<img alt="" title="' . $sResType . '" src="images/spriteplaceholder.png" class="' . GetObjectImageSpriteName($sImageURL) . '"> ' . htmlspecialchars($sName);
			echo '</div>';
			echo '</div>' . PHP_EOL;
		}
		$iCnt = count($a);
		if ($iCnt > 0)
		{
			$sName 		= '';
			$sGUID 		= '';
			$sImageURL	= '';
			echo '<div class="usage-section">';
			echo '<table class="usage-table">';
			for ($i=0; $i<$iCnt; $i++)
			{
				$sName = SafeGetArrayItem2Dim($a, $i, 'name');
				$sGUID = SafeGetArrayItem2Dim($a, $i, 'guid');
				$sImageURL = SafeGetArrayItem2Dim($a, $i, 'imageurl');
				echo '<tr><td class="usage-name w3-link" onclick="load_object(\'' . $sGUID . '\',\'false\',\'\',\'\',\'' . ConvertStringToParameter($sName) . '\',\'' . $sImageURL . '\')" >';
				echo '<img alt="" title="Diagram" src="images/spriteplaceholder.png" class="' . GetObjectImageSpriteName($sImageURL) . '"> ' . htmlspecialchars($sName);
				echo '</td></tr>'. PHP_EOL;
			}
			echo '</table>';
			echo '</div>' . PHP_EOL;
		}
		echo '</div>';
	}
	function WriteSectionRelationships($sInternalName, $sSectionName, $sDefault, $a)
	{
		if (count($a) <= 0)
		{
			return;
		}
		WritePropertySectionContentHeader($sInternalName, $sSectionName, $sDefault);
		$iCnt = count($a);
		if ($iCnt > 0)
		{
			echo '<div id="relationship-section">';
			$iOutCnt = 0;
			$iInCnt = 0;
			for ($i=0; $i<$iCnt; $i++)
			{
				$sLinkDirection	= SafeGetArrayItem2Dim($a, $i, 'linkdirection');
				if ($sLinkDirection	=== 'Outgoing')
				{
					$iOutCnt = $iOutCnt + 1;
				}
				if ($sLinkDirection	=== 'Incoming')
				{
					$iInCnt = $iInCnt + 1;
				}
			}
			if ( $iOutCnt > 0 )
			{
				echo '<div class="relationship-outgoing">';
				for ($i=0; $i<$iCnt; $i++)
				{
					$sLinkDirection	= SafeGetArrayItem2Dim($a, $i, 'linkdirection');
					if ($sLinkDirection	=== 'Outgoing')
					{
						$sConnectorName = SafeGetArrayItem2Dim($a, $i, 'connectorname');
						$sConnectorType = SafeGetArrayItem2Dim($a, $i, 'connectortype');
						$sConnectorName2= $sConnectorType . ' connector ' . $sConnectorName;
						$sConnectorGUID = SafeGetArrayItem2Dim($a, $i, 'connectorguid');
						$sConnectorImageURL = SafeGetArrayItem2Dim($a, $i, 'connectorimageurl');
						$sElementName 	= SafeGetArrayItem2Dim($a, $i, 'elementname');
						$sElementName 	= GetPlainDisplayName($sElementName);
						$sElementGUID 	= SafeGetArrayItem2Dim($a, $i, 'elementguid');
						$sElementImageURL = SafeGetArrayItem2Dim($a, $i, 'elementimageurl');
						$sDirection 	= SafeGetArrayItem2Dim($a, $i, 'direction');
						echo '<div class="relationship-item">';
						echo '<img alt="" src="images/spriteplaceholder.png" class="relationship-item-out">';
						echo '<a class="w3-link" onclick="load_object(\'' . $sConnectorGUID . '\',\'false\',\'\',\'\',\'' . ConvertStringToParameter($sConnectorName2) . '\',\'' . $sConnectorImageURL . '\')">';
						echo $sConnectorType . '</a>';
						echo '&nbsp;' . _glt('to') . '&nbsp;';
						echo '<a class="w3-link" onclick="load_object(\'' . $sElementGUID . '\',\'false\',\'\',\'\',\'' . ConvertStringToParameter($sElementName) . '\',\'' . $sElementImageURL . '\')">';
						echo '<img src="images/spriteplaceholder.png" class="' . GetObjectImageSpriteName($sElementImageURL) . '" alt="">&nbsp;';
						echo htmlspecialchars($sElementName);
						echo '</a>';
						echo '</div>'. PHP_EOL;
					}
				}
				echo '</div>';
			}
			if ( $iInCnt > 0 )
			{
				echo '<div class="relationship-incoming">';
				for ($i=0; $i<$iCnt; $i++)
				{
					$sLinkDirection	= SafeGetArrayItem2Dim($a, $i, 'linkdirection');
					if ($sLinkDirection	=== 'Incoming')
					{
						$sConnectorName = SafeGetArrayItem2Dim($a, $i, 'connectorname');
						$sConnectorType = SafeGetArrayItem2Dim($a, $i, 'connectortype');
						$sConnectorName2= $sConnectorType . ' connector ' . $sConnectorName;
						$sConnectorGUID = SafeGetArrayItem2Dim($a, $i, 'connectorguid');
						$sConnectorImageURL = SafeGetArrayItem2Dim($a, $i, 'connectorimageurl');
						$sElementName 	= SafeGetArrayItem2Dim($a, $i, 'elementname');
						$sElementName 	= GetPlainDisplayName($sElementName);
						$sElementGUID 	= SafeGetArrayItem2Dim($a, $i, 'elementguid');
						$sElementImageURL = SafeGetArrayItem2Dim($a, $i, 'elementimageurl');
						$sDirection 	= SafeGetArrayItem2Dim($a, $i, 'direction');
						echo '<div class="relationship-item">';
						echo '<img alt="" src="images/spriteplaceholder.png" class="relationship-item-in">';
						echo '<a class="w3-link" onclick="load_object(\'' . $sConnectorGUID . '\',\'false\',\'\',\'\',\'' . ConvertStringToParameter($sConnectorName2) . '\',\'' . $sConnectorImageURL . '\')">';
						echo $sConnectorType . '</a>';
						echo '&nbsp;' . _glt('from') . '&nbsp;';
						echo '<a class="w3-link" onclick="load_object(\'' . $sElementGUID . '\',\'false\',\'\',\'\',\'' . ConvertStringToParameter($sElementName) . '\',\'' . $sElementImageURL . '\')">';
						echo '<img src="images/spriteplaceholder.png" class="' . GetObjectImageSpriteName($sElementImageURL) . '" alt="">&nbsp;';
						echo htmlspecialchars($sElementName);
						echo '</a>';
						echo '</div>'. PHP_EOL;
					}
				}
				echo '</div>';
			}
			echo '</div>' . PHP_EOL;
		}
		echo '</div>';
	}
	function WriteSectionChangeManagement1($a, $sChgMgmtType)
	{
		$sDate1FieldName = 'requestedon';
		$sDate2FieldName = 'completedon';
		$sPerson1FieldName = 'requestedby';
		$sPerson2FieldName = 'completedby';
		$sPerson1Desc = _glt('Requested by');
		$sPerson2Desc = _glt('Completed by');
		if ( $sChgMgmtType === 'defect' || $sChgMgmtType === 'event' )
		{
			$sDate1FieldName = 'reportedon';
			$sDate2FieldName = 'resolvedon';
			$sPerson1FieldName = 'reportedby';
			$sPerson2FieldName = 'resolvedby';
			$sPerson1Desc = _glt('Reported by');
			$sPerson2Desc = _glt('Resolved by');
		}
		elseif ( $sChgMgmtType === 'issue' )
		{
			$sDate1FieldName = 'raisedon';
			$sDate2FieldName = 'completedon';
			$sPerson1FieldName = 'raisedby';
			$sPerson2FieldName = 'completedby';
			$sPerson1Desc = _glt('Raised by');
			$sPerson2Desc = _glt('Completed by');
		}
		elseif ( $sChgMgmtType === 'decision' )
		{
			$sDate1FieldName = 'date';
			$sDate2FieldName = 'effective';
			$sPerson1FieldName = 'owner';
			$sPerson2FieldName = 'author';
			$sPerson1Desc = _glt('Owner');
			$sPerson2Desc = _glt('Author');
		}
		echo '<div id="' . $sChgMgmtType . '-section">';
		$iCnt = count($a);
		for ($i=0;$i<$iCnt;$i++)
		{
			$sName	 	= SafeGetArrayItem2Dim($a, $i, 'name');
			$sStatus	= SafeGetArrayItem2Dim($a, $i, 'status');
			$sPriority	= SafeGetArrayItem2Dim($a, $i, 'priority');
			$sGUID 		= SafeGetArrayItem2Dim($a, $i, 'guid');
			$sName		= htmlspecialchars($sName);
			echo '<div class="' . $sChgMgmtType . '-item property-section-item">';
			$sItemHdr  	= '<img alt="" src="images/spriteplaceholder.png" class="' . $sChgMgmtType . '-item-icon">';
			$sItemHdr  .= '<div class="chgmgmt-name">';
			if ( !strIsEmpty($sStatus) )
				$sItemHdr .= $sStatus . ', ';
			if ( !strIsEmpty($sPriority) )
				$sItemHdr .= $sPriority . ' ' . _glt('priority') . '.  ';
			$sItemHdr  .=  $sName . ' </div>';
			$sDate1 	=  SafeGetArrayItem2Dim($a, $i, $sDate1FieldName);
			$sDate2 	=  SafeGetArrayItem2Dim($a, $i, $sDate2FieldName);
			if ( !strIsEmpty($sDate1) || !strIsEmpty($sDate2) )
			{
				$sItemHdr .= '<div class="chgmgmt-dates1">';
				$sItemHdr .= '<div class="chgmgmt-date-line">';
				if ( !strIsEmpty($sDate1) )
				{
					$sItemHdr .= '<span class="chgmgmt-date-value">' . $sDate1 . '&nbsp;</span>';
				}
				if ( !strIsEmpty($sDate2) )
				{
					$sItemHdr .= '<span class="chgmgmt-date-label2">' . _glt('until') . '</span><span class="chgmgmt-date-value">' . $sDate2 . '</span>';
				}
				$sItemHdr .= '</div>';
				$sItemHdr .= '</div>';
			}
			$sNotes 	= SafeGetArrayItem2Dim($a, $i, 'notes');
			$sHistory 	= SafeGetArrayItem2Dim($a, $i, 'history');
			$sPerson1 	=  SafeGetArrayItem2Dim($a, $i, $sPerson1FieldName);
			$sPerson2 	=  SafeGetArrayItem2Dim($a, $i, $sPerson2FieldName);
			$sVersion 	=  SafeGetArrayItem2Dim($a, $i, 'version');
			$sPerson1	= htmlspecialchars($sPerson1);
			$sPerson2	= htmlspecialchars($sPerson2);
			$sVersion	= htmlspecialchars($sVersion);
			if (!strIsEmpty($sNotes) || !strIsEmpty($sHistory) || !strIsEmpty($sPerson1) || !strIsEmpty($sPerson2) || !strIsEmpty($sVersion) )
			{
				$sSectionName = 'collapsible-' . $sGUID;
				echo '<div id="' . $sSectionName . '" onclick="OnToggleCollapsibleSection(\'' . $sSectionName . '\')" ';
				echo     ' class="collapsible-section-header collapsible-section-header-closed">';
				echo '<img alt="" src="images/spriteplaceholder.png" class="collapsible-section-header-closed-icon">';
				echo $sItemHdr;
				echo '</div>';
				echo '<div class="collapsible-section w3-hide">';
				if ( !strIsEmpty($sNotes) )
				{
					echo '<div class="chgmgmt-notes">' . $sNotes . '</div>';
				}
				if ( !strIsEmpty($sHistory) )
				{
					echo '<div class="chgmgmt-history-header">' . _glt('History') . ': </div><div class="chgmgmt-history">' . $sHistory . '</div>';
				}
				if ( !strIsEmpty($sPerson1) || !strIsEmpty($sPerson2) || !strIsEmpty($sVersion) )
				{
					echo '<div class="chgmgmt-times-div"><div class="chgmgmt-times">';
					echo '<span class="chgmgmt-time-label"> [ </span>';
					if ( !strIsEmpty($sPerson1) )
						echo '<span class="chgmgmt-time-label"> ' . $sPerson1Desc . ' </span><span class="chgmgmt-time-value"> ' . $sPerson1 . '.</span>&nbsp;';
					if ( !strIsEmpty($sPerson2) )
						echo '<span class="chgmgmt-time-label"> ' . $sPerson2Desc . ' </span><span class="chgmgmt-time-value"> ' . $sPerson2 . '.</span>&nbsp;';
					if ( !strIsEmpty($sVersion) )
						echo '<span class="chgmgmt-time-label"> ' . _glt('Version') . ':</span><span class="chgmgmt-time-value"> ' . $sVersion . '.</span>&nbsp;';
					echo '<span class="chgmgmt-time-label"> ]</span>';
					echo '</div></div>';
				}
				echo '</div>';
			}
			else
			{
				echo '<div class="non-collapsible-guid">';
				echo $sItemHdr;
				echo '</div>';
			}
			echo '</div>'. PHP_EOL;
		}
		echo '</div>' . PHP_EOL;
	}
	function WriteSectionChangeManagement2($a, $sChgMgmtType)
	{
		echo '<div id="' . $sChgMgmtType . '-section">';
		$iCnt = count($a);
		for ($i=0;$i<$iCnt;$i++)
		{
			$sName	 	= SafeGetArrayItem2Dim($a, $i, 'name');
			$sNotes		= SafeGetArrayItem2Dim($a, $i, 'notes');
			$sType		= SafeGetArrayItem2Dim($a, $i, 'type');
			$sWeight	= SafeGetArrayItem2Dim($a, $i, 'weight');
			$sGUID 		= SafeGetArrayItem2Dim($a, $i, 'guid');
			$sName	= htmlspecialchars($sName);
			echo '<div class="' . $sChgMgmtType . '-item property-section-item">';
			$sItemHdr  	= '<img alt="" src="images/spriteplaceholder.png" class="' . $sChgMgmtType . '-item-icon">';
			$sItemHdr  .= '<div class="chgmgmt-name">';
			if ( !strIsEmpty($sType) )
				$sItemHdr .= $sType . ' ' . $sChgMgmtType . '.  ';
			$sItemHdr  .=  $sName . ' </div>';
			if ( !strIsEmpty($sNotes) || (!strIsEmpty($sWeight) && $sWeight !== "0" ) )
			{
				$sSectionName = 'collapsible-' . $sGUID;
				echo '<div id="' . $sSectionName . '" onclick="OnToggleCollapsibleSection(\'' . $sSectionName . '\')" ';
				echo     ' class="collapsible-section-header collapsible-section-header-closed">';
				echo '<img alt="" src="images/spriteplaceholder.png" class="collapsible-section-header-closed-icon">';
				echo $sItemHdr;
				echo '</div>';
				echo '<div class="collapsible-section w3-hide">';
				if ( !strIsEmpty($sNotes) )
				{
					echo '<div class="chgmgmt-notes">' . $sNotes . '</div>';
				}
				if ( !strIsEmpty($sWeight) && $sWeight !== "0" )
				{
					echo '<div class="chgmgmt-times-div"><div class="chgmgmt-times">';
					echo '<span class="chgmgmt-time-label"> [ </span>';
					echo '<span class="chgmgmt-time-label"> Weight is </span><span class="chgmgmt-time-value"> ' . number_format($sWeight, 2, '.', '') . '</span>&nbsp;';
					echo '<span class="chgmgmt-time-label">]</span>';
					echo '</div></div>';
				}
				echo '</div>';
			}
			else
			{
				echo '<div class="non-collapsible-guid">';
				echo $sItemHdr;
				echo '</div>';
			}
			echo '</div>'. PHP_EOL;
		}
		echo '</div>' . PHP_EOL;
	}
?>