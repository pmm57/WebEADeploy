<?php
// --------------------------------------------------------
//  This is a part of the Sparx Systems Pro Cloud Server.
//  Copyright (C) Sparx Systems Pty Ltd
//  All rights reserved.
//
//  This source code can be used only under terms and 
//  conditions of the accompanying license agreement.
// --------------------------------------------------------
	require_once 'globals.php';
	SafeStartSession();
	if (isset($_SESSION['authorized']) === false)
	{
		setResponseCode(440);
		exit();
	}
	$sCurrGUID 		= isset($_POST['guid']) ? $_POST['guid'] : '';
	$sCurrHasChild 	= isset($_POST['haschild']) ? $_POST['haschild'] : '';
	$sCurrLinkType 	= isset($_POST['linktype']) ? $_POST['linktype'] : '';
	$sCurrHyper 	= isset($_POST['hyper']) ? $_POST['hyper'] : '';
	$sCurrName	 	= isset($_POST['name']) ? $_POST['name'] : '';
	$sCurrImageURL 	= isset($_POST['imageurl']) ? $_POST['imageurl'] : '';
	$sCurrResType	= GetResTypeFromGUID($sCurrGUID);
	$sCurrName 		= GetPlainDisplayName($sCurrName);
	$bShowHomeWithoutLink = true;
	$sHome = isset($_SESSION['model_name']) ? htmlspecialchars($_SESSION['model_name']) : 'Home';
	echo '<div class="navbar">';
	echo '<div id="navbar-busy-loader">';
	echo '<img src="images/navbarwait.gif" alt="" class="navbar-spinner" height="26" width="26">';
	echo '</div>';
	echo '<div class="navbar-panel-left" id="navbar-panel-left">';
	$sRefreshLink = 'refresh_current()';
	echo '<div id="navbar-refresh-button" title="' . _glt('Refresh the current view') . '" onclick="' . $sRefreshLink. '"><div><div class="mainsprite-refresh24grey">&#160;</div></div></div>';
	echo '<div class="navbar-spacer"><img alt="|" src="images/spriteplaceholder.png" class="mainsprite-bar36"></div>';
	echo '<div class="navbar-spacer-2"><img alt="|" src="images/spriteplaceholder.png" class="mainsprite-bar36"></div>';
	$bCurrentShown = false;
	if ( IsGUIDAddEditAction($sCurrGUID)  )
	{
		$sImageClass = '';
		$sText = '';
		echo '<div id="navbar-current-name"><div id="navbar-current-name-text">';
		if ( $sCurrGUID==='addelement' )
		{
			$sImageClass = 'element16-add';
			$sText = _glt('Add element to');
		}
		elseif ( $sCurrGUID==='addelementtest' )
		{
			$sImageClass = 'propsprite-testadd';
			$sText = _glt('Add Test to');
		}
		elseif ( $sCurrGUID==='addelementresalloc' )
		{
			$sImageClass = 'propsprite-resallocadd';
			$sText = _glt('Add resource allocation to');
		}
		elseif ( $sCurrGUID==='addelementchgmgmt' )
		{
			$sObjectGUID = '';
			$sChangeMgtType = '';
			list($sObjectGUID, $sChangeMgtType) = explode('|', $sCurrLinkType);
			$sObjectGUID = trim($sObjectGUID);
			$sChangeMgtType = trim($sChangeMgtType);
			GetChgMgtAddText($sChangeMgtType, $sText, $sImageClass);
		}
		elseif ( $sCurrGUID==='editelementnote' )
		{
			$sImageClass = 'propsprite-noteedit';
			$sText = _glt('Edit note for');
		}
		elseif ( $sCurrGUID==='editelementtest' )
		{
			$sImageClass = 'propsprite-testedit';
			$sText = _glt('Edit Test for');
		}
		elseif ( $sCurrGUID==='editelementresalloc' )
		{
			$sImageClass = 'propsprite-resallocedit';
			$sText = _glt('Edit resource allocation for');
		}
		$sName = htmlspecialchars($sCurrName);
		echo '<img alt="" src="images/spriteplaceholder.png" class="' . $sImageClass . '">&nbsp;' . $sText . '&nbsp;';
		echo '<img alt="" src="images/spriteplaceholder.png" class="' . GetObjectImageSpriteName(AdjustImagePath($sCurrImageURL, '16')) . '">&nbsp;' . $sName . '&nbsp;';
		echo '</div></div>';
		$bCurrentShown = true;
	}
	else if ( !strIsEmpty($sCurrResType) )
	{
		$sName = htmlspecialchars($sCurrName);
		echo '<div id="navbar-current-name"><div id="navbar-current-name-text">';
		$sImagePath = AdjustImagePath($sCurrImageURL, '16');
		if ( $sCurrLinkType === 'document' )
		{
			echo '<img alt="" src="images/spriteplaceholder.png" class="element16-document">&nbsp;' . _glt('Linked Document for') . '&nbsp;';
		}
		elseif ( $sCurrLinkType === 'encryptdoc' )
		{
			echo _glt('Encrypted Document for') . '&nbsp;';
		}
		$sPrefix = substr($sCurrGUID,0,4);
		if ($sPrefix === 'lt_{')
		{
			$s = trim($sName);
			$a = explode(' ', $s);
			if (count($a)>1)
			{
				$a[0] = _glt($a[0]);
				$a[1] = _glt($a[1]);
			}
			$sName = implode(' ', $a);
			$sName = htmlspecialchars($sCurrName);
		}
		elseif ($sPrefix !== 'mr_{' && $sPrefix !== 'pk_{' && $sPrefix !== 'dg_{' && $sPrefix !== 'di_{' && $sPrefix !== 'el_{')
		{
			$sName = _glt($sName);
			$sName = htmlspecialchars($sCurrName);
		}
		echo '<img alt="" title="' . $sCurrResType . '" src="images/spriteplaceholder.png" class="' . GetObjectImageSpriteName($sImagePath) . '">&nbsp;' . $sName . '&nbsp;';
		echo '</div></div>';
		$bCurrentShown = true;
	}
	if ($bCurrentShown === false)
	{
		echo '<div id="navbar-current-name"><div id="navbar-current-name-text"><img src="images/spriteplaceholder.png" class="mainsprite-root">&nbsp;' . $sHome . '&nbsp;</div></div>';
	}
	echo '</div>';
	echo '<div class="navbar-panel-right" id="navbar-panel-right">';
	echo '<div id="navbar-expand-button" title="' . _glt('Expand the Navigation Bar') . '" onclick="expand_navbar()"><div><div class="mainsprite-navbarexpand">&#160;</div></div></div>';
	echo '<div id="navbar-collapse-button" title="' . _glt('Collapse the Navigation Bar') . '" onclick="collapse_navbar()"><div><div class="mainsprite-navbarcollapse">&#160;</div></div></div>';
	echo '<div class="navbar-spacer-2"><img alt="|" src="images/spriteplaceholder.png" class="mainsprite-bar36"></div>';
	echo '<div id="navbar-home-button" title="' . _glt('Navigate to initial page') . '" onclick="load_home()"><div><div class="mainsprite-home24">&#160;</div></div></div>';
	echo '<div class="navbar-path-dropdown">';
	echo '<div id="navbar-path-button" title="' . _glt('Complete path to root node') . '" onclick="show_path()"><div><div class="mainsprite-path">&#160;</div></div></div>';
	echo '<div id="path-menu">';
	echo '<div class="contextmenu-arrow-bottom"></div><div class="contextmenu-arrow-top"></div>';
	echo '<div class="contextmenu-content">';
	echo '<div class="contextmenu-header">Path</div>';
	include('objectpath.php');
	echo '</div>';
	echo '</div>';
	echo '</div>';
	$sFirst3Chars 	= substr($sCurrGUID,0 ,3);
	if ( $sFirst3Chars === 'mr_' ||
		 $sFirst3Chars === 'pk_' ||
		 $sFirst3Chars === 'dg_' ||
		 $sFirst3Chars === 'el_' )
	{
		$sPlainGUID = substr($sCurrGUID, 4);
		$sPlainGUID = trim($sPlainGUID, '{}');
		$sFullURL  = ((isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') ? 'https' : 'http');
		$sFullURL .= '://' . $_SERVER['HTTP_HOST'];
		$sWebsiteRoot = '';
		$sDocPath = isset($_SERVER['REQUEST_URI']) ? $_SERVER['REQUEST_URI'] : '';
		$iLastPos = strripos($sDocPath, '/');
		if ( $iLastPos !== FALSE )
		{
			if ( $iLastPos > 0 )
			{
				$sWebsiteRoot = substr($sDocPath, 0, $iLastPos);
			}
		}
		$sFullURL .= $sWebsiteRoot;
		$sFullURL .= '?m=' . SafeGetInternalArrayParameter($_SESSION, 'model_no', '');
		$sFullURL .= '&o=' . $sPlainGUID;
		echo '<div id="navbar-share-button" title="' . _glt('Obtain direct link to the current page') . '" onclick="OnShowCurrentLink(\'' . $sPlainGUID . '\',\'' . $sFullURL . '\')"><div><div class="mainsprite-showlink">&#160;</div></div></div>';
	}
	else
	{
		echo '<div id="navbar-share-button" title="' . _glt('Obtain direct link to the current page') . '"><div><div class="mainsprite-showlink">&#160;</div></div></div>';
	}
	if (isset($sResType))
	{
		if ($sResType === 'Diagram')
		{
				if ($sCurrLinkType === 'edit')
				{
				}
				else
				{
				}
		}
	}
		if (isset($sResType))
	{
		$gLog->Write2Log('RES = '. $sResType );
		$gLog->Write2Log('LINK = '. $sCurrLinkType);
		if ($sResType === 'Diagram')
		{
				if ($sCurrLinkType === 'edit')
				{
				}
		}
	}
	echo '<div class="navbar-spacer"><img alt="|" src="images/spriteplaceholder.png" class="mainsprite-bar36"></div>';
	if (( ( $sCurrResType === "Diagram" || $sCurrResType === "Package") && $sCurrLinkType !== "props") ||
		( (	$sCurrResType === "Element" && ($sCurrHasChild === "true" || $sCurrLinkType === "child") ) ) )
	{
		$sLoadInfo = 'load_object(\'' . $sCurrGUID . '\', \'' . $sCurrHasChild . '\', \'props\', \'' . $sCurrHyper . '\', \'' . ConvertStringToParameter($sCurrName) . '\', \'' . $sCurrImageURL . '\')';
		echo '<div id="navbar-info-button" title="' . _glt('View the object properties') . '" onclick="' . $sLoadInfo . '"><div><div class="mainsprite-info">&#160;</div></div></div>';
	}
	else
	{
		echo '<div id="navbar-info-button" disabled=""><div class="mainsprite-info">&#160;</div></div>';
	}
	echo '<div class="navbar-spacer-2"><img alt="|" src="images/spriteplaceholder.png" class="mainsprite-bar36"></div>';
	echo '<div class="navbar-search-dropdown">';
	echo '  <input id="navbar-search-button" value="&nbsp;" type="button" title="Search" onclick="show_navbar_search()">';
	echo '	<div id="navbar-search-menu">';
	echo '	  <div class="contextmenu-arrow-bottom"></div><div class="contextmenu-arrow-top"></div>';
	echo '	  <div class="contextmenu-content">';
	echo '		<div class="contextmenu-header">' . _glt('Search') . '</div>';
	echo '		<div class="contextmenu-items">';
	$iDays = SafeGetArrayItem1DimInt($_SESSION, 'recent_search_days');
	if ( $iDays == 0 )
	{
		$iDays = 3;
	}
	$sDays = (string)$iDays;
	echo '		  <div class="contextmenu-item" onclick="OnPromptForGotoGUID()"><img alt="" src="images/spriteplaceholder.png" class="mainsprite-gotolink">' . _glt('Goto item') . '</div>';
	echo '		  <hr>';
	echo '		  <div class="contextmenu-item" onclick="OnRunPrefinedSearch(\'category=review&term=&recent=-' . $sDays. 'd\',\'' . _glt('Search Results') . '\')"><img alt="" title="' . _glt('Display list of recent reviews') . '" src="images/spriteplaceholder.png" class="mainsprite-recentreview">' . _glt('Reviews') . '</div>';
	echo '		  <div class="contextmenu-item" onclick="OnRunPrefinedSearch(\'category=discussion&term=&recent=-' . $sDays. 'd\',\'' . _glt('Search Results') . '\')"><img alt="" title="' . _glt('Display list of discussions') . '" src="images/spriteplaceholder.png" class="mainsprite-recentdiscuss">' . _glt('Discussions') . '</div>';
	echo '		  <hr>';
	echo '		  <div class="contextmenu-item" onclick="OnRunPrefinedSearch(\'category=diagram&term=&recent=-' . $sDays. 'd\',\'' . _glt('Search Results') . '\')"><img alt="" title="' . _glt('Display list of recently modified diagrams') . '" src="images/spriteplaceholder.png" class="mainsprite-recentdiagram">' . _glt('Diagrams') . '</div>';
	echo '		  <div class="contextmenu-item" onclick="OnRunPrefinedSearch(\'category=element&term=&recent=-' . $sDays. 'd\',\'' . _glt('Search Results') . '\')"><img alt="" title="' . _glt('Display list of recently modified elements') . '" src="images/spriteplaceholder.png" class="mainsprite-recentelement">' . _glt('Elements') . '</div>';
	echo '		  <div class="contextmenu-item" onclick="load_object(\'watchlist\',\'\',\'\',\'\',\'' . _glt('Watchlist') . '\',\'images/element16/watchlist.png\')"><img alt="" src="images/spriteplaceholder.png" class="mainsprite-watchlist16color">' . _glt('Watchlist') . '</div>';
	echo '		  <hr>';
	echo '		  <div class="contextmenu-item" onclick="load_object(\'search\',\'\',\'\',\'\',\'' . _glt('Search') . '\',\'images/element16/search.png\')"><img alt="" src="images/spriteplaceholder.png" class="mainsprite-search16color">' . _glt('Custom search') . '</div>';
	echo '		</div>';
	echo '	  </div>';
	echo '	</div>';
	echo '</div>';
	$sMainLayoutNo = SafeGetInternalArrayParameter($_SESSION, 'mainlayout', '1');
	$sShowRadioIcons = 'class="hamburger-radio-icon"';
	$sShowRadioList = '';
	$sShowRadioNotes = '';
	if ($sMainLayoutNo === '2')
	{
		$sShowRadioIcons = '';
		$sShowRadioList = 'class="hamburger-radio-icon"';
	}
	elseif ($sMainLayoutNo === '3')
	{
		$sShowRadioIcons = '';
		$sShowRadioNotes = 'class="hamburger-radio-icon"';
	}
	echo '<div class="navbar-hamburger-dropdown">';
	echo '  <input id="navbar-hamburger-button" value="&nbsp;" type="button" title="Complete path back to root node" onclick="show_navbar_hamburger()">';
	echo '  <div id="navbar-hamburger-menu">';
	echo '	  <div class = "contextmenu-arrow-bottom"></div><div class = "contextmenu-arrow-top"></div>';
	echo '	  <div class="contextmenu-content">';
	echo '		<div class="contextmenu-header">' . _glt('Menu') . '</div>';
	echo '		<div class="contextmenu-items">';
	echo '		  <div id="contextmenu-package">';
	echo '		    <div class="contextmenu-items-hdr">' . _glt('Package Layout') . '</div>';
	echo '		    <div class="contextmenu-item" onclick="set_main_layout(\'1\')"><div id="main-layout-icons" '.$sShowRadioIcons.'><div id="hamburger-iconview-icon"><div class="hamburger-item-text">' . _glt('Icon view') . '</div></div></div></div>';
	echo '		    <div class="contextmenu-item" onclick="set_main_layout(\'2\')"><div id="main-layout-list" '.$sShowRadioList.'><div id="hamburger-listview-icon"><div class="hamburger-item-text">' . _glt('List view') . '</div></div></div></div>';
	echo '		    <div class="contextmenu-item" onclick="set_main_layout(\'3\')"><div id="main-layout-notes" '.$sShowRadioNotes.'><div id="hamburger-notesview-icon"><div class="hamburger-item-text">' . _glt('Notes view') . '</div></div></div></div>';
	echo '	      </div>';
	echo '	      <div id="contextmenu-properties">';
	echo '		    <div class="contextmenu-items-hdr">' . _glt('Properties') . '</div>';
	echo '		    <div class="contextmenu-item" onclick="set_property_layout(\'1\')"><div id="navbar-prop-layout-wide" class="prop-layout-wide-disabled"><div id="hamburger-layout-wide-icon"><div class="hamburger-item-text">' . _glt('Wide view') . '</div></div></div></div>';
	echo '		    <div class="contextmenu-item" onclick="set_property_layout(\'2\')"><div id="navbar-prop-layout-split" class="prop-layout-split-enabled"><div id="hamburger-layout-split-icon"><div class="hamburger-item-text">' . _glt('Split view') . '</div></div></div></div>';
	echo '		    <hr>';
	echo '		    <div class="contextmenu-item" onclick="OnShowAboutPage(\'' . g_csWebEAVersion . '\')"><div id="hamburger-about-icon"><div class="hamburger-item-text">' . _glt('About WebEA') . '</div></div></div>';
	echo '		    <div class="contextmenu-item" onclick="OnLogoff(this)"><div id="hamburger-logout-icon"><div class="hamburger-item-text">' . _glt('Logout') . '</div></div></div>';
	echo '	      </div>';
	echo '		</div>';
	echo '    </div>';
	echo '  </div>';
	echo '</div>';
	echo '</div>';
	echo '</div>';
	echo PHP_EOL;
?>
<script>
function show_path()
{
	$('#path-menu').toggle();
}
function show_navbar_search()
{
	$('#navbar-search-menu').toggle();
}
function show_navbar_hamburger()
{
	$('#navbar-hamburger-menu').toggle();
}
$(document).mouseup(function (e)
{
	hide_menu(e, "#navbar-path-button","#path-menu");
});
function expand_navbar()
{
	var pr = document.getElementById("navbar-panel-right");
	pr.className += " navbar-panel-right-expanded";
	var pl = document.getElementById("navbar-panel-left");
	pl.className += " navbar-panel-left-collapsed";
}
function collapse_navbar()
{
	var pr = document.getElementById("navbar-panel-right");
	pr.className = "navbar-panel-right";
	var pl = document.getElementById("navbar-panel-left");
	pl.className = "navbar-panel-left";
}
</script>