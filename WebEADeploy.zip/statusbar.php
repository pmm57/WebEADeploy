<?php
// --------------------------------------------------------
//  This is a part of the Sparx Systems Pro Cloud Server.
//  Copyright (C) Sparx Systems Pty Ltd
//  All rights reserved.
//
//  This source code can be used only under terms and 
//  conditions of the accompanying license agreement.
// --------------------------------------------------------
	require_once 'globals.php';
	SafeStartSession();
	if (isset($_SESSION['authorized']) === false)
	{
		setResponseCode(440);
		exit();
	}
	$sReviewSession = isset($_POST['reviewguid']) ? $_POST['reviewguid'] : '';
	$sReviewSessionName = isset($_POST['reviewname']) ? $_POST['reviewname'] : '';
	if ( strIsEmpty($sReviewSession) )
	{
		$sReviewSession = SafeGetInternalArrayParameter($_SESSION, 'review_session');
		$sReviewSessionName = SafeGetInternalArrayParameter($_SESSION, 'review_session_name');
	}
	$sDisplayReviewName = LimitDisplayString($sReviewSessionName, 30);
	echo '<div style="width: 100%; display: table;">';
	echo '    <div style="display: table-row">';
	echo '        <div style="width: 110px; display: table-cell; vertical-align: top;">&nbsp;</div>';
	echo '        <div class="statusbar-item-about-cell">';
	echo '            <div class="statusbar-item-about" onclick="OnShowAboutPage(\'' . g_csWebEAVersion . '\')">';
	echo '                <img src="images/spriteplaceholder.png" class="mainsprite-about" alt="A" title="' . _glt('Show About screen') . '">';
	echo '            </div>';
	echo '        </div>';
	if ( !strIsEmpty($sReviewSession) )
	{
		echo '    <div class="statusbar-item-review-cell">';
		echo '		<div class="statusbar-item-review" onclick="load_object(\'' . $sReviewSession . '\',\'false\',\'\',\'\',\'' . ConvertStringToParameter($sReviewSessionName) . '\',\'images/element16/review.png\')">';
		echo '		<img alt="" src="images/spriteplaceholder.png" class="propsprite-review"/>&nbsp;';
		echo 		_glt('Review') . ' "'.  	   htmlspecialchars($sDisplayReviewName) .'"';
		echo '		</div>';
		echo '    </div>';
	}
	echo '    </div>';
	echo '</div>';
	echo PHP_EOL;
?>