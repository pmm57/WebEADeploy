<?php
// --------------------------------------------------------
//  This is a part of the Sparx Systems Pro Cloud Server.
//  Copyright (C) Sparx Systems Pty Ltd
//  All rights reserved.
//
//  This source code can be used only under terms and 
//  conditions of the accompanying license agreement.
// --------------------------------------------------------
	$sRootPath = dirname(__FILE__);
	require_once $sRootPath . '/globals.php';
	SafeStartSession();
	if (isset($_SESSION['authorized']) === false)
	{
		$sErrorMsg = _glt('Your session appears to have timed out');
		echo '<div id="main-content-empty">' . $sErrorMsg . '</div>';
		setResponseCode(440, $sErrorMsg);
		exit();
	}
	$g_sViewingMode		= '0';
	$sObjectGUIDEnc = SafeGetInternalArrayParameter($_POST, 'objectguid');
	$sObjectGUID 	= urldecode($sObjectGUIDEnc);
	$sResType 		= GetResTypeFromGUID($sObjectGUID);
	$sObjectHasChild = SafeGetInternalArrayParameter($_POST, 'haschild');
	$sLinkType 		= SafeGetInternalArrayParameter($_POST, 'linktype');
	$sObjectName	= SafeGetInternalArrayParameter($_POST, 'objectname');
	$sObjectImageURL = SafeGetInternalArrayParameter($_POST, 'imageurl');
	$sObjectHyper	= SafeGetInternalArrayParameter($_POST, 'hyper');
	$sCurrModelNo = SafeGetInternalArrayParameter($_SESSION, 'model_no', '');
	echo '<div id="page-built-with-model-no">' . $sCurrModelNo . '</div>';
	if ( $sObjectGUID === 'initialize' )
	{
	}
	elseif ( $sObjectGUID === 'addelement' )
	{
		include('mainaddelement.php');
	}
	elseif ( $sObjectGUID === 'addelementtest' )
	{
		include('mainaddelementtest.php');
	}
	elseif ( $sObjectGUID === 'addelementresalloc' )
	{
		include('mainaddelementresalloc.php');
	}
	elseif ( $sObjectGUID === 'addelementchgmgmt' )
	{
		include('mainaddelementchgmgmt.php');
	}
	elseif ( $sObjectGUID === 'editelementnote' )
	{
		include('maineditelementnote.php');
	}
	elseif ( $sObjectGUID === 'editelementtest' )
	{
		include('maineditelementtest.php');
	}
	elseif ( $sObjectGUID === 'editelementresalloc' )
	{
		include('maineditelementresalloc.php');
	}
	elseif ( $sObjectGUID === 'search' )
	{
		include('mainsearch.php');
	}
	elseif ( $sObjectGUID === 'searchresults' )
	{
		include('mainsearchresults.php');
	}
	elseif ( $sObjectGUID === 'watchlist' )
	{
		include('mainwatchlist.php');
	}
	elseif ( $sObjectGUID === 'watchlistconfig' )
	{
		include('mainwatchlistconfig.php');
	}
	elseif ( $sObjectGUID === 'watchlistresults' )
	{
		include('mainwatchlistresults.php');
	}
	else
	{
		if ( $sLinkType === "document" || $sLinkType === "encryptdoc" )
		{
			include('mainlinkeddoc.php');
		}
		elseif ( $sResType === "Connector" )
		{
			include('mainconnector.php');
		}
		elseif ( $sLinkType === 'props' || ($sResType==='Element' && $sLinkType !== 'child') )
		{
			include('mainproperties.php');
		}
		else
		{
			if ($sResType!=='Element' || $sObjectHasChild==='true' || ($sResType==='Element' && $sLinkType === 'child') )
			{
				if ($sResType === "Diagram")
				{
					if ( $sLinkType === "edit" )
					{
						include('maindiagramimagedit.php');
					}
					else
					{
						$sDiagramLayoutNo = SafeGetInternalArrayParameter($_SESSION, 'diagramlayout', '1');
						if ($sDiagramLayoutNo === '2')
						{
							include('maindiagramlist.php');
						}
						elseif ($sDiagramLayoutNo === '3')
						{
							include('maindiagramspecman.php');
						}
						else
						{
							include('maindiagramimage.php');
						}
					}
				}
				else if ($sResType === "ModelRoot" || $sResType === "Package" || $sResType === "Element" || strIsEmpty($sResType))
				{
					$sMainLayoutNo = SafeGetInternalArrayParameter($_SESSION, 'mainlayout', '1');
					if ($sMainLayoutNo === '2')
					{
						include('mainpackagelist.php');
					}
					elseif ($sMainLayoutNo === '3')
					{
						include('mainpackagespecman.php');
					}
					else
					{
						include('mainpackageicon.php');
					}
				}
			}
		}
	}
	echo '<div id="webea-viewing-mode" class="w3-hide">' . $g_sViewingMode . '</div>';
	echo '<div id="webea-last-oslc-error-code" class="w3-hide">' . $g_sLastOSLCErrorCode . '</div>';
	echo '<div id="webea-last-oslc-error-msg" class="w3-hide">' . $g_sLastOSLCErrorMsg . '</div>';
?>