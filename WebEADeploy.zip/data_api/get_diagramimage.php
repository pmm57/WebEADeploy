<?php
// --------------------------------------------------------
//  This is a part of the Sparx Systems Pro Cloud Server.
//  Copyright (C) Sparx Systems Pty Ltd
//  All rights reserved.
//
//  This source code can be used only under terms and 
//  conditions of the accompanying license agreement.
// --------------------------------------------------------
	if (isset($sObjectGUID) === false)
	{
		header("location: /login.php");
		exit();
	}
	$sRootPath = dirname(dirname(__FILE__));
	require_once $sRootPath . '/globals.php';
	SafeStartSession();
	if (isset($_SESSION['authorized']) === false)
	{
		echo '<div id="main-content-empty">Your session appears to have timed out, please reload the <a href="/login.php">main</a> page.</div>';
		setResponseCode(440);
		exit();
	}
	BuildOSLCConnectionString();
	$sOSLC_URL = $g_sOSLCString . "features/" . $sObjectGUID . "/";
	if ( !strIsEmpty($sObjectGUID) )
	{
		if ( !strIsEmpty($sOSLC_URL) )
		{
			$sStatusCode = '';
			$sStatusMessage = '';
			$sParas = '';
			$sLoginGUID  = SafeGetInternalArrayParameter($_SESSION, 'login_guid');
			AddURLParameter($sParas, 'useridentifier', $sLoginGUID);
			$sOSLC_URL 	.= $sParas;
			$xmlDoc = HTTPGetXML($sOSLC_URL);
			if ($xmlDoc != null)
			{
				$xnRoot = $xmlDoc->documentElement;
				$xnDesc = GetXMLFirstChild($xnRoot);
				if ($xnDesc != null && $xnDesc->childNodes != null)
				{
					if ( GetOSLCError($xnDesc) )
					{
						foreach ($xnDesc->childNodes as $xnDescC)
						{
							if ($xnDescC->nodeName === "ss:diagramimage")
							{
								$xnImgDesc = $xnDescC->firstChild;
								$xnImgProps = $xnImgDesc->getElementsByTagNameNS("*", "*");
								if ($xnImgProps != null)
								{
									foreach ($xnImgProps as $xnImgProp)
									{
										if ($xnImgProp->nodeName === "ss:image")
										{
											$sImgBin = $xnImgProp->nodeValue;
										}
										elseif ($xnImgProp->nodeName === "ss:imagemap")
										{
											$sImgMap = $xnImgProp->nodeValue;
											$sImgMap = str_replace('<![CDATA[<map name="#MAPNAME">', '', $sImgMap);
											$sImgMap = str_replace("]]>","", $sImgMap);
											$sImgMap = str_replace('$element=',"javascript:load_diagram_object('el_", $sImgMap);
											$sImgMap = str_replace('}',"}');", $sImgMap);
											$sImgMap = '<map id = "diagrammap" name="diagrammap">' . $sImgMap . '</map>';
										}
									}
								}
							}
						}
					}
				}
			}
		}
	}
?>