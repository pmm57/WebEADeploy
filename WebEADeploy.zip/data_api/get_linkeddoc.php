<?php
// --------------------------------------------------------
//  This is a part of the Sparx Systems Pro Cloud Server.
//  Copyright (C) Sparx Systems Pty Ltd
//  All rights reserved.
//
//  This source code can be used only under terms and 
//  conditions of the accompanying license agreement.
// --------------------------------------------------------
	$sRootPath = dirname(dirname(__FILE__));
	require_once $sRootPath . '/globals.php';
	SafeStartSession();
	if (isset($_SESSION['authorized']) === false)
	{
		echo '<div id="main-content-empty">' . _glt('Your session appears to have timed out') . '</div>';
		setResponseCode(440);
		exit();
	}
	if ($_SERVER["REQUEST_METHOD"] !== "POST")
	{
		setResponseCode(405);
		exit();
	}
	$sObjectGUID 	= SafeGetInternalArrayParameter($_POST, 'objectguid');
	$sPassword 		= SafeGetInternalArrayParameter($_POST, 'hyper');
	if (strIsEmpty($sObjectGUID))
	{
		setResponseCode(400);
		exit();
	}
	BuildOSLCConnectionString();
	$sOSLC_URL 		= $g_sOSLCString . "feature/linkeddocument/" . $sObjectGUID . "/";
	$sPostData 		= 'pwd=' . $sPassword;
	$sLoginGUID  = SafeGetInternalArrayParameter($_SESSION, 'login_guid');
	if ( !strIsEmpty($sLoginGUID) )
	{
		$sPostData .= ';useridentifier=' . $sLoginGUID;
	}
	$sErrorMsg 		= '';
	$sResponse		= HTTPPostXML($sOSLC_URL, $sPostData, $sErrorMsg);
	if ( strIsEmpty($sErrorMsg) )
	{
		if ($sResponse !== null && !strIsEmpty($sResponse))
		{
			$xmlDoc = new DOMDocument();
			if (SafeXMLLoad($xmlDoc, $sResponse, true) === true)
			{
				if ($xmlDoc != null)
				{
					$xnRoot = $xmlDoc->documentElement;
					$xnDesc = $xnRoot->firstChild;
					if ($xnDesc != null && $xnDesc->childNodes != null)
					{
						if ( GetOSLCError($xnDesc) )
						{
							$xnLD = GetXMLFirstChild($xnDesc);
							if ($xnLD != null)
							{
								$xnDesc2 = GetXMLFirstChild($xnLD);
								if ($xnDesc2 != null)
								{
									foreach ($xnDesc2->childNodes as $xnC)
									{
										GetXMLNodeValue($xnC, 'ss:content', $sHTMLDoc);
									}
								}
							}
						}
					}
				}
			}
		}
	}
	else
	{
		$sHTMLDoc = '<div class="search-message-error">' . $sErrorMsg . '</div>';
	}
?>