<?php
// --------------------------------------------------------
//  This is a part of the Sparx Systems Pro Cloud Server.
//  Copyright (C) Sparx Systems Pty Ltd
//  All rights reserved.
//
//  This source code can be used only under terms and 
//  conditions of the accompanying license agreement.
// --------------------------------------------------------
	$sRootPath = dirname(__FILE__);
	require_once $sRootPath . '/globals.php';
	SafeStartSession();
	if (isset($_SESSION['authorized']) === false)
	{
		$sErrorMsg = _glt('Your session appears to have timed out');
		echo '<div id="main-content-empty">' . $sErrorMsg . '</div>';
		setResponseCode(440, $sErrorMsg);
		exit();
	}
	if ($sResType === "Diagram")
	{
		$g_sViewingMode		= '2';
		if ( !strIsEmpty($sObjectGUID) )
		{
			$sImgBin 	= '';
			$sImgMap 	= '';
			include('./data_api/get_diagramimage.php');
			if ( IsSessionSettingTrue('edit_diagrams') && IsSessionSettingTrue('login_perm_updatediagram') )
			{
				echo '<div id="diagram-toolbar">';
				echo '<div class="diagram-toolbar-item">';
				echo '<input id="diagram-toolbar-edit" value="&nbsp;" title="Edit Diagram" onclick="edit_diagram(\'' . $sObjectGUID . '\',\'' . $sObjectName . '\',\''. $sObjectImageURL .'\')" type="button">';
				echo '</div>';
				echo '</div>';
			}
			if (strlen($sImgBin)>0)
			{
				echo '<div id="main-diagram-image" class="diagram-related-bkcolor">';
				echo '<div class="main-diagram-inner">';
				echo $sImgMap;
				printf('<img src="data:image/png;base64,%s" alt="" usemap="#diagrammap"/>', $sImgBin);
				echo '</div>';
				echo '</div>';
				echo '<iframe id="main_diagram_iframe" style="display:none;"></iframe>';
			}
			else
			{
				$sOSLCErrorMsg = BuildOSLCErrorString();
				if ( strIsEmpty($sOSLCErrorMsg) )
				{
					echo '<div id="main-diagram-image" class="diagram-related-bkcolor"><div class="main-diagram-image-inner">' . _glt('Invalid or missing diagram') . '</div></div>';
				}
				else
				{
					echo '<div id="main-diagram-image" class="diagram-related-bkcolor"><div class="main-diagram-image-inner">' . $sOSLCErrorMsg . '</div></div>';
				}
			}
		}
	}
?>