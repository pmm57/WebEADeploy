<?php
// --------------------------------------------------------
//  This is a part of the Sparx Systems Pro Cloud Server.
//  Copyright (C) Sparx Systems Pty Ltd
//  All rights reserved.
//
//  This source code can be used only under terms and 
//  conditions of the accompanying license agreement.
// --------------------------------------------------------
	$sRootPath = dirname(__FILE__);
	require_once $sRootPath . '/globals.php';
	SafeStartSession();
	if (isset($_SESSION['authorized']) === false)
	{
		$sErrorMsg = _glt('Your session appears to have timed out');
		echo '<div id="main-content-empty">' . $sErrorMsg . '</div>';
		setResponseCode(440, $sErrorMsg);
		exit();
	}
	$g_sViewingMode		= '3';
	$aCommonProps 	= array();
	$aAttributes 	= array();
	$aOperations 	= array();
	$aConstraints 	= array();
	$aTaggedValues 	= array();
	$aDiscussions 	= array();
	$aReviewDiscuss = array();
	$aReviewDiagrams = array();
	$aReviewNoDiscuss = array();
	$aTests 		= array();
	$aResAllocs 	= array();
	$aScenarios 	= array();
	$aRequirements 	= array();
	$aRunStates 	= array();
	$aUsages	 	= array();
	$aDocument	 	= array();
	$aParentInfo	= array();
	$aRelationships = array();
	$aChanges 		= array();
	$aDefects 		= array();
	$aIssues 		= array();
	$aTasks 		= array();
	$aEvents 		= array();
	$aDecisions 	= array();
	$aRisks 		= array();
	$aEfforts 		= array();
	$aMetrics 		= array();
	include('./data_api/get_properties.php');
	$sOSLCErrorMsg = BuildOSLCErrorString();
	if ( strIsEmpty($sOSLCErrorMsg) )
	{
		if (SafeGetArrayItem1Dim($aCommonProps, 'guid') === '')
		{
			echo '<div id="main-content-empty">';
			$s = _glt('NoElementLine1'). g_csHTTPNewLine . g_csHTTPNewLine;
			$sMessage = '';
			if ( !strIsEmpty($s) && $s!=='NoElementLine1' )
			{
				$sMessage .=  $s . g_csHTTPNewLine . g_csHTTPNewLine;
			}
			$s = _glt('NoElementLine2');
			if ( !strIsEmpty($s) && $s!=='NoElementLine2' )
			{
				$sMessage .=  $s . g_csHTTPNewLine . g_csHTTPNewLine;
			}
			$s = _glt('NoElementLine3');
			if ( !strIsEmpty($s) && $s!=='NoElementLine3' )
			{
				$sMessage .=  $s;
			}
			echo $sMessage;
			echo '</div>';
			exit();
		}
		$sPropertyLayoutNo = '2';
		if (isset($_SESSION['propertylayout']))
		{
			$sPropertyLayoutNo = $_SESSION['propertylayout'];
		}
		echo '<div id="properties-main" class="properties-main' . $sPropertyLayoutNo . '">';
		$sObjectGUID 	= SafeGetArrayItem1Dim($aCommonProps, 'guid');
		$sObjectAlias 	= SafeGetArrayItem1Dim($aCommonProps, 'alias');
		$sObjectName 	= SafeGetArrayItem1Dim($aCommonProps, 'name');
		$sObjectType 	= SafeGetArrayItem1Dim($aCommonProps, 'type');
		$sObjectResType = SafeGetArrayItem1Dim($aCommonProps, 'restype');
		$sObjectStereotype = SafeGetArrayItem1Dim($aCommonProps, 'stereotype');
		$aObjectStereotypes = SafeGetArrayItem1Dim($aCommonProps, 'stereotypes');
		$sObjImageURL	= SafeGetArrayItem1Dim($aCommonProps, 'imageurl');
		$sHasChildren	= SafeGetArrayItem1Dim($aCommonProps, 'haschild');
		$sObjectAuthor	= SafeGetArrayItem1Dim($aCommonProps, 'author');
		$sObjectModified= SafeGetArrayItem1Dim($aCommonProps, 'modified');
		$sObjectStatus	= SafeGetArrayItem1Dim($aCommonProps, 'status');
		$sObjectVersion	= SafeGetArrayItem1Dim($aCommonProps, 'version');
		$sObjectPhase	= SafeGetArrayItem1Dim($aCommonProps, 'phase');
		$sObjectNType	= SafeGetArrayItem1Dim($aCommonProps, 'ntype');
		$bObjLocked		= strIsTrue(SafeGetArrayItem1Dim($aCommonProps, 'locked'));
		$sObjLockedType	= SafeGetArrayItem1Dim($aCommonProps, 'lockedtype');
		$sObjClassName 	= SafeGetArrayItem1Dim($aCommonProps, 'classname');
		$sObjClassGUID 	= SafeGetArrayItem1Dim($aCommonProps, 'classguid');
		$sObjClassImageURL	= SafeGetArrayItem1Dim($aCommonProps, 'classimageurl');
		$sReviewStatus	= '';
		$sReviewStartDate = '';
		$sReviewEndDate	= '';
		$bIsReviewElement = false;
		if ( ($sObjectResType === 'Element' && $sObjectType === 'Artifact' && $sObjectStereotype === 'EAReview')  )
		{
			$bIsReviewElement = true;
			$sReviewStatus	= GetTaggedValue($aTaggedValues, 'Status', 'EAReview::Status');
			$sReviewStartDate = GetTaggedValue($aTaggedValues, 'StartDate', 'EAReview::StartDate');
			$sReviewEndDate	= GetTaggedValue($aTaggedValues, 'EndDate', 'EAReview::EndDate');
		}
		echo '<div id="object-main-details">';
		if ( $sObjectResType === 'Package' || $sObjectResType === 'Element' )
		{
			if ( !$bObjLocked )
			{
				echo '<div class="object-navigation">';
				include('elementhamburger.php');
				echo '</div>';
			}
		}
		echo '<div class="object-image">';
		if ($sHasChildren === 'true' && $bObjLocked)
		{
			$sImageLink = '<img style="background:url(' . $sObjImageURL . ')" src="images/element64/lockedhaschildoverlay.png" alt="" title="' . _glt('View child objects for locked') . ' ' . $sObjectResType . '" height="64" width="64"/>';
		}
		elseif ($sHasChildren === 'true' && !$bObjLocked )
		{
			$sImageLink = '<img style="background:url(' . $sObjImageURL . ')" src="images/element64/haschildoverlay.png" alt="" title="' . _glt('View child objects') . '" height="64" width="64"/>';
		}
		elseif ($sHasChildren === 'false' && $bObjLocked)
		{
			$sImageLink = '<img style="background:url(' . $sObjImageURL . ')" src="images/element64/lockedoverlay.png" alt="" title="' . $sObjectResType . ' ' . _glt('is locked') . '" height="64" width="64"/>';
		}
		else
		{
			$sImageLink = '<img src="' . $sObjImageURL . '" alt="" title="" height="64" width="64"/>';
		}
		if ( $sObjectResType === 'ModelRoot' || $sObjectResType === 'Package' || $sHasChildren === 'true' )
		{
			if ( $sObjectResType === 'Element' && $sHasChildren === 'true' )
			{
				echo '<a class="w3-link" onclick="load_object(\'' . $sObjectGUID . '\',\'false\',\'child\',\'\',\'' . ConvertStringToParameter($sObjectName) . '\', \'' . $aCommonProps['imageurl'] . '\')">';
			}
			else
			{
				echo '<a class="w3-link" onclick="load_object(\'' . $sObjectGUID . '\',\'true\',\'\',\'\',\'' . ConvertStringToParameter($sObjectName) . '\', \'' . $aCommonProps['imageurl'] . '\')">';
			}
			echo $sImageLink;
			echo '</a>';
		}
		elseif ( $sObjectResType === 'Diagram' )
		{
			echo '<a class="w3-link" onclick="load_object(\'' . $sObjectGUID . '\',\'false\',\'\',\'\',\'' . ConvertStringToParameter($sObjectName) . '\', \'' . $aCommonProps['imageurl'] . '\')">';
			echo $sImageLink;
			echo '</a>';
		}
		else
		{
			echo $sImageLink;
		}
		echo '</div>';
		if (IsHyperlink($sObjectType, $sObjectName, $sObjectNType))
		{
			$sDisplayName = $sObjectName;
			if ( !strIsEmpty($sObjectAlias) )
			{
				$sDisplayName = $sObjectAlias;
			}
			$sDisplayName 	= GetPlainDisplayName($sDisplayName);
			echo '<div class="object-name">' . htmlspecialchars($sDisplayName) . '</div>';
			echo '<div class="object-line2">';
			echo _glt('Hyperlink') . '&nbsp;';
			echo '</div>';
			echo '</div>';
		}
		elseif (ShouldIgnoreName($sObjectType, $sObjectName, $sObjectNType))
		{
			$sDisplayObjType = $sObjectType;
			if ( !strIsEmpty($sObjClassGUID) )
			{
				$sDisplayObjType  = '<a class="w3-link" onclick="load_object(\'' . $sObjClassGUID . '\',\'false\',\'\',\'\',\'' . ConvertStringToParameter($sObjectType) . '\',\'' . $sObjClassImageURL . '\')">';
				$sDisplayObjType .= '<img src="images/spriteplaceholder.png" class="' . GetObjectImageSpriteName($sObjClassImageURL) . '" alt="" style="float: none;">&nbsp;' . htmlspecialchars($sObjClassName) . '</a>';
			}
			else
			{
				$sDisplayObjType = htmlspecialchars(_glt($sDisplayObjType));
			}
			echo '<div class="object-name">' . htmlspecialchars( GetPlainDisplayName($sObjectName) ) . '</div>';
			echo '<div class="object-line2">';
			echo ( strIsEmpty($sDisplayObjType)?'': $sDisplayObjType . '&nbsp;');
			$sStereoHTML = buildStereotypeDisplayHTML($sObjectStereotype, $aObjectStereotypes, false);
			if ( !strIsEmpty($sStereoHTML) )
			{
				echo ( '&nbsp;' . $sStereoHTML . '&nbsp;&nbsp;' );
			}
			echo '</div>';
			echo '</div>';
			$sDocType = SafeGetArrayItem1Dim($aDocument, 'type');
			if ( $sDocType === 'MDOC_HTML_CACHE' || $sDocType === 'MDOC_HTML_EDOC1' || $sDocType === 'ExtDoc' )
			{
				echo '<div class="object-document">';
				if ( $sDocType === 'MDOC_HTML_EDOC1' || $sDocType === 'MDOC_HTML_CACHE' )
				{
					if ($sDocType === 'MDOC_HTML_EDOC1')
					{
						$sLoadObject = 'load_object(\'' . $sObjectGUID . '\',\'false\',\'encryptdoc\',\'\',\'' . ConvertStringToParameter($sObjectName) . '\', \'' . AdjustImagePath($sObjImageURL, '16') . '\')';
						echo '<img class="mainprop-object-image ' . GetObjectImageSpriteName('images/element16/encrypteddoc.png') . '" src="images/spriteplaceholder.png" alt=""> ' . _glt('Linked Document') . ' ';
						echo '<input id="linked-document-pwd-field" placeholder="' . _glt('password') . '" type="password" onkeypress="return onLinkDocPWDKeyDown(event,\''. $sObjectGUID. '\',\'' . ConvertStringToParameter($sObjectName) . '\', \'' .  AdjustImagePath($sObjImageURL, '16') . '\')" value="">';
					}
					else
					{
						$sLoadObject = 'load_object(\'' . $sObjectGUID . '\',\'false\',\'document\',\'\',\'' . ConvertStringToParameter($sObjectName) . '\', \'' . AdjustImagePath($sObjImageURL, '16') . '\')';
						echo '<img class="mainprop-object-image ' . GetObjectImageSpriteName('images/element16/document.png') . '" src="images/spriteplaceholder.png" alt=""> ' . _glt('Linked Document') . ' ';
					}
					echo '<button class="linked-document-open-button webea-main-styled-button" onclick="' . $sLoadObject. '">' . _glt('Open Document') . '</button> ';
				}
				elseif ( $sDocType === 'ExtDoc' )
				{
					if  (isset($_SERVER['HTTP_USER_AGENT']) &&
						(strpos($_SERVER['HTTP_USER_AGENT'], 'MSIE') === false) &&
						(strpos($_SERVER['HTTP_USER_AGENT'], 'Trident/7.0; rv:11.0') === false) )
					{
						$sDocContent = SafeGetArrayItem1Dim($aDocument, 'content');
						echo '<img class="mainprop-object-image ' . GetObjectImageSpriteName('images/element16/storeddocument.png') . '" src="images/spriteplaceholder.png" alt=""> ' . _glt('Stored Document') . ' ';
						echo '<a href="data:application/octet-stream;charset=utf-8;base64,' . $sDocContent . '" download="' . $sObjectName. '"><div class="stored-document-download-button webea-main-styled-button">'  . _glt('Download') . '</div></a>';
					}
				}
				echo "</div>";
			}
			elseif ( $sObjectNType==='32' )
			{
				$sImageAssetGUID	= SafeGetArrayItem1Dim($aCommonProps, 'imageasset');
				if ( !strIsEmpty($sImageAssetGUID) )
				{
					echo '<div class="object-document">';
					echo '<img class="mainprop-object-image ' . GetObjectImageSpriteName('images/element16/imageasset.png') . '" src="images/spriteplaceholder.png" alt=""> ' . _glt('Image Asset') . ' ';
					echo '<a href="data_api/dl_model_image.php?objectguid=' . $sImageAssetGUID . '" download="' . $sObjectName. '"><div class="stored-document-download-button webea-main-styled-button">'  . _glt('Download') . '</div></a>';
					echo "</div>";
				}
			}
		}
		else
		{
			echo '</div>';
		}
		if ( $bIsReviewElement )
		{
			$sPartInReviews = SafeGetInternalArrayParameter($_SESSION, 'participate_in_reviews');
			if ( strIsTrue($sPartInReviews) )
			{
				$sReviewSession = SafeGetInternalArrayParameter($_SESSION, 'review_session');
				$bJoin  = false;
				$bLeave = false;
				$sJoinTitle = '';
				$sLeaveTitle = '';
				if ( strIsEmpty( $sReviewSession ) )
				{
					$bJoin = true;
				}
				else
				{
					if ( $sReviewSession === $sObjectGUID )
					{
						$bLeave = true;
					}
				}
				$sLCReviewStatus = mb_strtolower($sReviewStatus);
				if ($bJoin && ($sLCReviewStatus !== 'open' && $sLCReviewStatus !== 'pending'))
				{
					$bJoin = false;
					$sJoinTitle = _glt('The current review is not open');
				}
				echo '<div class="review-session-section"><div class="review-session-actions">';
				echo '<input class="review-session-action-button" name="join" id="review-session-join-button" value="' . _glt('Join Review') . '" type="button" title="' . $sJoinTitle . '" onclick="OnJoinLeaveReviewSession(\'' . $sObjectGUID . '\', \'' . ConvertStringToParameter($sObjectName) . '\', \'' . $sObjectGUID . '\')" ' . ($bJoin ? '>' : 'disabled="">');
				echo '<input class="review-session-action-button" name="leave" id="review-session-leave-button" value="' . _glt('Leave Review') . '" type="button" onclick="OnJoinLeaveReviewSession(\'\', \'\', \'' . $sObjectGUID . '\')" ' . ($bLeave ? '>' : 'disabled="">');
				echo '</div></div>';
			}
		}
		$sNotes = SafeGetArrayItem1Dim($aCommonProps, 'notes');
		WriteNotes($sNotes, $sObjectGUID, $sObjectName, $bObjLocked, $sObjImageURL);
		if ( $bIsReviewElement )
		{
			echo '<h4 class="section-heading">' . _glt('Review Summary') . '</h4>';
			WriteSectionReviewSummary($aReviewDiscuss, $sReviewStatus, $sReviewStartDate, $sReviewEndDate, $aReviewDiagrams, $aReviewNoDiscuss);
			if ( count($aReviewDiscuss)>0 || count($aReviewNoDiscuss)>0 )
			{
				echo '<h4 class="section-heading">' . _glt('Objects in Review') . '</h4>';
				WriteSectionReviewDiscussions($aReviewDiscuss, $aReviewNoDiscuss);
			}
		}
		if ( count($aRequirements)>0 )
		{
			echo '<h4 class="section-heading">' . _glt('Requirements') . '</h4>';
			WriteSectionRequirements($aRequirements);
		}
		if ( count($aConstraints)>0 )
		{
			echo '<h4 class="section-heading">' . _glt('Constraints') . '</h4>';
			WriteSectionConstraints($aConstraints);
		}
		if ( count($aScenarios)>0 )
		{
			echo '<h4 class="section-heading">' . _glt('Scenarios') . '</h4>';
			WriteSectionScenarios($aScenarios);
		}
		echo '</div>';
		echo '<div id="properties-right" class="properties-right' . $sPropertyLayoutNo . '">';
		include('./properties.php');
		echo '</div>';
	}
	else
	{
		echo '<div id="main-content-empty">' . $sOSLCErrorMsg . '</div>';
	}
	function WriteNotes($sNotes, $sObjectGUID, $sObjectName, $bObjLocked, $sObjImageURL)
	{
		$sPlainNotes = ConvertHyperlinksInEAComments($sNotes);
		echo '<div class="notes-section">';
		if ( !$bObjLocked )
		{
			if ( IsSessionSettingTrue('login_perm_element') )
			{
				if (IsSessionSettingTrue('edit_object_notes'))
				{
					echo '<div class="notes-section-edit">';
					echo '<input class="notes-section-edit-button" type="button" value="&#160;" onclick="load_object(\'editelementnote\',\'false\',\'' . $sObjectGUID . '|' . ConvertStringToParameter($sObjectName) . '\',\'\',\'' . ConvertStringToParameter($sObjectName) . '\',\'' . $sObjImageURL . '\')" title="' . _glt('Edit Notes') . '" />';
					echo '</div>';
				}
			}
		}
		if ( strIsEmpty($sPlainNotes) )
			$sPlainNotes = '&nbsp;';
		echo '<img alt="" src="images/spriteplaceholder.png" class="propsprite-note">';
		echo '<div class="notes-note">' . $sPlainNotes . '</div>';
		echo '</div>' . PHP_EOL;
	}
	function WriteSectionRequirements($a)
	{
		echo '<div id="requirement-section">';
		$iCnt = count($a);
		for ($i=0;$i<$iCnt;$i++)
		{
			$sType = SafeGetArrayItem2Dim($a, $i, 'type');
			$sTitle = SafeGetArrayItem2Dim($a, $i, 'name');
			$sType	= htmlspecialchars($sType);
			$sTitle	= htmlspecialchars($sTitle);
			echo '<div class="requirement-item">';
			echo '<img alt="" src="images/spriteplaceholder.png" class="requirement-icon">';
			echo '<span class="requirement-name">' . $sType . '.&nbsp' . $sTitle . '</span>';
			$sStatus = SafeGetArrayItem2Dim($a, $i,'status');
			$sStability = SafeGetArrayItem2Dim($a, $i,'stability');
			$sDiff = SafeGetArrayItem2Dim($a, $i, 'difficulty');
			$sPrior = SafeGetArrayItem2Dim($a, $i, 'priority');
			$sNotes = SafeGetArrayItem2Dim($a, $i, 'notes');
			$sStatus = htmlspecialchars($sStatus);
			$sStability	= htmlspecialchars($sStability);
			$sDiff	= htmlspecialchars($sDiff);
			$sPrior	= htmlspecialchars($sPrior);
			if ( !strIsEmpty($sNotes) )
			{
				echo '<div class="requirement-notes">' . $sNotes . '</div>';
			}
			if ( !strIsEmpty($sStatus) || !strIsEmpty($sDiff) )
			{
				echo '<div class="requirement-status">[';
				$sStatusDiff = ( strIsEmpty($sStatus)? '': '&nbsp;' . $sStatus . '&nbsp;');
				$sStatusDiff = $sStatusDiff . ( !strIsEmpty($sStatus) && !strIsEmpty($sDiff)?',': '');
				$sStatusDiff = $sStatusDiff . ( strIsEmpty($sDiff)? '': '&nbsp;' . $sDiff . '&nbsp;' . _glt('difficulty') . '.&nbsp;');
				echo $sStatusDiff;
				echo ']</div>';
			}
			echo '</div>'. PHP_EOL;
		}
		echo '</div>' . PHP_EOL;
	}
	function WriteSectionConstraints($a)
	{
		echo '<div id="constraint-section">';
		$iCnt = count($a);
		for ($i=0;$i<$iCnt;$i++)
		{
			$sName = SafeGetArrayItem2Dim($a, $i, 'name');
			$sNotes = SafeGetArrayItem2Dim($a, $i, 'notes');
			$sName = htmlspecialchars($sName);
			echo '<div class="constraint-item">';
			echo '<div class="constraint-name">';
			echo '<img alt="" src="images/spriteplaceholder.png" class="constraint-icon">';
			echo '<span class="constraint-type">' . $a[$i]['type'] . '.</span>&nbsp;';
			echo '<span class="constraint-name-text">' . $sName . '</span>&nbsp;';
			echo '</div>';
			if ( !strIsEmpty($sNotes) )
			{
				echo '<div class="constraint-desc">';
				echo '<span class="constraint-notes">' . $sNotes . '</span>';
				echo '</div>';
			}
			echo '<div class="constraint-status">[&nbsp;' . $a[$i]['status'] . '.&nbsp;]</div>';
			echo '</div>';
		}
		echo '</div>' . PHP_EOL;
	}
	function WriteSectionScenarios($a)
	{
		echo '<div id="scenario-section">';
		$iCnt = count($a);
		for ($i=0; $i<$iCnt; $i++)
		{
			$sType = SafeGetArrayItem2Dim($a, $i, 'type');
			$sName = SafeGetArrayItem2Dim($a, $i, 'name');
			$sName = htmlspecialchars($sName);
			echo '<div class="scenario-item">';
			echo '<img alt="" src="images/spriteplaceholder.png" class="scenario-icon">';
			if( !strIsEmpty($sType) && !strIsEmpty($sName) )
			{
				echo '<div class="scenario-name">'. $sType . '&nbsp;.&nbsp'. $sName.'</div>';
			}
			elseif ( strIsEmpty($sType) && !strIsEmpty($sName))
			{
				echo '<div class="scenario-name">'. $sName.'</div>';
			}
			echo '<div class="scenario-desc">';
			$sNotes = SafeGetArrayItem2Dim($a, $i, 'description');
			if ( !strIsEmpty($sNotes) )
			{
				echo '<span class="scenario-notes">' . $sNotes . '</span>';
			}
			if (array_key_exists(("steps"), $a[$i]))
			{
				$aSteps = $a[$i]['steps'];
				$iStepsCnt = count($aSteps);
				for ($in=0; $in<$iStepsCnt; $in++)
				{
					$sStepName = SafeGetArrayItem2Dim($aSteps, $in, 'stepname');
					$sLevel = SafeGetArrayItem2Dim($aSteps, $in, 'level');
					$sUses = SafeGetArrayItem2Dim($aSteps, $in,'uses');
					$sStepName = htmlspecialchars($sStepName);
					$sUses = htmlspecialchars($sUses);
					echo '<div class="scenario-step">&nbsp;' . $sLevel . '.' . '&nbsp;' . $sStepName . '</div>';
					if ( !strIsEmpty($sUses) )
					{
						echo '<div class="scenario-step-uses">';
						echo '<span class="scenario-step-uses-label">Uses:</span><span id="scenario-step-uses-text">&nbsp;' . $sUses . '</span>';
						echo '</div>';
					}
				}
			}
			echo '</div>';
			echo '</div>';
		}
		echo '</div>' . PHP_EOL;
	}
	function WriteSectionReviewSummary($a, $sReviewStatus, $sReviewStartDate, $sReviewEndDate, $aDiagrams, $aNoDiscuss)
	{
		$iElementNotDiscussCnt = 0;
		$iDiscussTopicCnt 	= 0;
		$iPriorLowCnt		= 0;
		$iPriorMediumCnt	= 0;
		$iPriorHighCnt 		= 0;
		$iPriorNoneCnt		= 0;
		$iStatusOpenCnt 	= 0;
		$iStatusAwaitCnt 	= 0;
		$iStatusClosedCnt 	= 0;
		$iReviewDiagramCnt 	= 0;
		echo '<div id="reviewsummary-section">';
		$iElementCnt 	= count($a);
		for ($iEle=0; $iEle<$iElementCnt; $iEle++)
		{
			if (array_key_exists(("discussions"), $a[$iEle]))
			{
				$aDiscussions = $a[$iEle]['discussions'];
				$iDiscussCnt = count($aDiscussions);
				$iDiscussTopicCnt += $iDiscussCnt;
				for ($iD=0; $iD<$iDiscussCnt; $iD++)
				{
					$sPriority		= mb_strtolower(SafeGetArrayItem2Dim($aDiscussions, $iD, 'priority'));
					$sStatus 		= mb_strtolower(SafeGetArrayItem2Dim($aDiscussions, $iD, 'status'));
					if ( $sPriority === 'low' )
						$iPriorLowCnt += 1;
					elseif ( $sPriority === 'medium' )
						$iPriorMediumCnt += 1;
					elseif ( $sPriority === 'high' )
						$iPriorHighCnt += 1;
					else
						$iPriorNoneCnt += 1;
					if ( $sStatus === 'open' )
						$iStatusOpenCnt += 1;
					elseif ( $sStatus === 'awaiting review' )
						$iStatusAwaitCnt += 1;
					elseif ( $sStatus === 'closed' )
						$iStatusClosedCnt += 1;
				}
			}
		}
		echo '<div class="reviewsummary-line"><div class="reviewsummary-lvl1-col1">' . _glt('Review Status') . '</div><div class="reviewsummary-lvl1-col2">' . $sReviewStatus . '</div></div>';
		echo '<div class="reviewsummary-line"><div class="reviewsummary-lvl1-col1">' . _glt('Start') . '</div><div class="reviewsummary-lvl1-col2">' . $sReviewStartDate . '</div></div>';
		echo '<div class="reviewsummary-line"><div class="reviewsummary-lvl1-col1">' . _glt('End') . '</div><div class="reviewsummary-lvl1-col2">' . $sReviewEndDate . '</div></div>';
		$iElementNotDiscussCnt = count($aNoDiscuss);
		echo '<div class="reviewsummary-line"><div class="reviewsummary-lvl1-col1">' . _glt('Elements discussed') . '</div><div class="reviewsummary-lvl1-col2">' . $iElementCnt . '</div></div>';
		echo '<div class="reviewsummary-line"><div class="reviewsummary-lvl1-col1">' . _glt('Elements not discussed') . '</div><div class="reviewsummary-lvl1-col2">' . $iElementNotDiscussCnt . '</div></div>';
		echo '<div class="reviewsummary-line"><div class="reviewsummary-lvl1-col1">' . _glt('Discussion Topics') . '</div><div class="reviewsummary-lvl1-col2">' . $iDiscussTopicCnt . '</div></div>';
		echo '<div class="reviewsummary-line-lvl2-hdr">' . _glt('Priority') . '</div>';
		echo '<div class="reviewsummary-line-lvl2"><div class="reviewsummary-lvl2-col1"><img class="reviewsummary-lvl2-img propsprite-discusspriorityhigh" alt="" src="images/spriteplaceholder.png">&nbsp;' . _glt('High') . '</div><div class="reviewsummary-lvl2-col2">' . $iPriorHighCnt . '</div></div>';
		echo '<div class="reviewsummary-line-lvl2"><div class="reviewsummary-lvl2-col1"><img class="reviewsummary-lvl2-img propsprite-discussprioritymed" alt="" src="images/spriteplaceholder.png">&nbsp;' . _glt('Medium') . '</div><div class="reviewsummary-lvl2-col2">' . $iPriorMediumCnt . '</div></div>';
		echo '<div class="reviewsummary-line-lvl2"><div class="reviewsummary-lvl2-col1"><img class="reviewsummary-lvl2-img propsprite-discussprioritylow" alt="" src="images/spriteplaceholder.png">&nbsp;' . _glt('Low') . '</div><div class="reviewsummary-lvl2-col2">' . $iPriorLowCnt . '</div></div>';
		echo '<div class="reviewsummary-line-lvl2"><div class="reviewsummary-lvl2-col1"><img class="reviewsummary-lvl2-img propsprite-discussprioritynone" alt="" src="images/spriteplaceholder.png"">&nbsp;' . _glt('<none>') . '</div><div class="reviewsummary-lvl2-col2">' . $iPriorNoneCnt . '</div></div>';
		echo '<div class="reviewsummary-line-lvl2-hdr">' . _glt('Status') . '</div>';
		echo '<div class="reviewsummary-line-lvl2"><div class="reviewsummary-lvl2-col1"><img class="reviewsummary-lvl2-img propsprite-discussstatusopen" alt="" src="images/spriteplaceholder.png">&nbsp;' . _glt('Open') . '</div><div class="reviewsummary-lvl2-col2">' . $iStatusOpenCnt . '</div></div>';
		echo '<div class="reviewsummary-line-lvl2"><div class="reviewsummary-lvl2-col1"><img class="reviewsummary-lvl2-img propsprite-discussstatusawait" alt="" src="images/spriteplaceholder.png">&nbsp;' . _glt('Awaiting Review') . '</div><div class="reviewsummary-lvl2-col2">' . $iStatusAwaitCnt . '</div></div>';
		echo '<div class="reviewsummary-line-lvl2"><div class="reviewsummary-lvl2-col1"><img class="reviewsummary-lvl2-img propsprite-discussstatuscomplete" alt="" src="images/spriteplaceholder.png">&nbsp;' . _glt('Closed') . '</div><div class="reviewsummary-lvl2-col2">' . $iStatusClosedCnt . '</div></div>';
		echo '</div>' . PHP_EOL;
		$iReviewDiagramCnt = count($aDiagrams);
		echo '<h4 class="section-heading">' . _glt('Review diagrams') . '</h4>';
		echo '<div class="reviewdiagram-section">';
		if ($iReviewDiagramCnt > 0)
		{
			$sName 		= '';
			$sGUID 		= '';
			$sImageURL	= '';
			for ($i=0; $i<$iReviewDiagramCnt; $i++)
			{
				$sName = SafeGetArrayItem2Dim($aDiagrams, $i, 'name');
				$sGUID = SafeGetArrayItem2Dim($aDiagrams, $i, 'guid');
				$sImageURL = SafeGetArrayItem2Dim($aDiagrams, $i, 'imageurl');
				echo '<div class="reviewsummary-line w3-link"><div onclick="load_object(\'' . $sGUID . '\',\'false\',\'\',\'\',\'' . ConvertStringToParameter($sName) . '\',\'' . $sImageURL . '\')">';
				echo '<img alt="" title="Diagram" src="images/spriteplaceholder.png" class="' . GetObjectImageSpriteName($sImageURL) . '">&nbsp;' . htmlspecialchars($sName) . '</div></div>';
			}
		}
		echo '</div>' . PHP_EOL;
	}
	function WriteSectionReviewDiscussions($a, $aNoDiscuss)
	{
		echo '<div id="reviewdiscussion-section">';
		$iElementCnt = count($aNoDiscuss);
		for ($iEle=0; $iEle<$iElementCnt; $iEle++)
		{
			$sObjName 	= SafeGetArrayItem2Dim($aNoDiscuss, $iEle, 'name');
			$sObjType 	= SafeGetArrayItem2Dim($aNoDiscuss, $iEle, 'type');
			$sObjResType= SafeGetArrayItem2Dim($aNoDiscuss, $iEle, 'restype');
			$sObjGUID 	= SafeGetArrayItem2Dim($aNoDiscuss, $iEle, 'guid');
			$sObjStereo = SafeGetArrayItem2Dim($aNoDiscuss, $iEle, 'stereotype');
			$sObjImageURL = SafeGetArrayItem2Dim($aNoDiscuss, $iEle, 'imageurl');
			$sObjName 	= GetPlainDisplayName($sObjName);
			$sObjName = htmlspecialchars($sObjName);
			echo '<div class="reviewdiscussion-item">';
			if ( !strIsEmpty($sObjType) )
			{
				echo '<div id=reviewdiscussion-element-link class="w3-link" onclick="load_object(\'' . $sObjGUID . '\',\'false\',\'props\',\'\',\'' . ConvertStringToParameter($sObjName) . '\',\'' . $sObjImageURL . '\')">';
				echo '<img class="mainprop-object-image ' . GetObjectImageSpriteName($sObjImageURL) . '" src="images/spriteplaceholder.png" alt="">&nbsp;' . $sObjName;
				echo '</div>';
			}
			echo '</div>';
		}
		$iElementCnt = count($a);
		for ($iEle=0; $iEle<$iElementCnt; $iEle++)
		{
			$sObjName 	= SafeGetArrayItem2Dim($a, $iEle, 'name');
			$sObjType 	= SafeGetArrayItem2Dim($a, $iEle, 'type');
			$sObjResType= SafeGetArrayItem2Dim($a, $iEle, 'restype');
			$sObjGUID 	= SafeGetArrayItem2Dim($a, $iEle, 'guid');
			$sObjStereo = SafeGetArrayItem2Dim($a, $iEle, 'stereotype');
			$sObjImageURL = SafeGetArrayItem2Dim($a, $iEle, 'imageurl');
			$sObjName = htmlspecialchars($sObjName);
			echo '<div class="reviewdiscussion-item">';
			if( !strIsEmpty($sObjType) && !strIsEmpty($sObjName) )
			{
				echo '<div id=reviewdiscussion-element-link class="w3-link" onclick="load_object(\'' . $sObjGUID . '\',\'false\',\'props\',\'\',\'' . ConvertStringToParameter($sObjName) . '\',\'' . $sObjImageURL . '\')">';
				echo '<img class="mainprop-object-image ' . GetObjectImageSpriteName($sObjImageURL) . '" src="images/spriteplaceholder.png" alt="">&nbsp;' . $sObjName;
				echo '</div>';
				if (array_key_exists(("discussions"), $a[$iEle]))
				{
					echo '<div class="reviewdiscussion-item-topics">';
					$aDiscussions = $a[$iEle]['discussions'];
					$iDiscussCnt = count($aDiscussions);
					for ($iD=0; $iD<$iDiscussCnt; $iD++)
					{
						$sDiscussText 	= SafeGetArrayItem2Dim($aDiscussions, $iD, 'discussion');
						$sDiscussGUID 	= SafeGetArrayItem2Dim($aDiscussions, $iD, 'guid');
						$sPriority		= SafeGetArrayItem2Dim($aDiscussions, $iD, 'priority');
						$sPriorityImageClass = SafeGetArrayItem2Dim($aDiscussions, $iD, 'priorityimageclass');
						$sPriorityTooltip = str_replace('%PRIORITY%', $sPriority, _glt('Priority: xx'));
						$sStatus 		= SafeGetArrayItem2Dim($aDiscussions, $iD, 'status');
						$sStatusImageClass = SafeGetArrayItem2Dim($aDiscussions, $iD, 'statusimageclass');
						$sStatusTooltip = str_replace('%STATUS%', $sStatus, _glt('Status: xx'));
						$aReplies = null;
						$iReplyCnt = 0;
						if (array_key_exists(("replies"), $aDiscussions[$iD]))
						{
							$aReplies = $aDiscussions[$iD]['replies'];
							$iReplyCnt = count($aReplies);
						}
						if ($iReplyCnt > 0)
						{
							echo '<div class="reviewdiscussion-discussion-item collapsible-section-header-closed">';
							echo '<img alt="" src="images/spriteplaceholder.png" class="reviewdiscussion-discussion-item-icon collapsible-section-header-closed-icon show-cursor-pointer" onclick="OnToggleReviewDiscussionReplies(\'' . $sDiscussGUID . '\')">';
						}
						else
						{
							echo '<div class="reviewdiscussion-discussion-item">';
						}
						WriteAvatarImage($aDiscussions[$iD]['avatarid'], 'false');
						echo '<div class="reviewdiscussion-discussion-item-states" >';
						echo '<span id="review-prioritymenu-button"><img alt="" src="images/spriteplaceholder.png" class="' . $sPriorityImageClass . '" title="' . $sPriorityTooltip . '" height="16" width="16">&nbsp;</span>';
						echo '<span id="review-statusmenu-button"><img alt="" src="images/spriteplaceholder.png" class="' . $sStatusImageClass . '" title="' . $sStatusTooltip . '" height="16" width="16">&nbsp;</span>';
						echo '</div>';
						echo '<div class="reviewdiscussion-discussion-item-text' . ($iReplyCnt > 0 ? ' show-cursor-pointer' : '') . '" onclick="OnToggleReviewDiscussionReplies(\'' . $sDiscussGUID . '\')">' . $sDiscussText . '</div>';
						echo '<div class="reviewdiscussion-discussion-item-text-footer">';
						echo '<div class="reviewdiscussion-discussion-item-text-footer-dateauthor">' . $aDiscussions[$iD]['created'] . '&nbsp; &nbsp;' . $aDiscussions[$iD]['author'] . '</div>';
						echo '</div>';
						if ($iReplyCnt > 0)
						{
							echo '<div class="reviewdiscussion-discussion-item-replies" id="mpreplies_' . $sDiscussGUID . '">';
							for ($iR=0; $iR<$iReplyCnt; $iR++)
							{
								$sReplyAuthor 	= SafeGetArrayItem2Dim($aReplies, $iR, 'replyauthor');
								$sReplyCreated 	= SafeGetArrayItem2Dim($aReplies, $iR, 'replycreated');
								$sReplyText 	= SafeGetArrayItem2Dim($aReplies, $iR, 'replytext');
								$sReplyAvatarID 	= SafeGetArrayItem2Dim($aReplies, $iR, 'replyavatarid');
								$sReplyAvatarImage 	= SafeGetArrayItem2Dim($aReplies, $iR, 'replyavatarimage');
								echo '<div class="reviewdiscussion-discussion-item-reply">';
								WriteAvatarImage($sReplyAvatarID, 'true');
								echo '<div class="reviewdiscussion-discussion-item-reply-text">' . $sReplyText . '</div>';
								echo '<div class="reviewdiscussion-discussion-item-reply-text-footer">';
								echo '<div class="reviewdiscussion-discussion-item-reply-text-footer-dateauthor">' . $sReplyCreated . '&nbsp; &nbsp;' . $sReplyAuthor . '</div>';
								echo '</div>';
								echo '</div>';
							}
							echo '</div>';
						}
						echo '</div>';
					}
					echo '</div>';
				}
			}
			echo '</div>';
			if ($iEle<$iElementCnt-1)
			{
				echo '<hr class="reviewdiscussion-hr">';
			}
		}
		echo '</div>' . PHP_EOL;
	}
?>